"""配布版 VoiceChanger の自動更新（アプリ本体だけを差し替える。Python・PyTorch はそのまま）。

  配る人   vc package --publish "変更点"（リポジトリから作るので Mac からでもよい）
           → 更新ファイル（tools/ など約9MB の zip）と latest.json を、itr-server（https://itoro.f5.si/voicechanger/）
             と、控えの GitHub の公開リポジトリ（updates ブランチ）に置く。latest.json は Ed25519 で署名し、zip の
             URL（と控えの URL）・sha256 と、入れ替えるもの（UPDATE_ITEMS）の一覧も入れる
  アプリ   起動したら裏で latest.json（BUILD-INFO の update_urls を順に。つながらなければ次）を取り、署名・版・
           runtime（torch・依存・RVC の版）を確かめる。新しければ窓で知らせ、「はい」で zip を取って（取れなければ
           控えから）sha256 を確かめ、読み込みが終わってから入れ替えて開き直す

**入れ替えるのはアプリ本体だけ。** 一覧は署名した latest.json にあり（フォルダの並びを変えても配った版が
付いてこられる）、アプリは触ってはいけないもの（is_safe_item: runtime・設定・ログ・モデル・update/）だけを持つ。
runtime が違う版（PyTorch を上げた等）は入れ替えられないので、新しい zip を受け取るよう知らせるだけ。

**署名を確かめる。** 公開鍵は tools/update-key.txt（vc_package.py が置く）。秘密鍵は配る人の PC にだけある
（置き場所のサーバーや GitHub のアカウントが乗っ取られても、偽の更新は受け付けない）。公開鍵か URL が無い版は
確かめない。

**前の版に戻せる**（vc_rollback.py）。入れ替える前に update/pending.json を置き、前のものを update/old/ に移す。
新しい版の窓が開いたら pending.json を消す（started）。開く前に落ちたら vc_gui.py か __main__.py が戻す。

インターネットに送るのは、latest.json と zip を取りに行く要求と、モデルの一覧・モデルを取りに行く要求（ID・パスワード
付き）だけ（声・モデル・設定は送らない）。

**声のモデルも配れる**（fetch_models・download_model。窓の「取ってくる…」）。鍵か覚えた ID・パスワードがあれば、
起動したときに裏で一覧を取り、手元に無いモデル・取ったモデルの新しい版を知らせる（model_news）。モデルは itr-server の認証付きの場所
（MODELS_URL。相手ごとの ID・パスワード）にだけ置き、公開の場所（認証の無い場所・GitHub）には置かない（声のモデルは
その人の声でなりすませる道具になるので）。一覧（models.json）は更新と同じ鍵で署名し、取ったファイルは大きさと sha256 を
確かめる。置くのは vc models（vc_models.py）。
HTTPS の相手は、Windows の証明書の一覧と、同梱した Mozilla の一覧（tools/cacert.pem。certifi のもの）の両方で
確かめる。Windows はルート証明書を必要になってから取りに行くので、手元の一覧に GitHub の発行元がまだ無い PC がある
（「CERTIFICATE_VERIFY_FAILED: unable to get issuer certificate」で確かめられなかった。2026-11-01）。
起動のたびに読むので、通信・zip・署名のライブラリは使うときに読み込む（窓が出るのを遅らせない）。
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path

import vc_rollback
from rvc_common import PROJECT_ROOT

APP = "VoiceChanger"
BUILD_INFO = "BUILD-INFO.json"
KEY_FILE = "tools/update-key.txt"
MANIFEST = "latest.json"
# 変わったら更新ファイルでは足りない（runtime ごと入れ直す）。vc_package.py の --update も同じものを比べる
RUNTIME_KEYS = ("torch", "requirements", "rvc")
# 本家のうち配布物に入れるコード（vc_package.py が写し、更新ファイルにも入れる）
RVC_DIRS = ["configs", "i18n", "infer"]
RVC_FILES = ["tools/cuda_graph.py", "tools/file_io.py"]
# 更新ファイルで入れ替えるもの（vc_package.py がこの一覧で zip を作り、latest.json にも書く）。フォルダは丸ごと。
# VoiceChanger.exe は入れ替えない。ネットから取った exe で自分を置き換えて起動するのは、Windows Defender に
# マルウェアの動きと見られて隔離されやすい（中身は起動の手順だけで、ほとんど変わらない。変えたら zip で配る）
# ライセンスは本文だけ入れ替える（同梱物の一覧 THIRD-PARTY.txt は受け取った人の runtime のものなので残す）
UPDATE_ITEMS = (["tools"] + [f"RVC/{d}" for d in RVC_DIRS]
                + sorted({f"RVC/{Path(f).parent.as_posix()}" for f in RVC_FILES})
                + ["debug.bat", "README.txt", BUILD_INFO, "models/README.txt",
                   "LICENSES/RVC-LICENSE.txt", "LICENSES/RVC-references.txt", "LICENSES/RFC8032-LICENSE.txt",
                   "LICENSES/certifi-LICENSE.txt", "LICENSES/DeepFilterNet-LICENSE.txt", "LICENSES/sv-ttk-LICENSE.txt"])
# 更新で触ってはいけないもの（Python・PyTorch、受け取った人の設定・ログ・モデル、更新の作業場所）
# 声のモデルの置き場所の鍵（ID・パスワード）。全部入りの zip（個別に渡すもの）にだけ入れる。更新ファイル・GitHub
# （誰でも取れる）には決して入れない（入れるとパスワードが公開されたのと同じになる）。自動更新では触らない
ACCESS_FILE = "model-access.json"
PROTECTED_TOP = {"runtime", vc_rollback.WORK_DIR, "settings.json", "settings.json.tmp", "log.txt", "log.prev.txt",
                 ACCESS_FILE}
MAX_SIZE = 64 * 1024 * 1024  # 更新ファイルは 10MB ほど（雑音除去の重みが 8MB）。これより大きいものは取らない
ROOT = PROJECT_ROOT  # 配布版のフォルダ（試すときは書き換える）
CA_FILE = Path(__file__).with_name("cacert.pem")  # 同梱する証明書の一覧（vc_package.py が certifi から写す）
# 声のモデルの置き場所（itr-server。nginx の Basic 認証で相手ごとの ID・パスワード）と一覧
MODELS_URL = "https://itoro.f5.si/voicechanger/models/"
MODELS_INDEX = "models.json"
MODEL_FILE_MAX = 2 * 1024 ** 3  # 1ファイルの上限（モデル 55MB ほど、index は数百 MB）
SOURCE_FILE = ".source.json"  # 取ったモデルのフォルダに置く、取ったファイルの sha256 の控え（新しい版があるかを見る）
SAFE_NAME = re.compile(r"[^\W.][\w.-]{0,63}")  # モデル名・ファイル名（パスの区切り・先頭の . を許さない）


@dataclass
class Update:
    version: str
    notes: str
    urls: list[str]  # 更新ファイルを取りに行く順（取れなければ次）
    size: int
    sha256: str
    items: list[str]
    needs_full: bool  # runtime が違う（zip を入れ直す必要がある）


def version_key(version: str) -> tuple:
    """版を比べる形に。1.0.57 → (1, 1, 0, 57)。前の形（作った日時 20261101.132922）は、番号の版より古い。"""
    v = str(version)
    if m := re.fullmatch(r"(\d+)\.(\d+)\.(\d+)", v):
        return (1, *map(int, m.groups()))
    if m := re.fullmatch(r"(\d{8})\.(\d{6})", v):
        return (0, int(m.group(1)), int(m.group(2)))
    return (0,)  # 開発中（1.0.57-dev）など


def label(version: str) -> str:
    """版を人が読む形に（1.0.57 はそのまま。前の形の 20261101.132922 は 2026-11-01 13:29）。"""
    v = str(version)
    if re.fullmatch(r"\d{8}\.\d{6}", v):
        return f"{v[:4]}-{v[4:6]}-{v[6:8]} {v[9:11]}:{v[11:13]}"
    return v or "?"


def canonical(payload: dict) -> bytes:
    """署名する並び（キーの順と空白を決めておき、作る側と確かめる側で同じバイト列にする）。"""
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sign_doc(payload: dict, secret: bytes) -> dict:
    """署名した文書（{"payload", "signature"}。latest.json・models.json の形）。秘密鍵は配る人の PC にだけある。"""
    import ed25519

    return {"payload": payload, "signature": ed25519.sign(secret, canonical(payload)).hex()}


def verify_doc(doc: dict, key: bytes, what: str) -> dict:
    """署名を確かめて payload を返す。合わなければ ValueError（what は知らせる文に使う）。"""
    import ed25519

    payload = doc["payload"]
    if not ed25519.verify(key, canonical(payload), bytes.fromhex(doc["signature"])):
        raise ValueError(f"{what}の署名が合いません（配った人が作ったものではない）")
    return payload


def read_build_info(root: Path | None = None) -> dict:
    """配布版を作ったときの情報（vc_package.py が BUILD-INFO.json に書く）。無い・壊れていれば {}。"""
    try:
        info = json.loads(((root or ROOT) / BUILD_INFO).read_text(encoding="utf-8"))
        return info if isinstance(info, dict) else {}
    except (OSError, ValueError):
        return {}


def current_label() -> str:
    return label(read_build_info().get("version", ""))


def is_safe_item(item: str) -> bool:
    """更新で入れ替えてよい場所か（区切りは /）。上に出る・絶対パス・触ってはいけないものは不可。

    Windows は大文字小文字を区別せず、名前の終わりの「.」と空白を落とす（Runtime/・runtime. も runtime）ので、
    そろえて比べ、終わりが「.」か空白の名前は受け付けない。
    """
    parts = item.split("/")
    if not item or item.startswith("/") or "\\" in item or ":" in item:
        return False
    if any(p in ("", ".", "..") or p[-1] in ". " for p in parts):
        return False
    top = parts[0].lower()
    if top in {x.lower() for x in PROTECTED_TOP}:
        return False
    return top != "models" or item.lower() == "models/readme.txt"


def within(name: str, items: list[str]) -> bool:
    """zip の中の名前が、入れ替えるもののどれかに入っているか。"""
    return any(name == x or name.startswith(x + "/") for x in items)


def open_url(url: str, timeout: float, auth: tuple[str, str] | None = None):
    """HTTPS で取りに行く。相手の証明書は Windows（OS）の一覧と、同梱の一覧（CA_FILE）の両方で確かめる。
    auth（ID, パスワード）は Basic 認証で送る（声のモデルの置き場所だけ）。

    同梱の一覧だけにしないのは、ウイルス対策ソフトが HTTPS を中継している PC では、そのソフトの証明書が OS の
    一覧にだけあるため。
    """
    import base64
    import ssl
    import urllib.error
    import urllib.request

    ctx = ssl.create_default_context()
    if CA_FILE.exists():
        ctx.load_verify_locations(cafile=str(CA_FILE))
    headers = {"User-Agent": f"{APP}-updater"}
    if auth is None:
        return urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=timeout, context=ctx)
    if not url.startswith("https://"):
        raise ValueError("パスワードは HTTPS でしか送りません")
    headers["Authorization"] = "Basic " + base64.b64encode(f"{auth[0]}:{auth[1]}".encode("utf-8")).decode("ascii")

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        """転送（3xx）に付いていかない（urllib は転送先にも Authorization を付け直す。別のホスト・http:// でも）。
        転送は HTTPError になる。"""

        def redirect_request(self, *args, **kwargs):
            return None

    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx), NoRedirect)
    try:
        return opener.open(urllib.request.Request(url, headers=headers), timeout=timeout)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):  # 一覧を取るときも、モデルを取るときも
            raise AuthError("ID かパスワードが違います（止められた可能性もあります）") from None
        raise


def check(timeout: float = 8) -> Update | None:
    """新しい版があれば Update、無ければ None。確かめられなければ例外（呼ぶ側はログに残すだけ）。

    更新情報は BUILD-INFO の update_urls を順に見て、最初に取れて署名の合ったものを使う（1.0 の版は update_url
    だけを持つ）。
    """
    import urllib.error

    info = read_build_info()
    urls, key = info.get("update_urls") or [info.get("update_url")], public_key()
    urls = [u for u in urls if u]
    if not urls or key is None:
        return None
    errors = []
    for url in urls:
        try:
            payload = fetch_manifest(url, key, timeout)
            break
        except Exception as e:
            if not (isinstance(e, urllib.error.HTTPError) and e.code == 404):  # 404 はまだ上げていない
                errors.append(e)
            print(f"更新情報を取れませんでした（{url}）: {type(e).__name__}: {e}", flush=True)
    else:
        if errors:
            raise errors[0]
        return None
    if payload.get("app") != APP:
        raise ValueError(f"別のアプリの更新情報です: {payload.get('app')}")
    if version_key(payload["version"]) <= version_key(info.get("version", "")):
        return None
    items = [str(x) for x in payload["items"]]
    if not items or not all(is_safe_item(x) for x in items):
        raise ValueError(f"更新情報の入れ替えるものが不正です: {items}")
    differ = {k: (info.get(k), payload["runtime"].get(k)) for k in RUNTIME_KEYS if payload["runtime"].get(k) != info.get(k)}
    if differ:  # 入れ直しを案内する理由をログに残す（今の版の値, 新しい版の値）
        print(f"新しい版（{payload['version']}）は runtime が違います: {differ}", flush=True)
    urls = [str(payload["url"])] + [str(u) for u in payload.get("mirrors", [])]
    return Update(version=str(payload["version"]), notes=str(payload.get("notes", "")), urls=urls,
                  size=int(payload["size"]), sha256=str(payload["sha256"]), items=items, needs_full=bool(differ))


def fetch_manifest(url: str, key: bytes, timeout: float, auth: tuple[str, str] | None = None,
                   what: str = "更新情報") -> dict:
    """署名した文書（latest.json・models.json）を取って署名を確かめ、中身（payload）を返す。"""
    if url.startswith("https://"):
        # 途中の配信サーバーが前の版を覚えていることがある（GitHub の releases/latest/download は、1.0.23 を
        # 上げた直後に 1.0.21 へ転送した）。毎回違う URL にして避ける
        url += ("&" if "?" in url else "?") + f"t={int(time.time())}"
    with open_url(url, timeout, auth) as r:
        doc = json.loads(r.read(1024 * 1024))
    return verify_doc(doc, key, what)


class AuthError(Exception):
    """声のモデルの置き場所の ID・パスワードが違う（または止められた）。"""


def builtin_access() -> tuple[str, str] | None:
    """アプリのフォルダの鍵ファイル（ACCESS_FILE）の (ID, パスワード)。無い・壊れていれば None（窓で入れてもらう）。"""
    try:
        d = json.loads((ROOT / ACCESS_FILE).read_text(encoding="utf-8"))
        user, password = str(d["user"]), str(d["password"])
    except (OSError, ValueError, KeyError, TypeError):
        return None
    return (user, password) if user and password else None


def model_auths(saved: tuple[str, str]) -> list[tuple[str, str]]:
    """声のモデルの置き場所に試す (ID, パスワード) の順: アプリの鍵 → この PC に覚えたもの（saved。両方あるときだけ）。"""
    return [a for a in (builtin_access(), saved) if a and all(a)]


def public_key() -> bytes | None:
    path = ROOT / KEY_FILE
    return bytes.fromhex(path.read_text(encoding="ascii").strip()) if path.exists() else None


def fetch_models(auth: tuple[str, str], timeout: float = 10) -> dict:
    """配っている声のモデルの一覧（モデル名 → {"note", "date", "files": [{"name", "size", "sha256"}]}）。
    auth は (ID, パスワード)。署名を確かめる。ID・パスワードが違えば AuthError。"""
    import urllib.error

    key = public_key()
    if key is None:
        raise ValueError(f"署名の公開鍵がありません（{KEY_FILE}）")
    try:
        payload = fetch_manifest(MODELS_URL + MODELS_INDEX, key, timeout, auth, "モデルの一覧")
    except urllib.error.HTTPError as e:  # ID・パスワードが違えば open_url が AuthError にする
        if e.code == 404:
            return {}  # まだ1つも置いていない
        raise
    if payload.get("app") != APP or payload.get("kind") != "models":
        raise ValueError("モデルの一覧ではありません")
    models = {}
    for name, entry in payload["models"].items():
        files = entry["files"]
        if not SAFE_NAME.fullmatch(name) or not files or not all(
                SAFE_NAME.fullmatch(f["name"]) and 0 < int(f["size"]) <= MODEL_FILE_MAX for f in files):
            raise ValueError(f"モデルの一覧が不正です: {name}")
        models[name] = entry
    return models


def fetch_models_any(auths: list[tuple[str, str]], timeout: float = 10) -> tuple[tuple[str, str], dict]:
    """auths（model_auths）を順に試して、最初に通った (ID, パスワード) と一覧を返す。どれも違えば最後の AuthError
    （呼ぶ側が知らせる。途中で次を試したものだけ、ここでログに残す）。"""
    for auth in auths[:-1]:
        try:
            return auth, fetch_models(auth, timeout)
        except AuthError as e:
            print(f"モデルの一覧を取れませんでした（ID {auth[0]}。次を試します）: {e}", flush=True)
    if not auths:
        raise AuthError("ID とパスワードがありません")
    return auths[-1], fetch_models(auths[-1], timeout)


def _source(folder: Path) -> dict:
    """取ったモデルのフォルダの控え（ファイル名 → sha256）。無い・壊れていれば空（自分で置いたもの）。"""
    try:
        return json.loads((folder / SOURCE_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _mine(folder: Path, entry: dict) -> bool:
    """同じ名前のファイルを、取ったのではなく自分で置いている（控えが無い）。取ると上書きしてしまう。"""
    return not _source(folder) and any((folder / f["name"]).exists() for f in entry["files"])


def model_state(name: str, entry: dict) -> str:
    """手元の様子: "new"（無い）・"same"（同じものを取ってある）・"changed"（新しい版がある）・"mine"（同じ名前の
    自分のモデルがある。上書きしないので取れない）。"""
    folder = ROOT / "models" / name
    if _mine(folder, entry):
        return "mine"
    source = _source(folder)
    if not source:  # まだ取っていない（フォルダが無い・取ったものではないファイルだけがある）
        return "new"
    want = model_files(entry)
    return "same" if source == want and all((folder / n).is_file() for n in want) else "changed"


def model_files(entry: dict) -> dict[str, str]:
    """一覧の1つのモデルのファイル（名前 → sha256）。モデルの版はこれで見分ける（取ったものの控え SOURCE_FILE も
    同じ形）。"""
    return {f["name"]: f["sha256"] for f in entry["files"]}


def model_version(entry: dict) -> str:
    """model_files を短くした版の印（置き直すと変わる）。どの版を一覧で見たか（知らせたか）を設定に覚えるのに使う。"""
    import hashlib

    return hashlib.sha256(json.dumps(model_files(entry), sort_keys=True).encode()).hexdigest()[:16]


def model_news(models: dict, seen: dict) -> dict[str, str]:
    """起動したときに知らせるモデル（名前 → "new" か "changed"）。手元に無いものと、取ったものの新しい版のうち、
    「取ってくる…」の一覧でまだ見ていない版（seen: 名前 → model_version）だけ（見たのに取らなかったものは、
    置き直されるまで知らせない）。"""
    news = {}
    for name, entry in models.items():
        if seen.get(name) == model_version(entry):
            continue
        state = model_state(name, entry)
        # "changed" でも、取ったファイルを消しただけ（置き直されていない）なら知らせない
        if state == "new" or state == "changed" and _source(ROOT / "models" / name) != model_files(entry):
            news[name] = state
    return news


def download_model(name: str, entry: dict, auth: tuple[str, str], progress=None) -> Path:
    """声のモデルを models/<名前>/ に取る（大きさと sha256 を確かめる）。前に取ったもの（SOURCE_FILE の一覧）は
    入れ替える。同じものを取ってあるファイル（.pth だけ置き直したときの index など）は取り直さない。取り終えたら、
    置いた .pth を返す。progress(取った, 全部) を呼ぶ。"""
    import shutil
    import urllib.parse

    if not SAFE_NAME.fullmatch(name):
        raise ValueError(f"モデル名が不正です: {name}")
    models = ROOT / "models"
    folder, work = models / name, models / f".{name}.download"
    if _mine(folder, entry):
        raise ValueError(f"models/{name}/ に同じ名前の自分のモデルがあります（上書きしません）。"
                         "そのフォルダの名前を変えてから取ってください")
    old = _source(folder)
    keep = {f["name"] for f in entry["files"] if old.get(f["name"]) == f["sha256"] and (folder / f["name"]).is_file()}
    todo = [f for f in entry["files"] if f["name"] not in keep]
    shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True)
    total, done = sum(int(f["size"]) for f in todo), 0
    # 取りかけは .part（窓やアプリが途中で閉じられて残っても、モデルの一覧に .pth として出ない）
    try:
        for f in todo:
            url = f"{MODELS_URL}{urllib.parse.quote(name)}/{urllib.parse.quote(f['name'])}"
            _fetch_file(url, work / f"{f['name']}.part", int(f["size"]), f["sha256"], f["name"], auth,
                        progress and (lambda got, _t, base=done: progress(base + got, total)))
            done += int(f["size"])
        # 前に取ったもの（控えにあるもの）のうち、入れ替える・要らなくなったものだけ消す（自分で置いたほかのファイルは残す）
        folder.mkdir(exist_ok=True)
        for n in old:
            if SAFE_NAME.fullmatch(n) and n not in keep:
                (folder / n).unlink(missing_ok=True)
        for f in todo:
            os.replace(work / f"{f['name']}.part", folder / f["name"])
        (folder / SOURCE_FILE).write_text(json.dumps(model_files(entry)), encoding="utf-8")
    finally:
        shutil.rmtree(work, ignore_errors=True)
    pths = [folder / f["name"] for f in entry["files"] if f["name"].endswith(".pth")]
    return pths[0] if pths else folder


def _fetch_file(url: str, part: Path, size: int, sha256: str, what: str, auth: tuple[str, str] | None = None,
                progress=None) -> None:
    """url を part に取る。大きさと sha256 を確かめ、違えば part を消して ValueError。progress(取った, 全部)。
    更新ファイルと声のモデルで使う（どちらも、署名した一覧にある大きさ・sha256 と比べる）。"""
    import hashlib

    h, done = hashlib.sha256(), 0
    if progress:
        progress(0, size)
    try:
        with open_url(url, 60, auth) as r, open(part, "wb") as f:
            while chunk := r.read(1024 * 1024):
                done += len(chunk)
                if done > size:
                    raise ValueError(f"{what}の大きさが違います")
                h.update(chunk)
                f.write(chunk)
                if progress:
                    progress(done, size)
        if done != size or h.hexdigest() != sha256:
            raise ValueError(f"{what}の中身が違います（途中で壊れたか、別のもの）")
    except BaseException:
        part.unlink(missing_ok=True)
        raise


def download(update: Update, progress=None) -> Path:
    """更新ファイルを update/ に取る。大きさと sha256（署名した latest.json に書いてある）を確かめる。

    update.urls を順に試す（置き場所のサーバーが止まっていたら控えから）。どれも駄目なら最初の失敗を投げる。
    """
    if update.size > MAX_SIZE:
        raise ValueError(f"更新ファイルが大きすぎます（{update.size} バイト）")
    errors = []
    for url in update.urls:
        try:
            return _download(url, update, progress)
        except Exception as e:
            print(f"更新ファイルを取れませんでした（{url}）: {type(e).__name__}: {e}", flush=True)
            errors.append(e)
    raise errors[0]


def _download(url: str, update: Update, progress) -> Path:
    work = ROOT / vc_rollback.WORK_DIR
    work.mkdir(exist_ok=True)
    dst, part = work / "download.zip", work / "download.zip.part"
    _fetch_file(url, part, update.size, update.sha256, "更新ファイル", progress=progress)
    os.replace(part, dst)
    return dst


def apply(zip_path: Path, update: Update) -> None:
    """更新ファイルの中身で入れ替える。前のものは update/old/ に移す（vc_rollback で戻せる）。

    実行中の VoiceChanger.exe も名前を変えて移せる（Windows は使用中の exe の削除・上書きはできないが、
    名前の変更はできる）。途中で失敗したら、それまでに入れ替えたものを戻してから例外を投げる。
    """
    import zipfile

    work = ROOT / vc_rollback.WORK_DIR
    new, old = work / "new", work / "old"
    for d in (new, old, work / "broken"):
        vc_rollback.clear(d)  # 前回の残り（前の版の控えは1つだけ持つ）
    with zipfile.ZipFile(zip_path) as z:
        for name in z.namelist():
            if not name.endswith("/") and not (is_safe_item(name) and within(name, update.items)):
                raise ValueError(f"更新ファイルに想定外のものがあります: {name}")
        z.extractall(new)
    info, current = read_build_info(new), read_build_info()
    if info.get("version") != update.version or any(info.get(k) != current.get(k) for k in RUNTIME_KEYS):
        raise ValueError("更新ファイルの版が、更新情報と合いません")
    if not (new / "tools" / "vc_gui.py").exists():
        raise ValueError("更新ファイルに tools/vc_gui.py がありません")
    items = [x for x in update.items if (new / x).exists()]
    added = [x for x in items if not (ROOT / x).exists()]  # 前の版に無いもの（戻すときは外す）
    # 入れ替える前に印を置く。途中で電源が落ちるなどしても、次に開いたときに戻せる（__main__.py が
    # vc_rollback.incomplete で見つけて戻す）
    (work / vc_rollback.PENDING).write_text(json.dumps(
        {"from": current.get("version", ""), "to": update.version, "items": items, "added": added},
        ensure_ascii=False), encoding="utf-8")
    done: list[str] = []
    try:
        for x in items:
            if (ROOT / x).exists():
                vc_rollback.move(ROOT / x, old / x)
            done.append(x)
            vc_rollback.move(new / x, ROOT / x)
    except BaseException:
        vc_rollback.rollback(ROOT, done, added)
        raise
    vc_rollback.clear(new)
    zip_path.unlink(missing_ok=True)


def rollback() -> bool:
    """更新した版が開けなかったので前の版に戻す。更新した直後でなければ何もしない（False）。"""
    return vc_rollback.rollback(ROOT)


def started() -> str | None:
    """更新した版の窓が開いた。控えの印を消して、更新前の版を返す（更新直後でなければ None）。

    入れ替えが途中で止まったまま（BUILD-INFO が新しい版になっていない）なら印は消さない。次に exe から
    開いたときに __main__.py が前の版に戻す（今動いているものはもう読み込んでいるので、ここでは動かさない）。
    """
    pending = vc_rollback.read_pending(ROOT)
    if pending is None:
        return None
    if vc_rollback.incomplete(ROOT):
        print("更新が途中で止まっています。次に開いたときに前の版に戻します", flush=True)
        return None
    (ROOT / vc_rollback.WORK_DIR / vc_rollback.PENDING).unlink(missing_ok=True)
    return str(pending.get("from", ""))


def restart() -> bool:
    """VoiceChanger.exe を開き直す（Windows の配布版だけ）。開けたら True（呼んだ側はすぐ終わる）。"""
    import subprocess

    exe = ROOT / f"{APP}.exe"
    if os.name != "nt" or not exe.exists():
        return False
    subprocess.Popen([str(exe), "--after-update"], cwd=ROOT, close_fds=True,
                     creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP)
    return True
