"""RVC（リアルタイム音声変換）用ツールの共通部分。

`vc` のコマンド（`./vc`・`vc.bat`）は **`RVC/.venv` の Python** で動く（`vc install` が作る）。

RVC 本体は相対パス（`assets/...`、`logs/...`）でモデルを読み、`configs.config.Config` は
起動時に sys.argv を argparse で読む。どちらも本家の WebUI 前提の作りなので、
RVC のモジュールを import する前に `enter_rvc()` を呼ぶこと。
"""

from __future__ import annotations

import math
import os
import re
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
RVC_ROOT = PROJECT_ROOT / "RVC"

# 動作確認した RVC 本家のコミット（2026-08-04、リリース 2.3.260718 の後）。
# `vc install`（シェル / バッチ）もこのファイルを読む。rtrvc.RVC の引数や train/*.py の
# argv の並びは版ごとに変わるので、上げるときは vc file で通しを確認してから書き換える。
RVC_COMMIT = (Path(__file__).resolve().parent / "rvc-version.txt").read_text().strip()

# 学習の設定。どのクライアント（本家 GUI / Applio / VCClient）でも読めるものに固定する。
SAMPLE_RATE = "40k"
VERSION = "v2"

GREEN, YELLOW, RED, DIM, BOLD, RESET = (
    "\033[32m", "\033[33m", "\033[31m", "\033[2m", "\033[1m", "\033[0m",
)

# 案内に出すコマンド名。cmd では `./vc` は動かない（vc.bat）
VC = "vc" if os.name == "nt" else "./vc"

# 渡す・配布版で使うモデルの置き場所（vc export がまとめる。窓もここを探す）。git 管理外
MODELS_DIR = PROJECT_ROOT / "models"


def rel_path(p: Path) -> str:
    """リポジトリ（配布版ならアプリのフォルダ）の中なら相対パスで。"""
    try:
        return str(p.relative_to(PROJECT_ROOT))
    except ValueError:
        return str(p)


def sha256_file(path: Path) -> str:
    """ファイルの sha256（大きなファイルも 1MB ずつ読む）。"""
    import hashlib

    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def fmt_secs(s: float) -> str:
    s = int(s)
    return f"{s // 60}:{s % 60:02d}" if s >= 60 else f"{s} 秒"


def enable_ansi() -> None:
    """Windows の古いコンソールでも、色や行の書き換え（\\x1b[K）が効くようにする。"""
    if os.name != "nt":
        return
    try:
        import ctypes

        k32 = ctypes.windll.kernel32
        h = k32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_uint32()
        if k32.GetConsoleMode(h, ctypes.byref(mode)):
            k32.SetConsoleMode(h, mode.value | 0x0004)  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
    except Exception:
        pass


def disable_quick_edit() -> None:
    """Windows のコンソールの「簡易編集モード」を、このプロセスの間だけ切る。

    有効なままだと、窓をクリックしただけで選択モードに入り、コンソールへの出力が全部止まる。
    本家は変換中も print するので、`vc` なら変換スレッドが止まって音が途切れ、`vc train` なら学習が
    止まる（Esc を押すまで）。終了時に元の設定へ戻す。Windows 以外とコンソールでないときは何もしない。
    """
    if os.name != "nt":
        return
    try:
        import atexit
        import ctypes

        k32 = ctypes.windll.kernel32
        h = k32.GetStdHandle(-10)  # STD_INPUT_HANDLE
        mode = ctypes.c_uint32()
        if not k32.GetConsoleMode(h, ctypes.byref(mode)):
            return
        ENABLE_QUICK_EDIT_MODE, ENABLE_EXTENDED_FLAGS = 0x0040, 0x0080
        k32.SetConsoleMode(h, (mode.value | ENABLE_EXTENDED_FLAGS) & ~ENABLE_QUICK_EDIT_MODE)
        atexit.register(k32.SetConsoleMode, h, mode.value)
    except Exception:
        pass


def enter_rvc() -> None:
    """RVC 本体を import できる状態にする（作業ディレクトリも移る）。

    呼ぶ前に、ユーザーが渡したパスは絶対パスにしておくこと。
    """
    if not (RVC_ROOT / "infer" / "rtrvc.py").exists():
        sys.exit(
            f"RVC 本体が見つかりません: {RVC_ROOT}\n"
            "docs/リアルタイム音声変換手順.md の「セットアップ」を見てください。"
        )
    os.chdir(RVC_ROOT)
    sys.path.insert(0, str(RVC_ROOT))
    os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
    # torch と faiss（と scikit-learn）がそれぞれ OpenMP を抱えていて、2つ目が初期化されるときに
    # 「OMP: Error #15 … already initialized」で落ちる。scikit-learn は import 時にこれを設定するので、
    # transformers（→ scikit-learn）を読んでいた頃は偶然避けられていた。transformers を使わない
    # HuBERT（rvc_hubert.py）にしたら Mac で落ちたので、明示する。faiss は1スレッドでしか使わない
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
    # Config が argparse で読むので、こちらの引数を見せない
    sys.argv = sys.argv[:1]


# 声の響き（フォルマント）は ±6 半音・0.5 刻みに収める。GPU では値ごとに変換の準備（CUDA Graph）を作り直す（本家は
# 8 個まで覚える）ので細かい値にしない。本家は 0 に近すぎる値（40k で 0.04 未満など）だと、伸ばして作った音を縮め忘れて
# 崩れる（rtrvc の upp_res が元のままになる）。0.5 刻みなら起きない
FORMANT_RANGE = 6.0
FORMANT_STEP = 0.5
# 抑揚（声の高さの上下の幅）は ×0.5〜×2.0・0.05 刻み（rvc_engine.Intonation）
INTONATION_RANGE = (0.5, 2.0)
INTONATION_STEP = 0.05


def snap(v, lo: float, hi: float, step: float) -> float:
    """v を step 刻みに丸めて（0 を中心に左右対称の四捨五入。-0.25 → -0.5、0.25 → 0.5）、lo〜hi に収める。
    lo・hi は step の倍数にしておく。数でない・inf・nan は ValueError。響き・抑揚と、窓の声の欄のスライダー
    （吸い付く位置と、使う・覚える値）はみなこれで丸める。"""
    v = float(v)
    if not math.isfinite(v):
        raise ValueError(f"数ではありません: {v}")
    # 1e-9 は小数の誤差の分（1.025 / 0.05 が 20.4999… になって切り捨てられないように）
    r = math.copysign(math.floor(abs(v) / step + 0.5 + 1e-9) * step, v)
    return round(min(hi, max(lo, r)), 6) + 0.0  # 小数の誤差を落とし、+ 0.0 で -0.0 を 0.0 に


def clamp_formant(v) -> float:
    return snap(v, -FORMANT_RANGE, FORMANT_RANGE, FORMANT_STEP)


def clamp_intonation(v) -> float:
    return snap(v, *INTONATION_RANGE, INTONATION_STEP)


def add_conversion_args(ap) -> None:
    """vc（マイク）と vc file（ファイル）で共通の変換設定。既定値は本家 realtime_gui.py に合わせる。

    vc file で決めた値をそのまま vc に渡せば同じ音になる。
    """
    ap.add_argument("--model-name", required=True)
    ap.add_argument("--epoch", type=int, help="途中のエポックのモデルを使う（既定: 最終版）")
    g = ap.add_argument_group("変換の設定")
    g.add_argument("--pitch", type=float, default=0.0,
                   help="音の高さを半音単位でずらす（既定: 0。男性→女性なら +12 前後）")
    g.add_argument("--formant", type=float, default=0.0,
                   help="声の響き（フォルマント）を半音単位でずらす。高さはそのまま（既定: 0。男性→女性で声が太い・"
                        "大人っぽいなら +1〜+3）。±6・0.5 刻みに丸める")
    g.add_argument("--intonation", type=float, default=1.0,
                   help="抑揚（声の高さの上下の幅）を何倍にするか（既定: 1.0 で入力どおり。女性らしい話し方に寄せるなら "
                        "1.1〜1.3。上げすぎると歌うような声に、下げると平板な声に）。0.5〜2.0・0.05 刻みに丸める")
    g.add_argument("--index-rate", type=float, default=0.5,
                   help="学習データの特徴量にどれだけ寄せるか 0〜1（既定: 0.5。上げると似るが滑舌が落ちやすい）")
    g.add_argument("--rms-mix", type=float, default=0.0,
                   help="音量の起伏 0〜1。0 で入力どおり、1 でモデルの出力のまま（既定: 0）")
    g.add_argument("--threshold", type=float, default=-60.0,
                   help="これより小さい音（dB）を無音にする。-60 で無効（既定）。息やキーボード音が"
                        "変換されるなら -45 前後に上げる")
    g.add_argument("--f0", choices=("rmvpe", "fcpe", "pm"), default="rmvpe",
                   help="音の高さの推定方法（既定: rmvpe）")
    g.add_argument("--denoise", action="store_true",
                   help="雑音（キーボード・クリック・ファンなど）を消してから変換する（DeepFilterNet3。CPU で動く）")
    g = ap.add_argument_group("遅延と品質の兼ね合い")
    g.add_argument("--block-ms", type=float, default=200.0,
                   help="1回に変換する長さ（既定: 200）。小さいほど遅延が減るが、処理が間に合わないと途切れる")
    g.add_argument("--crossfade-ms", type=float, default=50.0,
                   help="ブロックのつなぎ目を重ねる長さ（既定: 50。実際は最大 40ms）")
    g.add_argument("--extra-ms", type=float, default=2500.0,
                   help="変換時に見る過去の音声の長さ（既定: 2500）。長いほど安定するが処理が重い")


def conversion_options(args) -> dict:
    """StreamEngine.process に渡すキーワード引数。"""
    return dict(pitch=args.pitch, formant=clamp_formant(args.formant), intonation=clamp_intonation(args.intonation),
                index_rate=args.index_rate, rms_mix=args.rms_mix,
                threshold_db=args.threshold, f0_method=args.f0)


WEIGHTS_DIR = RVC_ROOT / "assets" / "weights"
LOGS_DIR = RVC_ROOT / "logs"  # 学習の途中生成物・学習再開用・index・TensorBoard のログ（logs/<名前>/）
# 学習途中の推論用モデルの名前の終わり（<名前>_e<エポック>_s<ステップ>）
CHECKPOINT_SUFFIX = re.compile(r"_e(\d+)_s\d+$")


def model_base(p: Path) -> str:
    """モデルの名前。途中のモデル（<名前>_e20_s1234）も <名前> にする。"""
    return CHECKPOINT_SUFFIX.sub("", p.stem)


def checkpoint_epoch(p: Path) -> int | None:
    """途中のモデルならエポック、最終版なら None。"""
    m = CHECKPOINT_SUFFIX.search(p.stem)
    return int(m.group(1)) if m else None


def checkpoints(name: str) -> list[Path]:
    """学習途中の推論用モデル `<名前>_e<エポック>_s<ステップ>.pth` を、ステップ順に。

    glob の `<名前>_e*_s*.pth` は使わない。名前が taro のとき、別モデル
    taro_extra の `taro_extra_e10_s100.pth` まで拾ってしまう。
    """
    pat = re.compile(rf"{re.escape(name)}_e(\d+)_s(\d+)\.pth")
    hits = [(int(m.group(2)), p) for p in WEIGHTS_DIR.glob("*.pth") if (m := pat.fullmatch(p.name))]
    return [p for _, p in sorted(hits)]


def find_model(name: str, epoch: int | None = None) -> Path:
    """学習済みの推論用モデル（`assets/weights/<名前>*.pth`）を探す。

    学習中は `<名前>_e<エポック>_s<ステップ>.pth` が増えていき、学習が最後まで
    終わると `<名前>.pth` ができる。指定が無ければ最終版、無ければ最新のものを使う。
    """
    if epoch is not None:
        hits = [p for p in checkpoints(name) if p.name.startswith(f"{name}_e{epoch}_s")]
        if not hits:
            sys.exit(f"{name} の {epoch} エポックのモデルがありません（{WEIGHTS_DIR}）")
        return hits[0]
    final = WEIGHTS_DIR / f"{name}.pth"
    if final.exists():
        return final
    ckpts = checkpoints(name)
    if not ckpts:
        sys.exit(
            f"モデル {name} が見つかりません（{WEIGHTS_DIR}）\n"
            f"先に {VC} train --model-name {name} で学習してください。"
        )
    return ckpts[-1]


def all_models(name: str) -> list[Path]:
    """途中のモデル（ステップ順）と最終版。どれも無ければ find_model と同じく知らせて終わる。"""
    models = checkpoints(name)
    if (WEIGHTS_DIR / f"{name}.pth").exists():
        models.append(WEIGHTS_DIR / f"{name}.pth")
    if not models:
        find_model(name)
    return models


def find_index(name: str) -> Path | None:
    """検索用 index（`logs/<名前>/added_*.index`）。無ければ None。

    `trained_*.index` は中身が空の途中生成物で、渡すと検索が効かない。
    """
    hits = sorted(
        (LOGS_DIR / name).glob("added_*.index"),
        key=lambda p: p.stat().st_mtime,
    )
    return hits[-1] if hits else None
