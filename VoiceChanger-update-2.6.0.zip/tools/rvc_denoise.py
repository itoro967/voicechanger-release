"""雑音を消す（DeepFilterNet3。キーボード・クリック・物音・ファン・エアコンなど）。

DeepFilterNet（https://github.com/Rikorose/DeepFilterNet 、MIT / Apache-2.0）の DeepFilterNet3 を、
本家の Python パッケージを使わずに PyTorch だけで動かす。本家の部品（DeepFilterLib）は Rust 製で
2023 年から更新が無く、配布版の Python 3.12 用が無い（新しいライブラリを足すと、配った人が zip を
入れ直すことになる）ため、特徴量の計算（libDF の STFT・ERB・正規化）と、流しながら処理する形の
モデルの計算をここに写した。重み（dfn3/DeepFilterNet3.npz）は本家の models/DeepFilterNet3.zip の
checkpoints/model_120.ckpt.best を、convert() で numpy の形にしたもの。

  48kHz・モノラルのみ。0.01 秒（HOP）単位で、渡した長さの音を同じ長さで返す。
  返す音は入力より DELAY（30ms）遅れる（STFT の 10ms + モデルの先読み 20ms）。

モデルの中の時間方向の畳み込みは、前のブロックの末尾を足して計算し、GRU の状態も持ち越すので、
ブロックの切れ目で音は変わらない（全体を一度に通した本家の enhance() と同じ結果になる。確かめ方は
docs/リアルタイム音声変換手順.md の「追記: 開いたらすぐ地声…」）。

CPU で動かす（0.2 秒の音を数 ms。GPU は RVC が使うので取り合わない。CUDA の初期化も要らない）。
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import torch
from torch import nn

from rvc_realtime import DENOISE_DELAY, SAMPLE_RATE

WEIGHTS = Path(__file__).resolve().parent / "dfn3" / "DeepFilterNet3.npz"
FFT_SIZE, HOP = 960, 480
NB_ERB, NB_DF = 32, 96
DF_ORDER, LOOKAHEAD = 5, 2  # 低い帯域（NB_DF）は前後 2 フレームずつ、計 5 フレームを重ねて直す
ALPHA = 0.99  # 特徴量の正規化の時定数（本家 get_norm_alpha(): exp(-HOP / SR / 1 秒) を 3 桁に丸めた値）
DELAY = FFT_SIZE - HOP + LOOKAHEAD * HOP
assert DELAY == DENOISE_DELAY and SAMPLE_RATE == 48000  # rvc_realtime（torch を読まない）が持つ値と同じ
MEAN_NORM_INIT, UNIT_NORM_INIT = (-60.0, -90.0), (0.001, 0.0001)


def conv_norm_act(in_ch: int, out_ch: int, kernel: tuple[int, int], fstride: int = 1,
                  act=nn.ReLU, transposed: bool = False) -> nn.Sequential:
    """本家の Conv2dNormAct / ConvTranspose2dNormAct（separable=True, bias=False）と同じ並び。

    時間方向の詰め物（本家の先頭の ConstantPad2d）の代わりに、呼ぶ側が前のブロックの末尾を
    足して渡す。重みの名前（添字）をそろえるため、時間の窓が 2 以上なら先頭に Identity を置く。
    """
    kt, kf = kernel
    layers: list[nn.Module] = [nn.Identity()] if kt > 1 else []
    groups = math.gcd(in_ch, out_ch)
    if transposed:
        layers.append(nn.ConvTranspose2d(in_ch, out_ch, kernel, padding=(kt - 1, kf // 2),
                                         output_padding=(0, kf // 2), stride=(1, fstride),
                                         groups=groups, bias=False))
    else:
        layers.append(nn.Conv2d(in_ch, out_ch, kernel, padding=(0, kf // 2), stride=(1, fstride),
                                groups=groups, bias=False))
    if groups > 1 and max(kernel) > 1:
        layers.append(nn.Conv2d(out_ch, out_ch, 1, bias=False))
    layers += [nn.BatchNorm2d(out_ch), act()]
    return nn.Sequential(*layers)


class GroupedLinear(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, groups: int):
        super().__init__()
        self.groups = groups
        self.weight = nn.Parameter(torch.zeros(groups, input_size // groups, hidden_size // groups))

    def forward(self, x):
        b, t, _ = x.shape
        x = torch.einsum("btgi,gih->btgh", x.view(b, t, self.groups, -1), self.weight)
        return x.flatten(2, 3)


class SqueezedGRU(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, output_size: int | None, num_layers: int, groups: int):
        super().__init__()
        self.linear_in = nn.Sequential(GroupedLinear(input_size, hidden_size, groups), nn.ReLU())
        self.gru = nn.GRU(hidden_size, hidden_size, num_layers=num_layers, batch_first=True)
        self.linear_out = (nn.Sequential(GroupedLinear(hidden_size, output_size, groups), nn.ReLU())
                           if output_size else nn.Identity())

    def forward(self, x, h):
        x, h = self.gru(self.linear_in(x), h)
        return self.linear_out(x), h


class Encoder(nn.Module):
    def __init__(self):
        super().__init__()
        ch = 64
        self.erb_conv0 = conv_norm_act(1, ch, (3, 3))
        self.erb_conv1 = conv_norm_act(ch, ch, (1, 3), fstride=2)
        self.erb_conv2 = conv_norm_act(ch, ch, (1, 3), fstride=2)
        self.erb_conv3 = conv_norm_act(ch, ch, (1, 3))
        self.df_conv0 = conv_norm_act(2, ch, (3, 3))
        self.df_conv1 = conv_norm_act(ch, ch, (1, 3), fstride=2)
        emb = ch * NB_ERB // 4
        self.df_fc_emb = nn.Sequential(GroupedLinear(ch * NB_DF // 2, emb, 32), nn.ReLU())
        self.emb_gru = SqueezedGRU(emb, 256, emb, 1, 16)
        self.lsnr_fc = nn.Sequential(nn.Linear(emb, 1), nn.Sigmoid())  # 使わない（重みの名前をそろえるため）


class ErbDecoder(nn.Module):
    def __init__(self):
        super().__init__()
        ch = 64
        emb = ch * NB_ERB // 4
        self.emb_gru = SqueezedGRU(emb, 256, emb, 2, 16)
        self.conv3p = conv_norm_act(ch, ch, (1, 1))
        self.convt3 = conv_norm_act(ch, ch, (1, 3))
        self.conv2p = conv_norm_act(ch, ch, (1, 1))
        self.convt2 = conv_norm_act(ch, ch, (1, 3), fstride=2, transposed=True)
        self.conv1p = conv_norm_act(ch, ch, (1, 1))
        self.convt1 = conv_norm_act(ch, ch, (1, 3), fstride=2, transposed=True)
        self.conv0p = conv_norm_act(ch, ch, (1, 1))
        self.conv0_out = conv_norm_act(ch, 1, (1, 3), act=nn.Sigmoid)


class DfDecoder(nn.Module):
    def __init__(self):
        super().__init__()
        emb = 64 * NB_ERB // 4
        self.df_convp = conv_norm_act(64, DF_ORDER * 2, (5, 1))
        self.df_gru = SqueezedGRU(emb, 256, None, 2, 8)
        self.df_skip = GroupedLinear(emb, 256, 16)
        self.df_out = nn.Sequential(GroupedLinear(256, NB_DF * DF_ORDER * 2, 16), nn.Tanh())
        self.df_fc_a = nn.Sequential(nn.Linear(256, 1), nn.Sigmoid())  # 使わない


class _Mask(nn.Module):
    def __init__(self):
        super().__init__()
        self.register_buffer("erb_inv_fb", torch.zeros(NB_ERB, FFT_SIZE // 2 + 1))


class DfNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.register_buffer("erb_fb", torch.zeros(FFT_SIZE // 2 + 1, NB_ERB))
        self.enc = Encoder()
        self.erb_dec = ErbDecoder()
        self.mask = _Mask()
        self.df_dec = DfDecoder()


def convert(ckpt: Path, out: Path = WEIGHTS) -> None:
    """本家の重み（model_120.ckpt.best）を numpy の形で保存する（読むのに pickle を使わないため）。"""
    sd = torch.load(ckpt, map_location="cpu", weights_only=True)
    out.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out, **{k: v.numpy() for k, v in sd.items()})


def load_model() -> DfNet:
    model = DfNet()
    with np.load(WEIGHTS, allow_pickle=False) as z:
        model.load_state_dict({k: torch.from_numpy(z[k]) for k in z.files}, strict=True)
    return model.eval()


def denoise(audio: np.ndarray) -> np.ndarray:
    """録音全体の雑音を消す。48kHz・モノラル。同じ長さ・同じ時刻で返す（DELAY の遅れを詰める）。"""
    d = Denoiser()
    n = len(audio)
    x = np.concatenate([np.asarray(audio, dtype=np.float32),
                        np.zeros(DELAY + (-(n + DELAY)) % HOP, dtype=np.float32)])
    chunk = 100 * HOP
    return np.concatenate([d.process(x[i:i + chunk]) for i in range(0, len(x), chunk)])[DELAY:DELAY + n]


class Denoiser:
    """流しながら雑音を消す（消せるだけ消す。本家の既定）。process() に HOP の倍数の長さの音（48kHz・
    モノラル・float32）を渡す。model を渡すと使い回す（重みは状態を持たない。状態はこのオブジェクトが持つ）。"""

    def __init__(self, model: DfNet | None = None):
        self.model = model if model is not None else load_model()
        n = torch.arange(FFT_SIZE, dtype=torch.float64)
        # Vorbis の窓（libDF と同じ）。50% 重ねると 2 乗の和が 1 になる
        self.window = torch.sin(0.5 * math.pi * torch.sin(math.pi * (n + 0.5) / FFT_SIZE) ** 2).float()
        self._decay: dict[int, tuple] = {}
        self.reset()

    def reset(self) -> None:
        z = torch.zeros
        self.ana_mem = z(FFT_SIZE - HOP)
        self.syn_mem = z(FFT_SIZE - HOP)
        self.erb_state = torch.linspace(*MEAN_NORM_INIT, NB_ERB)
        self.unit_state = torch.linspace(*UNIT_NORM_INIT, NB_DF)
        self.spec_ctx = z(DF_ORDER - 1, FFT_SIZE // 2 + 1, dtype=torch.complex64)
        self.ctx_erb = z(1, 1, 2, NB_ERB)
        self.ctx_spec = z(1, 2, 2, NB_DF)
        self.ctx_c0 = z(1, 64, 4, NB_DF)
        self.h_enc = self.h_erb = self.h_df = None
        # 本家は特徴量を LOOKAHEAD フレーム先にずらしてモデルに通すので、最初の 2 フレームはモデルに入らない
        self.skip = LOOKAHEAD

    def _ema(self, x, state):
        """state を初期値に、s_t = ALPHA s_{t-1} + (1 - ALPHA) x_t を時間（0 次元）方向に。(全ての s, 最後の s)"""
        t = x.shape[0]
        if t not in self._decay:
            i = torch.arange(t, dtype=torch.float64)
            d = i[:, None] - i[None, :]
            lower = torch.where(d >= 0, ALPHA ** d.clamp_min(0), torch.zeros(()))
            self._decay[t] = ((1 - ALPHA) * lower).float(), (ALPHA ** (i + 1)).float()
        mat, pw = self._decay[t]
        s = mat @ x + pw[:, None] * state[None, :]
        return s, s[-1]

    @torch.inference_mode()
    def process(self, audio: np.ndarray) -> np.ndarray:
        if len(audio) % HOP:
            raise ValueError(f"長さは {HOP} の倍数にしてください: {len(audio)}")
        x = torch.from_numpy(np.asarray(audio, dtype=np.float32))
        t = len(audio) // HOP
        buf = torch.cat([self.ana_mem, x])
        self.ana_mem = buf[-(FFT_SIZE - HOP):]
        frames = buf.unfold(0, FFT_SIZE, HOP) * self.window
        spec = torch.fft.rfft(frames) / FFT_SIZE  # libDF と同じ大きさ（分析側だけで割る）

        # 特徴量（libDF の feat_erb・feat_cplx）
        m = self.model
        erb = 10 * torch.log10((spec.real ** 2 + spec.imag ** 2) @ m.erb_fb + 1e-10)
        s, self.erb_state = self._ema(erb, self.erb_state)
        feat_erb = ((erb - s) / 40).view(1, 1, t, NB_ERB)
        low = spec[:, :NB_DF]
        s, self.unit_state = self._ema(low.abs(), self.unit_state)
        low = low / s.sqrt()
        feat_spec = torch.stack([low.real, low.imag]).unsqueeze(0)  # [1, 2, T, F]

        k = min(self.skip, t)
        self.skip -= k
        gains, coefs = self._model(feat_erb[:, :, k:], feat_spec[:, :, k:])
        if k:  # 最初の 2 フレーム（真ん中のフレームはまだ無音）
            gains = torch.cat([gains.new_zeros(k, gains.shape[1]), gains])
            coefs = torch.cat([coefs.new_zeros(k, *coefs.shape[1:]), coefs])

        ext = torch.cat([self.spec_ctx, spec])  # 直す対象は LOOKAHEAD フレーム前（先の 2 フレームも使う）
        self.spec_ctx = ext[-(DF_ORDER - 1):]
        center = ext[LOOKAHEAD:LOOKAHEAD + t]
        out = center * gains
        win = ext[:, :NB_DF].unfold(0, DF_ORDER, 1)  # [T, F, O]
        out[:, :NB_DF] = (win * coefs).sum(-1)

        y = torch.fft.irfft(out, n=FFT_SIZE) * FFT_SIZE * self.window
        res = y[:, :HOP].clone()
        res[0] += self.syn_mem
        res[1:] += y[:-1, HOP:]
        self.syn_mem = y[-1, HOP:]
        return res.reshape(-1).numpy()

    def _model(self, feat_erb, feat_spec):
        """モデルを T フレーム分進める。(ERB の帯域ごとの倍率を全帯域に広げたもの [T, 481],
        低い帯域を直す係数 [T, NB_DF, DF_ORDER]（複素数）)"""
        t = feat_erb.shape[2]
        if t == 0:
            return feat_erb.new_zeros(0, FFT_SIZE // 2 + 1), feat_erb.new_zeros(0, NB_DF, DF_ORDER, dtype=torch.complex64)
        enc, dec, dfd = self.model.enc, self.model.erb_dec, self.model.df_dec
        x = torch.cat([self.ctx_erb, feat_erb], 2)
        self.ctx_erb = x[:, :, -2:]
        e0 = enc.erb_conv0[1:](x)
        e1 = enc.erb_conv1(e0)
        e2 = enc.erb_conv2(e1)
        e3 = enc.erb_conv3(e2)
        x = torch.cat([self.ctx_spec, feat_spec], 2)
        self.ctx_spec = x[:, :, -2:]
        c0 = enc.df_conv0[1:](x)
        c1 = enc.df_conv1(c0)
        emb = e3.permute(0, 2, 3, 1).flatten(2) + enc.df_fc_emb(c1.permute(0, 2, 3, 1).flatten(2))
        emb, self.h_enc = enc.emb_gru(emb, self.h_enc)

        e, self.h_erb = dec.emb_gru(emb, self.h_erb)
        e = e.view(1, t, e3.shape[3], -1).permute(0, 3, 1, 2)
        e3 = dec.convt3(dec.conv3p(e3) + e)
        e2 = dec.convt2(dec.conv2p(e2) + e3)
        e1 = dec.convt1(dec.conv1p(e1) + e2)
        mask = dec.conv0_out(dec.conv0p(e0) + e1)[0, 0]  # [T, NB_ERB]

        c, self.h_df = dfd.df_gru(emb, self.h_df)
        c = c + dfd.df_skip(emb)
        x = torch.cat([self.ctx_c0, c0], 2)
        self.ctx_c0 = x[:, :, -4:]
        c = dfd.df_out(c).view(1, t, NB_DF, -1) + dfd.df_convp[1:](x).permute(0, 2, 3, 1)
        coefs = torch.view_as_complex(c[0].view(t, NB_DF, DF_ORDER, 2).contiguous())
        return mask @ self.model.mask.erb_inv_fb, coefs
