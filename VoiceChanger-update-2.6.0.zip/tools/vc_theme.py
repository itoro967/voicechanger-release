"""窓の見た目（暗い色のテーマ）と、窓で使う部品。vc_gui.py が使う。

テーマは Sun Valley（sv_ttk/。https://github.com/rdbende/Sun-Valley-ttk-theme の 2.6.1、MIT。Windows 11 の
見た目）。pip の sv-ttk は Python から sv.tcl を読むだけなので、Tcl と画像をそのまま同梱して読む（新しい
ライブラリを足すと、配った人が zip を入れ直すことになるため）。文字は日本語の UI 用の書体にそろえる
（テーマの既定の Segoe UI には日本語が無く、混ざると高さがそろわない）。

標準の messagebox は Windows の明るい窓になるので、確認・お知らせの窓も自前で描く（ask・show）。
ファイルを選ぶ窓（filedialog）だけは Windows の標準のまま。
"""

from __future__ import annotations

import os
import time
import tkinter as tk
import traceback
from pathlib import Path
from tkinter import font as tkfont
from tkinter import ttk

THEME = Path(__file__).resolve().parent / "sv_ttk" / "sv.tcl"
# 色（Sun Valley の暗い色に合わせる）
BG = "#1c1c1c"
FG = "#fafafa"
DIM = "#9d9d9d"
TRACK = "#2d2d2d"
ACCENT = "#57c8ff"
GREEN = "#3fb950"
YELLOW = "#e3b341"
RED = "#f85149"
GRAY = "#4a4a4a"
DISABLED = "#333333"
ON_FG = "#000000"  # 明るい色のボタンの文字
STATE_COLORS = {"info": DIM, "ok": GREEN, "warn": YELLOW, "error": RED}
FONT_FAMILIES = ("Yu Gothic UI", "Meiryo UI", "Hiragino Sans", "Noto Sans CJK JP")


def ui_scale(widget) -> float:
    """ピクセルで決めた大きさに掛ける倍率（Windows の表示スケール 150% など。文字は Tk が大きくする）。"""
    return max(1.0, widget.winfo_fpixels("1i") / 96) if os.name == "nt" else 1.0


def apply(root: tk.Tk) -> None:
    """暗い色のテーマを付ける。読めなければ標準の見た目のまま（文字の設定と窓は同じように使える）。"""
    try:
        root.tk.call("source", str(THEME))
        ttk.Style(root).theme_use("sun-valley-dark")
    except tk.TclError:
        traceback.print_exc()
    family = next((f for f in FONT_FAMILIES if f in tkfont.families(root)), None)
    # 大きさは pt で（テーマの既定は px なので、Windows の表示スケール 150% などで小さくなる）。テーマを
    # 読めなかったときは、窓が使う名前の文字の設定をここで作る
    for name, size, weight in (("SunValleyCaptionFont", 9, "normal"), ("SunValleyBodyFont", 10, "normal"),
                               ("SunValleyBodyStrongFont", 10, "bold"), ("SunValleyBodyLargeFont", 12, "normal"),
                               ("SunValleySubtitleFont", 14, "bold"), ("SunValleyTitleFont", 18, "bold"),
                               ("TkDefaultFont", 10, "normal"), ("TkTextFont", 10, "normal")):
        if name not in tkfont.names(root):
            # Font(exists=False) で作ると、その Python のオブジェクトが消えたときに文字の設定ごと消える
            root.tk.call("font", "create", name)
        tkfont.nametofont(name, root=root).configure(size=size, weight=weight,
                                                     **({"family": family} if family else {}))
    style = ttk.Style(root)
    style.configure("Dim.TLabel", foreground=DIM)
    style.configure("Caption.TLabel", foreground=DIM, font="SunValleyCaptionFont")
    style.configure("Section.TLabel", font="SunValleyBodyStrongFont")
    style.configure("Status.TLabel", font="SunValleySubtitleFont")
    root.configure(bg=BG)


def dark_title_bar(win) -> None:
    """Windows のタイトルバーも暗くする（Windows 10 の 2004 以降・11。それより前は何も起きない）。

    窓を表示してから呼ぶこと（Windows の Tk は、最初に表示するまでタイトルバーの付いた枠の窓を作らない）。
    """
    if os.name != "nt":
        return
    try:
        import ctypes

        win.update_idletasks()
        user32 = ctypes.windll.user32
        hwnd = user32.GetParent(win.winfo_id())
        on = ctypes.c_int(1)
        for attr in (20, 19):  # DWMWA_USE_IMMERSIVE_DARK_MODE（2004 より前の版は 19）
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(on), ctypes.sizeof(on)) == 0:
                break
        color = ctypes.c_int(int(BG[5:7] + BG[3:5] + BG[1:3], 16))  # COLORREF は 0x00BBGGRR
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(color), ctypes.sizeof(color))  # 11 のみ
        # 表示中の枠を描き直させる（SWP_NOSIZE | NOMOVE | NOZORDER | NOACTIVATE | FRAMECHANGED）
        user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0004 | 0x0010 | 0x0020)
    except Exception:
        traceback.print_exc()


def _shade(color: str, k: float) -> str:
    r, g, b = (int(color[i:i + 2], 16) for i in (1, 3, 5))
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(c + (255 - c) * k if k > 0 else c * (1 + k)))) for c in (r, g, b))


class PillButton(tk.Canvas):
    """角の丸い大きなボタン。色で状態を表す（ttk のボタンは色を変えにくいので Canvas で描く）。"""

    def __init__(self, master, width: int, height: int, command):
        super().__init__(master, width=width, height=height, bg=BG, highlightthickness=0, bd=0)
        self.command = command
        self.text, self.color, self.fg, self.enabled, self.hover = "", GRAY, FG, True, False
        self.bind("<Enter>", lambda e: self._hover(True))
        self.bind("<Leave>", lambda e: self._hover(False))
        self.bind("<ButtonRelease-1>", self._click)

    def set(self, text: str, color: str, fg: str = FG, enabled: bool = True) -> None:
        if (text, color, fg, enabled) != (self.text, self.color, self.fg, self.enabled):
            self.text, self.color, self.fg, self.enabled = text, color, fg, enabled
            self.configure(cursor="hand2" if enabled else "")
            self._draw()

    def _hover(self, on: bool) -> None:
        self.hover = on
        self._draw()

    def _click(self, e) -> None:
        if self.enabled and 0 <= e.x < self.winfo_width() and 0 <= e.y < self.winfo_height():
            self.command()

    def _draw(self) -> None:
        self.delete("all")
        w, h = int(self["width"]), int(self["height"])
        r = min(h // 2, max(6, h // 4))
        fill = (_shade(self.color, 0.15) if self.hover else self.color) if self.enabled else DISABLED
        for x0, y0 in ((0, 0), (w - 2 * r, 0), (0, h - 2 * r), (w - 2 * r, h - 2 * r)):
            self.create_oval(x0, y0, x0 + 2 * r, y0 + 2 * r, fill=fill, outline=fill)
        self.create_rectangle(r, 0, w - r, h, fill=fill, outline=fill)
        self.create_rectangle(0, r, w, h - r, fill=fill, outline=fill)
        self.create_text(w // 2, h // 2, text=self.text, font="SunValleyBodyStrongFont",
                         fill=self.fg if self.enabled else "#8a8a8a")


class Dot(tk.Canvas):
    def __init__(self, master, size: int):
        super().__init__(master, width=size, height=size, bg=BG, highlightthickness=0, bd=0)
        self.size, self.color = size, ""

    def set(self, color: str) -> None:
        if color != self.color:
            self.color = color
            self.delete("all")
            self.create_oval(1, 1, self.size - 1, self.size - 1, fill=color, outline=color)


class HelpIcon(tk.Canvas):
    """丸の中の「?」。マウスを乗せると説明（text）を出し、離すと消す。"""

    TIP_BG = "#2b2b2b"

    def __init__(self, master, text: str, size: int):
        super().__init__(master, width=size, height=size, bg=BG, highlightthickness=0, bd=0)
        self.text, self.tip = text, None
        self.create_oval(1, 1, size - 1, size - 1, outline=DIM)
        self.create_text(size / 2, size / 2, text="?", fill=DIM, font="SunValleyCaptionFont")
        try:
            self.configure(cursor="question_arrow")
        except tk.TclError:
            pass
        self.bind("<Enter>", self._show)
        self.bind("<Leave>", self._hide)

    def _show(self, e) -> None:
        if self.tip is not None:
            return
        tip = tk.Toplevel(self)
        tip.withdraw()  # 位置を決めてから出す（決める前に画面の隅に一瞬出ないように）
        tip.wm_overrideredirect(True)
        try:
            tip.attributes("-topmost", True)  # 窓の後ろに隠れないように
        except tk.TclError:
            pass
        tk.Label(tip, text=self.text, justify="left", wraplength=int(340 * ui_scale(self)), bg=self.TIP_BG, fg=FG,
                 font="SunValleyCaptionFont", padx=10, pady=7, highlightthickness=1,
                 highlightbackground=GRAY).pack()
        tip.update_idletasks()
        # マウスの右下に出す。窓の右・下からはみ出すなら、マウスの左・上へ（画面の大きさは主モニタのものしか
        # 分からないので、窓を基準にする。別のモニタに窓があっても、その中に出る）
        w, h = tip.winfo_reqwidth(), tip.winfo_reqheight()
        top = self.winfo_toplevel()
        x, y = e.x_root + 14, e.y_root + 12
        if x + w > top.winfo_rootx() + top.winfo_width():
            x = e.x_root - w - 14
        if y + h > top.winfo_rooty() + top.winfo_height():
            y = e.y_root - h - 8
        tip.geometry(f"+{x}+{y}")
        tip.deiconify()
        self.tip = tip

    def _hide(self, _e=None) -> None:
        if self.tip is not None:
            self.tip.destroy()
            self.tip = None


class LevelMeter(tk.Canvas):
    """音量のメーター（-60〜0 dB）の絵。動き（とどめる・下げる）は Meter が決める。

    バーは平均の音量（入力では「無音にする音量」の白い線と比べる）。細い目印は瞬間の最大（ピーク）で、
    赤い線（WARN_DB）より右は音が割れやすい。割れたら（clipping）バーと目印を赤くする。線はバーの上下に少し
    はみ出させて、バーの中の目印と見分ける。
    """

    LOW_DB = -60.0
    WARN_DB = -6.0  # 音割れ注意の線（ピークがここを超えたら注意。0 dB で割れる）
    DANGER = "#4a2a2a"  # 注意の線より右の地の色（赤みのある暗い色）
    PEAK = _shade(GREEN, 0.45)

    def __init__(self, master, width: int, height: int):
        self.pad = max(2, round(height * 0.4))  # 線をバーの上下にはみ出させる長さ
        super().__init__(master, width=width, height=height + 2 * self.pad, bg=BG, highlightthickness=0, bd=0)
        self.w, self.h = width, height
        self.warn = self.x(self.WARN_DB)
        self.last = None

    def x(self, db: float) -> int:
        return int(self.w * (min(0.0, max(self.LOW_DB, db)) - self.LOW_DB) / -self.LOW_DB)

    def set(self, db: float, peak_db: float, threshold_db: float, clipping: bool = False) -> None:
        bar = self.x(db)
        peak = min(self.w - 2, max(1, self.x(peak_db))) if peak_db > self.LOW_DB else None
        over = peak_db >= self.WARN_DB
        th = self.x(threshold_db) if threshold_db > self.LOW_DB else None
        key = (bar, peak, over, th, clipping)
        if key == self.last:
            return
        self.last = key
        self.delete("all")
        top, bottom, warn = self.pad, self.pad + self.h, self.warn
        full = bottom + self.pad
        self.create_rectangle(0, top, warn, bottom, fill=TRACK, outline=TRACK)
        self.create_rectangle(warn, top, self.w, bottom, fill=self.DANGER, outline=self.DANGER)
        if bar > 0:
            color = RED if clipping else GREEN
            self.create_rectangle(0, top, bar, bottom, fill=color, outline=color)
        if peak is not None:
            color = RED if clipping else YELLOW if over else self.PEAK
            self.create_rectangle(peak - 1, top, peak + 1, bottom, fill=color, outline=color)
        self.create_rectangle(warn - 1, 0, warn, full, fill=RED, outline=RED)
        if th is not None:
            self.create_rectangle(th - 1, 0, th, full, fill=FG, outline=FG)


class Meter(ttk.Frame):
    """メーター（LevelMeter）と、横の数値（「-20 dB」「無音」「音割れ」）。0.1 秒ごとに show を呼ぶ。

    バーは上がるときはすぐ、下がるときは 1 回に 3 dB。目印は PEAK_HOLD 秒とどめてから 1 回に 2 dB 下げる。
    割れたら CLIP_SHOW 秒、赤くして「音割れ」と出す。
    """

    PEAK_HOLD = 1.5
    CLIP_SHOW = 2.0

    def __init__(self, master, width: int, height: int):
        super().__init__(master)
        self.bar = LevelMeter(self, width, height)
        self.bar.pack(side="left")
        self.label = ttk.Label(self, width=7)
        self.label.pack(side="left", padx=(int(10 * ui_scale(master)), 0))
        self.shown = ("", False)  # 今の数値の文字と赤くしているか（毎回 Tk に聞かないように覚えておく）
        self.reset()

    def reset(self) -> None:
        """とどめている目印・音割れを忘れる（音を開き直したとき）。"""
        self.level = self.peak = -120.0
        self.peak_until = 0.0
        self.clip_at = float("-inf")

    def show(self, level_db: float, peak_db: float, clipped: bool, threshold_db: float = -120.0,
               active: bool = True) -> bool:
        """今の音量（平均・ピーク）と割れたかを渡す。active=False（音が止まっている）なら数値を出さない。
        割れ始めたら True（ログに残す用）。"""
        now = time.monotonic()
        self.level = level_db if level_db > self.level else max(level_db, self.level - 3.0)
        if peak_db >= self.peak:
            self.peak, self.peak_until = peak_db, now + self.PEAK_HOLD
        elif now >= self.peak_until:
            self.peak = max(peak_db, self.peak - 2.0)
        started = clipped and now - self.clip_at >= self.CLIP_SHOW
        if clipped:
            self.clip_at = now
        clipping = now - self.clip_at < self.CLIP_SHOW
        self.bar.set(self.level, self.peak, threshold_db, clipping)
        if not active:
            text = ""
        elif clipping:
            text = "音割れ"
        else:
            text = f"{self.level:.0f} dB" if self.level > -100 else "無音"
        if self.shown != (text, clipping):
            self.shown = (text, clipping)
            self.label.configure(text=text, foreground=RED if clipping else "")
        return started


def _dialog(parent, title: str, message: str, buttons: list[tuple[str, object]], kind: str = "info"):
    """暗い色の確認・お知らせの窓。押したボタンの値を返す（閉じたら最後のボタンの値）。"""
    win = tk.Toplevel(parent)
    win.withdraw()
    win.title(title)
    win.configure(bg=BG)
    win.resizable(False, False)
    if parent.winfo_viewable():
        win.transient(parent)
    result = [buttons[-1][1]]
    f = ttk.Frame(win, padding=20)
    f.grid(sticky="nsew")
    scale = ui_scale(parent)
    if kind != "info":
        tk.Label(f, text="●", fg=STATE_COLORS[kind], bg=BG, font="SunValleyBodyLargeFont").grid(
            row=0, column=0, sticky="nw", padx=(0, 10))
    ttk.Label(f, text=message, wraplength=int(460 * scale), justify="left").grid(row=0, column=1, sticky="w")
    bf = ttk.Frame(f)
    bf.grid(row=1, column=0, columnspan=2, sticky="e", pady=(18, 0))

    def done(value):
        result[0] = value
        win.destroy()

    for i, (text, value) in enumerate(buttons):
        b = ttk.Button(bf, text=text, style="Accent.TButton" if i == 0 else "TButton",
                       command=lambda v=value: done(v))
        b.pack(side="left", padx=(0 if i == 0 else 8, 0))
        if i == 0:
            b.focus_set()
    win.bind("<Return>", lambda e: done(buttons[0][1]))
    win.bind("<Escape>", lambda e: done(buttons[-1][1]))
    win.protocol("WM_DELETE_WINDOW", lambda: done(buttons[-1][1]))
    win.update_idletasks()
    if parent.winfo_viewable():  # 親の窓の真ん中あたり
        x = parent.winfo_rootx() + (parent.winfo_width() - win.winfo_reqwidth()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - win.winfo_reqheight()) // 3
        win.geometry(f"+{max(0, x)}+{max(0, y)}")
    win.deiconify()
    dark_title_bar(win)
    win.lift()
    win.grab_set()
    parent.wait_window(win)
    return result[0]


def ask(parent, title: str, message: str) -> bool:
    return bool(_dialog(parent, title, message, [("はい", True), ("いいえ", False)], "info"))


def show(parent, title: str, message: str, kind: str = "info") -> None:
    _dialog(parent, title, message, [("OK", None)], kind)
