"""自動更新した版を前の版に戻す（vc_update.py と、VoiceChanger.exe の __main__.py が使う）。

標準ライブラリだけで書く。exe の __main__.py は、これを前の版の控え（update/old/tools/）か tools/ から読んで
使う（更新した tools/ が壊れていても、前の版のもので戻せる。exe 自体にはファイルを動かす処理を入れない）。

  update/pending.json   入れ替えるものの一覧と、更新で新しく増えるもの・新しい版（入れ替える前に置き、
                        新しい版の窓が開いたら消す）
  update/old/           入れ替える前のもの（前の版）
  update/broken/        戻したときに外した新しい版（調べる用。次の更新で消える）
"""

from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path

WORK_DIR = "update"
PENDING = "pending.json"
BUILD_INFO = "BUILD-INFO.json"


def move(src: Path, dst: Path) -> None:
    """名前を変えて移す。ウイルス対策ソフトが調べている間は動かせないので、少し待ってやり直す。"""
    dst.parent.mkdir(parents=True, exist_ok=True)
    for i in range(20):
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if i == 19:
                raise
            time.sleep(0.5)


def clear(p: Path) -> None:
    if p.is_dir():
        shutil.rmtree(p)
    elif p.exists():
        p.unlink()


def read_pending(root: Path) -> dict | None:
    try:
        data = json.loads((root / WORK_DIR / PENDING).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) and isinstance(data.get("items"), list) else None
    except (OSError, ValueError):
        return None


def incomplete(root: Path) -> bool:
    """入れ替えが途中で止まったまま（電源が落ちた・戻すのに失敗した等）。BUILD-INFO が新しい版になっていない。"""
    pending = read_pending(root)
    if pending is None:
        return False
    try:
        version = json.loads((root / BUILD_INFO).read_text(encoding="utf-8")).get("version")
    except (OSError, ValueError, AttributeError):
        version = None
    return version != pending.get("to")


def rollback(root: Path, items: list[str] | None = None, added: list[str] | None = None) -> bool:
    """update/old/ の前の版に戻す。items・added を渡さなければ pending.json のもの。全部戻せたら True。

    added（更新で新しく増えたもの。前の版には無い）は update/broken/ に外す。1つ戻せなくても残りは戻す
    （例外は投げない）。戻せないものがあれば pending.json を残し、次に開いたときにもう一度戻す。
    """
    work = root / WORK_DIR
    if items is None:
        pending = read_pending(root)
        if pending is None:
            return False
        items, added = pending["items"], pending.get("added", [])
    added = set(added or [])
    ok = True
    for x in reversed(items):
        bak, cur = work / "old" / x, root / x
        if not bak.exists() and x not in added:
            continue
        try:
            if cur.exists():
                clear(work / "broken" / x)
                move(cur, work / "broken" / x)
            if bak.exists():
                move(bak, cur)
        except OSError as e:
            print(f"前の版に戻せませんでした: {x}: {e}", flush=True)
            ok = False
    if ok:
        (work / PENDING).unlink(missing_ok=True)
    return ok
