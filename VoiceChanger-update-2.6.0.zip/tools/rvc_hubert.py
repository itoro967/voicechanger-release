"""transformers を使わない HuBERT（RVC の変換で特徴量を取り出す部分）。

本家 infer/hubert.py は transformers の HubertModel を使う。transformers は import のたびに全モデルの
ソースファイルを開いて中身を調べる（`.pyc` があっても避けられない。HuBERT のためだけに約 3,600
ファイルを開き、sympy・scipy・networkx なども芋づる式に読む。本人の Windows で 96 秒）。
ここでは同じ重み（assets/hubert_base/pytorch_model.bin。名前も transformers のまま）を PyTorch だけで
動かす。計算は transformers 4.49 の HubertModel の推論時（feat_extract_norm="group"、
do_stable_layer_norm=False、マスクなし）と同じで、本家との一致は Mac で確かめた（HANDOFF 9-44）。

install() を、本家の infer.rtrvc を import する前に呼ぶと、sys.modules["infer.hubert"] をこのモジュールに
差し替える（rtrvc は `from infer.hubert import extract_hubert_features, load_hubert_model` で読む）。
学習（train/）は本家のまま transformers を使う。
"""

from __future__ import annotations

import importlib.machinery
import json
import sys
import types

import torch
import torch.nn.functional as F
from torch import nn

from rvc_common import RVC_ROOT

HUBERT_MODEL_PATH = RVC_ROOT / "assets" / "hubert_base"


class _Attention(nn.Module):
    def __init__(self, dim: int, heads: int):
        super().__init__()
        self.heads = heads
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
        self.out_proj = nn.Linear(dim, dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, t, d = x.shape

        def split(y):
            return y.view(b, t, self.heads, d // self.heads).transpose(1, 2)

        # transformers の HubertSdpaAttention と同じ（尺度は既定の 1/sqrt(head_dim)）
        y = F.scaled_dot_product_attention(split(self.q_proj(x)), split(self.k_proj(x)), split(self.v_proj(x)))
        return self.out_proj(y.transpose(1, 2).reshape(b, t, d))


class _FeedForward(nn.Module):
    def __init__(self, dim: int, hidden: int):
        super().__init__()
        self.intermediate_dense = nn.Linear(dim, hidden)
        self.output_dense = nn.Linear(hidden, dim)

    def forward(self, x):
        return self.output_dense(F.gelu(self.intermediate_dense(x)))


class _EncoderLayer(nn.Module):
    """後ろで正規化する型（HubertEncoderLayer）。"""

    def __init__(self, dim: int, heads: int, hidden: int, eps: float):
        super().__init__()
        self.attention = _Attention(dim, heads)
        self.layer_norm = nn.LayerNorm(dim, eps=eps)
        self.feed_forward = _FeedForward(dim, hidden)
        self.final_layer_norm = nn.LayerNorm(dim, eps=eps)

    def forward(self, x):
        x = self.layer_norm(x + self.attention(x))
        return self.final_layer_norm(x + self.feed_forward(x))


class _ConvLayer(nn.Module):
    def __init__(self, cin: int, cout: int, kernel: int, stride: int, group_norm: bool):
        super().__init__()
        self.conv = nn.Conv1d(cin, cout, kernel, stride=stride, bias=False)
        # 1層目だけ GroupNorm（チャンネルごと。transformers での名前は layer_norm）
        self.layer_norm = nn.GroupNorm(cout, cout, affine=True) if group_norm else None

    def forward(self, x):
        x = self.conv(x)
        if self.layer_norm is not None:
            x = self.layer_norm(x)
        return F.gelu(x)


class _Namespace(nn.Module):
    """transformers と同じ名前で重みを読むための入れ物。"""


class HubertModelWithFinalProj(nn.Module):
    def __init__(self, cfg: dict):
        super().__init__()
        dim, eps = cfg["hidden_size"], cfg["layer_norm_eps"]
        self.feature_extractor = _Namespace()
        dims = [1] + cfg["conv_dim"]
        self.feature_extractor.conv_layers = nn.ModuleList(
            _ConvLayer(dims[i], dims[i + 1], k, s, group_norm=(i == 0))
            for i, (k, s) in enumerate(zip(cfg["conv_kernel"], cfg["conv_stride"]))
        )
        self.feature_projection = _Namespace()
        self.feature_projection.layer_norm = nn.LayerNorm(cfg["conv_dim"][-1], eps=eps)
        self.feature_projection.projection = nn.Linear(cfg["conv_dim"][-1], dim)
        self.encoder = _Namespace()
        self.encoder.pos_conv_embed = _Namespace()
        k = cfg["num_conv_pos_embeddings"]
        self.encoder.pos_conv_embed.conv = nn.Conv1d(dim, dim, k, padding=k // 2,
                                                     groups=cfg["num_conv_pos_embedding_groups"])
        self.pos_conv_trim = 1 if k % 2 == 0 else 0  # 偶数の幅では最後の1フレームを落とす（HubertSamePadLayer）
        self.encoder.layer_norm = nn.LayerNorm(dim, eps=eps)
        self.encoder.layers = nn.ModuleList(
            _EncoderLayer(dim, cfg["num_attention_heads"], cfg["intermediate_size"], eps)
            for _ in range(cfg["num_hidden_layers"])
        )
        self.final_proj = nn.Linear(dim, cfg["classifier_proj_size"])

    def forward(self, input_values: torch.Tensor, output_layer: int) -> torch.Tensor:
        """output_layer 層目の出力（transformers の hidden_states[output_layer]。12 なら last_hidden_state）。"""
        x = input_values[:, None]
        for layer in self.feature_extractor.conv_layers:
            x = layer(x)
        x = x.transpose(1, 2)
        x = self.feature_projection.projection(self.feature_projection.layer_norm(x))
        pos = self.encoder.pos_conv_embed.conv(x.transpose(1, 2))
        if self.pos_conv_trim:
            pos = pos[:, :, :-self.pos_conv_trim]
        x = self.encoder.layer_norm(x + F.gelu(pos).transpose(1, 2))
        for layer in self.encoder.layers[:output_layer]:
            x = layer(x)
        return x


def _load_state_dict(path) -> dict:
    sd = torch.load(path, map_location="cpu", weights_only=True)
    # 位置の畳み込みは weight_norm（dim=2）のまま入っている。推論では固定なので重みに戻しておく
    prefix = "encoder.pos_conv_embed.conv."
    g = sd.pop(prefix + "parametrizations.weight.original0", None)
    v = sd.pop(prefix + "parametrizations.weight.original1", None)
    if g is None:  # 古い名前（weight_g / weight_v）
        g, v = sd.pop(prefix + "weight_g"), sd.pop(prefix + "weight_v")
    g, v = g.float(), v.float()
    sd[prefix + "weight"] = v * (g / v.norm(dim=(0, 1), keepdim=True))
    sd.pop("masked_spec_embed", None)  # 学習時のマスク用
    return sd


def load_hubert_model(device, is_half: bool = False):
    """本家 infer.hubert.load_hubert_model と同じ。"""
    cfg = json.loads((HUBERT_MODEL_PATH / "config.json").read_text(encoding="utf-8"))
    model = HubertModelWithFinalProj(cfg)
    model.load_state_dict(_load_state_dict(HUBERT_MODEL_PATH / "pytorch_model.bin"))
    return model.to(device, torch.float16 if is_half else torch.float32).eval()


def hubert_audio_requires_normalization() -> bool:
    try:
        cfg = json.loads((HUBERT_MODEL_PATH / "preprocessor_config.json").read_text(encoding="utf-8"))
        return bool(cfg.get("do_normalize", False))
    except (OSError, ValueError):
        return False


def extract_hubert_features(model, source, version, padding_mask=None):
    """本家 infer.hubert.extract_hubert_features と同じ（v1 は 9層目 → final_proj、v2 は 12層目）。"""
    from tools.cuda_graph import run_cuda_graph

    if version not in {"v1", "v2"}:
        raise ValueError(f"Unsupported RVC feature version: {version!r}")
    if padding_mask is not None and bool(torch.any(padding_mask).item()):
        # リアルタイム変換の rtrvc は常に全部 False を渡す（マスクの経路は使わない）
        raise NotImplementedError("padding_mask は使えません")
    with torch.no_grad():
        if version == "v1":
            return run_cuda_graph(model, "hubert-v1-no-mask",
                                  lambda x: model.final_proj(model(x, 9)), source)
        return run_cuda_graph(model, "hubert-v2-no-mask", lambda x: model(x, 12), source)


def install() -> None:
    """sys.modules["infer.hubert"] をこのモジュールにする（本家の rtrvc を import する前に呼ぶ）。"""
    mod = types.ModuleType("infer.hubert")
    mod.__spec__ = importlib.machinery.ModuleSpec("infer.hubert", None)
    for name in ("load_hubert_model", "extract_hubert_features", "hubert_audio_requires_normalization",
                 "HubertModelWithFinalProj", "HUBERT_MODEL_PATH"):
        setattr(mod, name, globals()[name])
    sys.modules["infer.hubert"] = mod
