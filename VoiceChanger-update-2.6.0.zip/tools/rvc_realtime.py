"""リアルタイム変換の本体（マイク → 雑音除去 → RVC → 出力デバイス）。vc.py（コマンド）と vc_gui.py（窓）で共有する。

  マイク ──▶ 雑音除去 ──▶ RVC（ブロックごとに変換） ──▶ CABLE Input ──▶ Discord のマイク（CABLE Output）
                    └──────▶ 地声（ボイチェン OFF のとき）

**開いたらすぐ地声を流す。** 変換のモデル（engine）は後から渡す（set_engine）。渡すと変換スレッドが試運転
してから変換を始め、voice_ready が立つ。voice（ボイチェンの ON/OFF）は、変換した声と地声のどちらを流すか
だけを切り替える（変換は裏で続いているので一瞬で切り替わる。変換の文脈 = 直前 extra_ms の入力も途切れない）。
**voice が True の間は地声を流さない**: 変換の準備ができていない（読み込み中・読み直し中）ときは無音にする
（声を変えたい人の地声が Discord に漏れないように）。

雑音除去（rvc_denoise.Denoiser、PyTorch が要る）も後から渡す（set_denoiser）。渡す前と denoise=False の
ときは、雑音を消さない音を同じだけ（DENOISE_DELAY）遅らせて流す（ON/OFF や準備ができた瞬間に音が飛ばない）。

**デバイスの形式は問わない。** 中では SAMPLE_RATE（48kHz）・モノラル・float32 で扱う。入力と出力は別々の
ストリームで開き、それぞれまず 48kHz で開いてみて（Windows の WASAPI 共有モードは自動変換を付けて開くので、
ほぼこれで開ける）、開けなければデバイスの既定のレートで開いて、中で変換する（Resampler）。ビット数
（16 / 24 / 32 bit）とチャンネル数は PortAudio と Windows が合わせる。

スレッドは3つ:
  音声スレッド（PortAudio のコールバック）: 入力を音の処理スレッドへ渡す / 出力バッファから取って鳴らす
  音の処理スレッド: 入力が1ブロック分たまったら、雑音除去 → 変換スレッドに渡して待つ → 流す音を選ぶ → 出力バッファへ
  変換スレッド: engine の試運転（CUDA Graph の作成など。本番と同じスレッドで行い、最初のブロックだけ遅く
                なるのを防ぐ）と変換。試運転の間も音の処理スレッドは地声を流し続ける

変換をコールバックの中でしないのは、音声スレッドが処理時間ぶん止まって OS 側で音が落ちるため（PortAudio は
それを途切れとして報告しない。macOS で実測: 処理 330〜520ms / ブロック 600ms で、出力の約半分が無音だった）。

出力は最初に buffer_ms だけ無音を積んでから鳴らし始める（処理時間のばらつきの吸収分）。バッファが空になると
無音が挟まり（途切れとして数える）、次に積むときに余裕を積み直す（入力と出力は時計が別なので、ずれで何度も
途切れないように）。**遅延は増えたままにしない**: 処理が一時的に遅れて入力が2ブロック以上たまったら古い分を
捨てる。出力バッファは、直近 SETTLE_SECONDS 以上でいちばん減ったときの残りが buffer_ms より多ければ、話して
いないブロック（QUIET_DB 未満）でその分を削る（ばらつきで一瞬増えた分を削ると、次の遅いブロックで途切れるため。
書くたびに上限で削っていた前のやり方は、処理 80ms±15ms の模擬で2時間に36回途切れ、このやり方は0回）。1ブロック
以上溜まったときだけはすぐ削る。削った分はスキップとして数える。

音声デバイスが止まったこと（抜けた・スリープ・設定の変更）は、コールバックが SILENT_SECONDS 届かない・
ストリームが止まった・処理スレッドが死んだ、で検出して health() で知らせる。
"""

from __future__ import annotations

import math
import os
import queue
import sys
import threading
import time
import traceback
from collections import deque

import numpy as np

DEFAULT_HOSTAPI = "WASAPI" if os.name == "nt" else None
DEFAULT_OUTPUT = "CABLE Input"
# VB-CABLE を入れると既定の録音デバイスがこれに替わることがある。入力にすると、自分の出力を
# 自分で変換し続ける
CABLE_LOOPBACK = "CABLE Output"
SAMPLE_RATE = 48000  # 中で扱うレート（雑音除去のモデルが 48kHz 専用。vc_file もこのレートで変換する）
# 雑音除去の遅れ（30ms）。ここは torch を読まないので値で持ち、rvc_denoise が import のときに自分の値と比べる
DENOISE_DELAY = 1440
CROSSFADE_MS = 50.0  # 変換のブロックのつなぎ目を重ねる長さ（窓は固定。vc は --crossfade-ms）


def level_db(a: np.ndarray) -> float:
    """平均の音量（RMS）の dB（無音は -180）。"""
    return 10 * math.log10(float(np.dot(a, a)) / max(1, len(a)) + 1e-18)


def gain_ramp(g0: float, g1: float, n: int):
    """音量を g0 から g1 へ n サンプルかけて移す倍率（同じなら g1 のまま）。掛けてもプツッと鳴らない。"""
    return g1 if g0 == g1 else np.linspace(g0, g1, n, dtype=np.float32)


def frames(ms: float, sr: int = SAMPLE_RATE) -> int:
    """ms を 10ms 単位に丸めたサンプル数。rvc_engine.StreamEngine もこれでブロック長などを決める。"""
    zc = sr // 100
    return int(round(ms / 1000 * sr / zc) * zc)


def raw_delay_frames(crossfade_ms: float, sr: int = SAMPLE_RATE) -> int:
    """変換した声が入力より遅れて出てくる分（重ね合わせ + 前のブロックとつなぐ位置を探す幅 10ms）。
    地声もこれだけ遅らせると、変換した声と時刻がそろう（StreamEngine.raw_delay_frame）。"""
    return frames(crossfade_ms, sr) + frames(10, sr)


def hostapi_name(sd, dev: int) -> str:
    return sd.query_hostapis()[sd.query_devices(dev)["hostapi"]]["name"]


def wasapi_settings(sd, dev: int, exclusive: bool = False):
    """WASAPI のデバイスなら開くときの設定。共有モードでは自動変換を付ける（デバイスの形式と違うレート・
    チャンネル数でも開ける）。WASAPI でなければ None。"""
    if "WASAPI" not in hostapi_name(sd, dev):
        return None
    return sd.WasapiSettings(exclusive=exclusive, auto_convert=not exclusive)


def devices(sd, kind: str, hostapi: str | None) -> list[dict]:
    """kind（"input" / "output"）のデバイス。hostapi を渡すとその API のものだけ（無ければ全部）。"""
    apis = sd.query_hostapis()
    found = [d for d in sd.query_devices() if d[f"max_{kind}_channels"] > 0]
    if hostapi:
        same = [d for d in found if hostapi.lower() in apis[d["hostapi"]]["name"].lower()]
        found = same or found
    return found


def default_device(sd, kind: str, hostapi: str | None) -> int:
    """ホスト API の既定デバイス（無ければ OS の既定）。kind は "input" か "output"。"""
    if hostapi:
        for api in sd.query_hostapis():
            if hostapi.lower() in api["name"].lower():
                idx = api[f"default_{kind}_device"]
                if idx >= 0:
                    return idx
    return sd.default.device[0 if kind == "input" else 1]


class Resampler:
    """サンプルレートを変える（流しながら。numpy だけ）。src == dst なら何もしない。

    scipy の resample_poly と同じやり方（Kaiser 窓の低域通過フィルタを多相に分けて使う）。
    44.1kHz ↔ 48kHz なら 160 / 147 倍。遅れは HALF サンプル（44.1kHz で 0.4ms）。
    """

    HALF = 16  # フィルタの片側の長さ（変換前のサンプル数）

    def __init__(self, src: int, dst: int):
        g = math.gcd(src, dst)
        self.up, self.down = dst // g, src // g
        self.taps = 2 * self.HALF
        if src == dst:
            return
        n = self.taps * self.up
        cutoff = 1.0 / max(self.up, self.down)  # 0 埋めで上げたレートのナイキストに対する割合
        t = np.arange(n) - (n - 1) / 2
        h = self.up * cutoff * np.sinc(cutoff * t) * np.kaiser(n, 8.0)
        self.phases = h.reshape(self.taps, self.up).T.astype(np.float32)  # [位相, タップ]
        self.buf = np.zeros(self.taps, dtype=np.float32)  # buf[0] が入力の base 番目
        self.base = -self.taps
        self.n_in = 0
        self.m = 0  # 次に出す出力の番号

    def process(self, x: np.ndarray) -> np.ndarray:
        if self.up == self.down:
            return x
        self.buf = np.concatenate([self.buf, x])
        self.n_in += len(x)
        m_end = (self.n_in * self.up - 1) // self.down + 1  # 今ある入力で出せるところまで
        u = np.arange(self.m, m_end, dtype=np.int64) * self.down
        i0 = u // self.up
        idx = i0[:, None] - np.arange(self.taps)[None, :] - self.base
        y = np.einsum("mj,mj->m", self.buf[idx], self.phases[u % self.up])
        self.m = m_end
        drop = max(0, (m_end * self.down) // self.up - (self.taps - 1) - self.base)
        self.buf = self.buf[drop:]
        self.base += drop
        return y.astype(np.float32)


class Delay:
    def __init__(self, n: int):
        self.hist = np.zeros(n, dtype=np.float32)

    def process(self, x: np.ndarray) -> np.ndarray:
        if not len(self.hist):
            return x
        joined = np.concatenate([self.hist, x])
        self.hist = joined[len(x):]
        return joined[:len(x)]


class Fader:
    """2つの音のどちらを流すか。切り替えたブロックは先頭 n サンプルで重ねる（プツッと鳴らさない）。"""

    def __init__(self, n: int):
        self.ramp = np.linspace(0.0, 1.0, max(1, n), dtype=np.float32)
        self.cur: bool | None = None

    def pick(self, want: bool, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """want なら a、でなければ b。"""
        if self.cur is None or want == self.cur:
            self.cur = want
            return a if want else b
        src, dst = (b, a) if want else (a, b)
        out = dst.astype(np.float32, copy=True)
        w = self.ramp[:len(out)]
        out[:len(w)] = src[:len(w)] * (1.0 - w) + dst[:len(w)] * w
        self.cur = want
        return out


class OutputBuffer:
    """音の処理スレッドが積み、音声スレッドが取り出す。足りない分は無音で埋める。rate はデバイスのレート。"""

    TRIM_FADE_SECONDS = 0.005

    def __init__(self, rate: int, buffer_ms: float, block_ms: float):
        self.lock = threading.Lock()
        self.chunks: deque = deque()
        self.size = 0
        self.started = False
        self.dry = False
        self.underruns = 0
        self.low: int | None = None  # 前回 take_low() 以降でいちばん減ったときの残り（表示用）
        self.ctl_low: int | None = None  # 前回 settle() 以降の同じもの（削る量を決める用）
        self.rate = rate
        self.block = frames(block_ms, rate)
        self.set_buffer(buffer_ms)
        self.trim_fade = np.linspace(0.0, 1.0, max(1, int(rate * self.TRIM_FADE_SECONDS)), dtype=np.float32)

    def set_buffer(self, buffer_ms: float) -> None:
        """余裕（buffer_ms）を決める。流している間に変えてよい（次に積むときから効く）。"""
        with self.lock:
            self.buffer_frames = int(self.rate * buffer_ms / 1000)
            # 目標（書いた直後の量）と、すぐ削る上限（1ブロック以上余ったとき）
            self.target = self.buffer_frames + self.block
            self.hard_cap = self.target + self.block

    def put(self, y: np.ndarray) -> bool:
        """積む。最初と、空になった後は余裕の無音を先に積む。1ブロック以上余ったらすぐ削る（削ったら True）。"""
        with self.lock:
            if not self.started or self.dry:
                if self.buffer_frames > 0:
                    self.chunks.append(np.zeros(self.buffer_frames, dtype=np.float32))
                    self.size += self.buffer_frames
                self.dry = False
            self.chunks.append(y)
            self.size += len(y)
            self.started = True
        return self.size > self.hard_cap and self.trim(self.target) > 0

    def settle(self) -> bool:
        """直近でいちばん減ったときの残りが buffer_ms より 10ms 以上多ければ、その分を削る（削ったら True）。"""
        with self.lock:
            low, self.ctl_low = self.ctl_low, None
        if low is None:
            return False
        excess = low - self.buffer_frames
        return excess > self.rate // 100 and self.trim(self.size - excess) > 0

    def trim(self, keep: int) -> int:
        """古い分を削って keep サンプルにする。削ったサンプル数を返す。削った直後は音を戻していく。"""
        dropped = 0
        with self.lock:
            while self.size - dropped > keep and self.chunks:
                c = self.chunks[0]
                k = min(len(c), self.size - dropped - keep)
                if k == len(c):
                    self.chunks.popleft()
                else:
                    self.chunks[0] = c[k:]
                dropped += k
            self.size -= dropped
            if dropped and self.chunks:
                c = self.chunks[0].copy()
                n = min(len(c), len(self.trim_fade))
                c[:n] *= self.trim_fade[:n]
                self.chunks[0] = c
        return dropped

    def take_low(self) -> int | None:
        with self.lock:
            low, self.low = self.low, None
            return low

    def read(self, n: int):
        out = np.zeros(n, dtype=np.float32)
        pos = 0
        with self.lock:
            while pos < n and self.chunks:
                c = self.chunks[0]
                k = min(n - pos, len(c))
                out[pos:pos + k] = c[:k]
                pos += k
                if k == len(c):
                    self.chunks.popleft()
                else:
                    self.chunks[0] = c[k:]
            self.size -= pos
            if self.started:
                self.low = self.size if self.low is None else min(self.low, self.size)
                self.ctl_low = self.size if self.ctl_low is None else min(self.ctl_low, self.size)
            # 空になった回数を数える（1回の途切れが複数のコールバックにまたがっても1回）
            if pos < n and self.started and not self.dry:
                self.underruns += 1
            self.dry = self.dry or (pos < n and self.started)
        return out


class Stats:
    """音の処理スレッドから書き、表示側から読む。"""

    def __init__(self):
        self.lock = threading.Lock()
        self.times: list[float] = []
        self.overruns = 0
        self.skips = 0
        self.errors = 0  # 変換に失敗したブロック（通算、表示用）
        self.consecutive_errors = 0  # 続けて失敗したブロック数（外すかの判断用）
        self.level_db = -120.0
        self.out_level_db = -120.0  # 出力先に流した音の平均の音量（表示用。take では渡さない）

    def take(self):
        with self.lock:
            t, self.times = self.times, []
            return t, self.overruns, self.skips, self.errors, self.consecutive_errors, self.level_db


class _Output:
    """出力先・プレビュー: ストリーム、デバイスのレートへの変換、出力バッファ、音量（プレビューだけ）。"""

    def __init__(self, gain=None):
        self.stream = None
        self.rate = SAMPLE_RATE
        self.resampler: Resampler | None = None
        self.buf: OutputBuffer | None = None
        self.last_cb = time.monotonic()
        self.gain = gain  # 今の音量を返す関数（None なら 1 倍のまま）
        self._g = 0.0  # 今かけている音量（変えたらコールバックの間に移していく。プツッと鳴らさない）

    def open(self, session: "Session", dev: int, exclusive: bool) -> None:
        self.stream, self.rate = session._stream("output", dev, self.callback, exclusive)
        self.resampler = Resampler(SAMPLE_RATE, self.rate)
        self.buf = OutputBuffer(self.rate, session.buffer_ms, session.block_ms)
        self.last_cb = time.monotonic()

    def put(self, y: np.ndarray) -> bool:
        return self.buf.put(self.resampler.process(y))

    # コールバックからは例外を出さない（出すと sounddevice がストリームを黙って止める）
    def callback(self, outdata, frames_, _time, _status):
        try:
            self.last_cb = time.monotonic()
            y = self.buf.read(frames_)
            if self.gain is not None:
                g0, self._g = self._g, self.gain()
                y *= gain_ramp(g0, self._g, frames_)
            outdata[:] = y[:, None]
        except Exception:
            outdata.fill(0)


class Session:
    """開いてから stop() までの音の流れ（開いたらすぐ流し始める）。

    voice: True で変換した声、False で地声を流す（いつ変えてもよい。次のブロックから。変換の準備ができて
    いなければ、True の間は無音）。声を変えたい用途なら True で作る（開いた瞬間から地声を漏らさない）。
    denoise: True で雑音を消す（set_denoiser で渡してから効く。いつ変えてもよい）。消す・消さないにかかわらず
    雑音除去の分（30ms）遅らせる（切り替えで音が飛ばない）。allow_denoise=False なら使わず、遅らせもしない。
    options: engine.process に渡すキーワード引数。変えてよい（次のブロックから効く）。
    monitor_dev を渡すと、出力先（Discord に流す CABLE Input など）と同じ音を、別のデバイス（自分で聞く
    ヘッドホン）にも流す（プレビュー）。monitor_on・monitor_volume はいつ変えてもよい（monitor_on は次のブロックから。
    OFF でもデバイスは開いたまま無音を積む）。プレビューを開けなくても続ける（monitor_error）。
    input_gain: マイクの音にかける倍率（いつ変えてもよい。次のブロックから、ブロックの中でなめらかに移す）。
    雑音除去・変換・地声のどれにもかかる。マイク自体で割れた音は直らない（take_peaks はかける前の値）。
    start_recording で、出力先に流す音を録ってプレビューで聞ける（「録って聞く」）。
    """

    FADE_SECONDS = 0.02
    SETTLE_SECONDS = 10.0  # 出力バッファの余りを削るか判断する間隔
    QUIET_DB = -45.0  # 余りは入力がこれより小さい（話していない）ブロックで削る（話している最中に削ると言葉が飛ぶ）
    SILENT_SECONDS = 2.0  # コールバックがこれだけ来なければ、デバイスが止まったとみなす
    CONVERT_TIMEOUT = 15.0  # 変換がこれだけ返らなければ、変換が止まったとみなす（GPU が固まった等）

    def __init__(self, in_dev: int, out_dev: int, *, block_ms: float = 200.0, crossfade_ms: float = CROSSFADE_MS,
                 buffer_ms: float = 50.0, exclusive: bool = False, options: dict | None = None,
                 voice: bool = False, denoise: bool = True, allow_denoise: bool = True,
                 monitor_dev: int | None = None, monitor_on: bool = True, monitor_volume: float = 1.0,
                 input_gain: float = 1.0):
        import sounddevice as sd

        self.sd = sd
        self.in_dev, self.out_dev = in_dev, out_dev
        self.exclusive = exclusive
        self.block_ms, self.buffer_ms = block_ms, buffer_ms
        self.block = frames(block_ms)
        # 地声は変換した声と同じだけ遅らせる（そろえないと切り替えのたびに言葉が飛ぶ・重なる）
        self.voice_delay = raw_delay_frames(crossfade_ms)
        self.options = dict(options or {})
        self.voice = voice
        self.denoise = denoise
        # 雑音除去を使わない（途中で切り替えない vc の --denoise なし）なら、その分の遅れ（30ms）も足さない
        self.allow_denoise = allow_denoise
        self.nr_delay = DENOISE_DELAY if allow_denoise else 0
        self.monitor_on = monitor_on
        self.monitor_volume = monitor_volume
        self.monitor_dev = monitor_dev if monitor_dev is not None and monitor_dev != out_dev else None
        self.stats = Stats()
        self.input_gain = input_gain
        self.in_peak = 0.0  # 入力のコールバックが書き、take_peaks() が読んで 0 に戻す
        self.out_peak = 0.0  # 処理スレッドが書き、take_peaks() が読んで 0 に戻す
        # 録って聞く（窓のスレッドが _rec_req に置き、処理スレッドが受け取って録る・流す）
        self._rec_lock = threading.Lock()  # 窓のスレッドと処理スレッドで、下の4つをまとめて読み書きする
        self._rec_req: int | None = None  # 録るサンプル数（0 はやめる）
        self._rec_buf: np.ndarray | None = None  # 録る・録った音（録り終えたら頭から流す）
        self._rec_pos = 0
        self._playing = False
        # 上限は約 10 秒分（コールバックは 10ms 前後ごと）。処理スレッドが止まってもメモリを食い続けない
        self.inq: queue.Queue = queue.Queue(maxsize=1000)
        self.running = threading.Event()
        self.instream = None
        self.in_rate = SAMPLE_RATE
        self.last_in_cb = 0.0
        self.out = _Output()
        self.mon: _Output | None = None  # 開けたら入れる（処理スレッドが開きかけのものに積まないように）
        self.monitor_error = ""
        self.started_at = 0.0
        self.last_error = ""
        self.stopped_cleanly = True  # stop() でスレッドが終わったか（終わらなければ engine を使い回さない）
        self.threads: list[threading.Thread] = []
        # 雑音除去
        self.denoiser = None
        self.denoise_error = ""
        # 変換（変換スレッドとのやりとり）
        self._engine_lock = threading.Lock()
        self._engine_req: list = []  # 渡された engine（None は外す）。変換スレッドが取る
        self._attached = False  # engine を渡している
        self._released = threading.Event()  # 変換スレッドが前の engine を手放した
        self._ready = threading.Event()  # 試運転が済んで変換している
        self._conv_in: queue.Queue = queue.Queue()
        self._conv_out: queue.Queue = queue.Queue()
        self._seq = 0
        self.engine_error: BaseException | None = None  # 試運転で落ちた理由（traceback は外す。GPU のメモリを離すため）
        self.voice_problem = ""  # 変換が応答しない（GPU が固まった等）

    # ---- 外から使うもの
    @property
    def engine_state(self) -> str:
        """渡した engine の状態。"none"（渡していない）・"warming"（試運転中）・"ready"・"failed"（試運転で落ちた。
        engine_error）・"stuck"（変換が応答しない。voice_problem。この Session では直らない）。"""
        if not self._attached:
            return "none"
        if self.voice_problem:
            return "stuck"
        if self.engine_error is not None:
            return "failed"
        return "ready" if self._ready.is_set() else "warming"

    @property
    def voice_ready(self) -> bool:
        return self.engine_state == "ready"

    def accepts(self, engine) -> bool:
        """engine（rvc_engine.StreamEngine）の形（レート・ブロック長・重ね合わせ）がこの Session と同じか。"""
        return (engine.sample_rate, engine.block_frame, engine.raw_delay_frame) == (SAMPLE_RATE, self.block,
                                                                                    self.voice_delay)

    def _streams(self) -> list:
        return [s for s in (self.instream, self.out.stream, self.mon and self.mon.stream) if s is not None]

    @property
    def device_latency_ms(self) -> float:
        """入力と出力先のデバイスの遅れ（プレビューは出力先への経路に無いので入れない）。"""
        return 1000 * sum(s.latency for s in (self.instream, self.out.stream) if s is not None)

    def latency_ms(self, proc_ms: float = 0.0) -> float:
        """話してから出力先に届くまでのおおよその時間: ブロックをためる分 + 重ね合わせ・雑音除去の分 + 処理
        （proc_ms）+ 出力の余裕 + デバイス。"""
        return (self.block_ms + 1000 * (self.voice_delay + self.nr_delay) / SAMPLE_RATE + proc_ms + self.buffer_ms
                + self.device_latency_ms)

    def open(self) -> None:
        """ストリームを開いて鳴らし始める。開けなければ後始末してから sd.PortAudioError を投げる。

        **Windows では PortAudio を初期化したスレッド（メインスレッド）から呼ぶこと。** WASAPI は
        COM を使うので、COM を初期化していないスレッドで開くと「Unanticipated host error
        [PaErrorCode -9999]」で失敗する（なぜか WDM-KS のメッセージが付く）。窓で読み込み用の
        スレッドから開いて、実際に Windows で起きた。停止（stop）も同じスレッドから呼ぶ。
        """
        self.started_at = self.last_in_cb = time.monotonic()
        self.running.set()
        try:
            self.instream, self.in_rate = self._stream("input", self.in_dev, self._in_callback, self.exclusive)
            self._in_rs = Resampler(self.in_rate, SAMPLE_RATE)
            self.out.open(self, self.out_dev, self.exclusive)
            self.threads = [threading.Thread(target=self._pipeline, daemon=True),
                            threading.Thread(target=self._converter, daemon=True)]
            for t in self.threads:
                t.start()
            self.out.stream.start()
            self.instream.start()
        except BaseException:
            self.stop()  # 開けた・始めたものを閉じ、スレッドも止める
            raise
        if self.monitor_dev is None:
            return
        # プレビューは開けなくても続ける。自分のヘッドホンなので、--exclusive でも共有モードで開く
        # （排他にすると Discord などがそのヘッドホンで鳴らせなくなる）
        mon = _Output(gain=lambda: self.monitor_volume)
        try:
            mon.open(self, self.monitor_dev, False)
            mon.stream.start()
            self.mon = mon
        except Exception as e:
            traceback.print_exc()
            self.monitor_dev = None
            self.monitor_error = f"プレビューのデバイスを開けませんでした（{e}）"

    def _stream(self, kind: str, dev: int, callback, exclusive: bool):
        """(ストリーム, レート)。まず SAMPLE_RATE で、開けなければデバイスの既定のレートで開く。"""
        sd = self.sd
        info = sd.query_devices(dev)
        cls = sd.InputStream if kind == "input" else sd.OutputStream
        err = None
        for rate in dict.fromkeys((SAMPLE_RATE, int(info["default_samplerate"]))):
            try:
                # コールバックは軽いので、ブロック長は指定せずデバイス任せ・低遅延で開く
                stream = cls(device=dev, samplerate=rate, channels=min(info[f"max_{kind}_channels"], 2),
                             dtype="float32", latency="low", callback=callback,
                             extra_settings=wasapi_settings(sd, dev, exclusive))
            except sd.PortAudioError as e:
                err = e
                continue
            if rate != SAMPLE_RATE:
                print(f"{info['name']} は {rate} Hz で開きました（中で {SAMPLE_RATE} Hz に変換します）", flush=True)
            return stream, rate
        raise err

    def stop(self, wait: float = 10.0) -> None:
        """止める。スレッドが終わるのを wait 秒まで待つ（終わらなければ stopped_cleanly が False）。"""
        for s in self._streams():
            try:
                s.stop()
                s.close()
            except Exception:
                pass
        self.running.clear()
        # 待っているスレッドを起こす（入力・変換の待ちで最大 0.5 秒かからないように）
        try:
            self.inq.put_nowait(None)
        except queue.Full:
            pass
        self._conv_in.put(None)
        deadline = time.monotonic() + wait
        for t in self.threads:
            # 処理中のブロックが終わるのを待つ（同じ engine で次の Session を始められるように）
            t.join(timeout=max(0.0, deadline - time.monotonic()))
        self.stopped_cleanly = not any(t.is_alive() for t in self.threads)
        self._rec_buf = None  # 録った音を離す

    def take_peaks(self) -> tuple[float, float]:
        """前に呼んでからの（マイクの音, 出力先に流した音）の最大の振幅（1 に届いたら音が割れている。窓は
        vc_gui.CLIP_LEVEL で見る）。

        マイクはデバイスから来たままの値（input_gain・雑音除去・リサンプルの前、全チャンネル）。割れるのは
        マイク（と OS の音量）のところなので、Discord に流れる大きさ（stats.level_db。雑音除去の後の平均）では
        なくこちらで見る。開いてから1秒は数えない（開いた瞬間のポップ音を音割れと間違えない）。出力は ±1 に
        抑える前の値（1 を超えた分は切れて割れる）。
        鍵をかけずに受け渡すので、まれに1回分を取りこぼす（表示用なので構わない）。
        """
        peaks = self.in_peak, self.out_peak
        self.in_peak = self.out_peak = 0.0
        return peaks

    def start_recording(self, seconds: float) -> bool:
        """「録って聞く」: 出力先に流す音を seconds 秒録って、録り終えたらプレビューに流す（相手にどう聞こえるかを
        自分で確かめる）。流している間は、プレビューに今の音の代わりに録った音を流す（「自分で聞く」が OFF でも
        聞こえる）。プレビューを開けていなければ何もせず False。次のブロックから録る。"""
        if self.mon is None:
            return False
        with self._rec_lock:
            self._rec_req = frames(1000 * seconds)
        return True

    def stop_recording(self) -> None:
        """録る・流すのをやめる。"""
        with self._rec_lock:
            self._rec_req = 0

    @property
    def recording(self) -> tuple[str, float]:
        """録って聞くの状態: ("rec"（録っている）・"play"（流している）・""、残りの秒数)。"""
        with self._rec_lock:
            req, buf, pos, playing = self._rec_req, self._rec_buf, self._rec_pos, self._playing
        if req:  # 頼んだが、処理スレッドがまだ受け取っていない
            return "rec", req / SAMPLE_RATE
        if buf is None:
            return "", 0.0
        return "play" if playing else "rec", max(0, len(buf) - pos) / SAMPLE_RATE

    def set_buffer(self, buffer_ms: float) -> None:
        """余裕を変える（開き直さない。次に積むときから効く）。"""
        self.buffer_ms = buffer_ms
        for o in (self.out, self.mon):
            if o is not None and o.buf is not None:
                o.buf.set_buffer(buffer_ms)

    def set_engine(self, engine, wait: float = 10.0) -> bool:
        """変換に使う engine（rvc_engine.StreamEngine、accepts() が True のもの）を渡す。None で外す。

        前の engine を変換スレッドが手放すまで wait 秒まで待つ（手放したら True。その後は前の engine を
        別のスレッドで触ってよい）。新しい engine の試運転は変換スレッドが行い、済むと voice_ready が立つ。
        """
        if engine is not None and not self.accepts(engine):
            raise ValueError("engine の形（レート・ブロック長・重ね合わせ）が Session と違います")
        with self._engine_lock:
            self._released.clear()
            self._ready.clear()
            self.engine_error = None
            self.voice_problem = ""
            self._attached = engine is not None
            self._engine_req.append(engine)
        if not self.running.is_set():
            # 止めた後でも、変換スレッドが試運転・変換の途中ならまだ前の engine を使っている
            return len(self.threads) < 2 or not self.threads[1].is_alive()
        return self._released.wait(wait)

    def set_denoiser(self, denoiser) -> None:
        """rvc_denoise.Denoiser を渡す。None で外す。allow_denoise=False の Session では使わない。"""
        self.denoise_error = ""
        self.denoiser = denoiser if self.allow_denoise else None

    def poll(self) -> dict:
        """前回の poll からの統計。errors は通算、consecutive_errors は続けて失敗したブロック数。"""
        times, over, skips, errors, consecutive, level = self.stats.take()
        buf = self.out.buf
        low = buf.take_low() if buf is not None else None
        return dict(
            times=times, dropouts=(buf.underruns if buf is not None else 0) + over, skips=skips, errors=errors,
            consecutive_errors=consecutive, level_db=level,
            low_ms=1000 * low / self.out.rate if low is not None else None,
        )

    def health(self) -> tuple[str, str]:
        """(音が止まった理由, プレビューの問題)。問題が無ければ空文字。定期的に呼ぶ。

        PortAudio はコールバックの外で例外が出たり、デバイスが抜けたりすると、ストリームを黙って
        止める（コールバックが来なくなる）。そのままだと窓は動いているように見えて Discord には何も流れない。
        変換が応答しないこと（engine_state の "stuck"）は別に見る。
        """
        now = time.monotonic()

        def stalled(stream, last) -> bool:
            return stream is not None and (not stream.active or now - last > self.SILENT_SECONDS)

        problem = ""
        if self.threads and not self.threads[0].is_alive():
            problem = "音の処理が止まりました（詳しくはログ）"
        elif stalled(self.instream, self.last_in_cb) or stalled(self.out.stream, self.out.last_cb):
            problem = "音声デバイスが止まりました（抜けた・スリープした・サウンドの設定が変わった など）"
        mon = self.monitor_error
        if not mon and self.mon is not None and stalled(self.mon.stream, self.mon.last_cb):
            mon = "プレビューのデバイスが止まりました"
        return problem, mon

    # ---- 音声スレッド（コールバックからは例外を出さない。出すと sounddevice がストリームを黙って止める）
    def _in_callback(self, indata, _frames, _time, status):
        try:
            self.last_in_cb = now = time.monotonic()
            if now - self.started_at > 1.0:  # 開いた直後は数えない（下の入力オーバーフローと同じ）
                peak = max(float(indata.max()), float(-indata.min()))
                if peak > self.in_peak:
                    self.in_peak = peak
            mono = indata.mean(axis=1) if indata.shape[1] > 1 else indata[:, 0]
            try:
                self.inq.put_nowait(mono.copy())
                dropped = False
            except queue.Full:  # 処理スレッドが止まっている。health() で知らせる
                dropped = True
            # 開始直後の報告は数えない（macOS で開始直後に入力オーバーフローが1回報告されることが
            # ある。まだ何も鳴らしていないので、聞こえる途切れにはならない）
            if (status.input_overflow or dropped) and now - self.started_at > 1.0:
                with self.stats.lock:
                    self.stats.overruns += 1
        except Exception:
            pass

    # ---- 音の処理スレッド
    def _pipeline(self):
        try:
            self._pipeline_loop()
        except BaseException:
            traceback.print_exc()  # スレッドは終わる。health() が「音の処理が止まりました」を返す
            raise

    def _pipeline_loop(self):
        block, stats = self.block, self.stats
        fade = int(SAMPLE_RATE * self.FADE_SECONDS)
        nr_raw, voice_raw = Delay(self.nr_delay), Delay(self.voice_delay)
        nr_fade, voice_fade, mon_fade, play_fade = Fader(fade), Fader(fade), Fader(fade), Fader(fade)
        silence = np.zeros(block, dtype=np.float32)
        prev = silence  # 1つ前の入力（雑音除去を使い始めるときに、STFT と先読みを埋める）
        nr_running = None  # 前のブロックで使った雑音除去
        next_settle = time.monotonic() + self.SETTLE_SECONDS
        pending = np.zeros(0, dtype=np.float32)
        gain = self.input_gain  # 今かけている倍率（変えたらブロックの中で移していく。プツッと鳴らさない）
        while self.running.is_set():
            try:
                parts = [self.inq.get(timeout=0.5)]
            except queue.Empty:
                continue
            while True:  # たまっている入力をまとめて取る
                try:
                    parts.append(self.inq.get_nowait())
                except queue.Empty:
                    break
            parts = [p for p in parts if p is not None]  # None は stop() が起こしただけ
            if not parts:
                continue
            pending = np.concatenate([pending, self._in_rs.process(np.concatenate(parts))])
            if len(pending) >= 2 * block:
                # 処理が追いつかずに入力がたまった。古いブロックを捨てて最新に追いつく
                pending = pending[(len(pending) // block - 1) * block:]
                with stats.lock:
                    stats.skips += 1
            while len(pending) >= block and self.running.is_set():
                x, pending = pending[:block], pending[block:]
                t0 = time.perf_counter()
                g0, gain = gain, self.input_gain
                if g0 != 1.0 or gain != 1.0:
                    x = x * gain_ramp(g0, gain, block)
                # 1. 雑音を消す（消さないときも同じだけ遅らせる。OFF の間は回さない。OFF にしたブロックだけは
                #    重ねて切り替えるために回す）
                raw = nr_raw.process(x)
                d = self.denoiser if self.denoise or nr_fade.cur else None
                den = None
                if d is not None:
                    if d is not nr_running:  # 使い始め・OFF の後: 前のブロックを通して STFT・先読みを埋める
                        self._denoise(d, prev, reset=True)
                    den = self._denoise(d, x)
                nr_running = d if den is not None else None
                prev = x
                x = nr_fade.pick(den is not None and self.denoise, raw if den is None else den, raw)
                # 2. 変換（準備ができていれば、ボイチェン OFF でも裏で続ける）
                y, err = self._convert(x) if self.voice_ready else (None, 0)
                # 3. 流す音を選ぶ。ON で変換が無ければ無音（地声を漏らさない）
                y = voice_fade.pick(self.voice, silence if y is None else y, voice_raw.process(x))
                # 異常値（fp16 のあふれ等）とはみ出しを出力の手前で抑える（はみ出した分は割れるので数える）
                y = np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)
                peak = max(float(y.max()), float(-y.min()))
                if peak > self.out_peak:
                    self.out_peak = peak
                np.clip(y, -1.0, 1.0, out=y)
                mon = self.mon
                trimmed = self.out.put(y)
                if mon is not None:
                    # プレビュー: 出力先と同じ音（「自分で聞く」が OFF なら無音）。録って聞くで流している間は録った音。
                    # 切り替えはここで決めて、それぞれ 20ms 重ねる（ON/OFF と、今の音 ↔ 録った音を別々に重ねる。1つで
                    # 3つを切り替えると、重ねる相手を間違えて今の音が漏れる・プツッと鳴る）
                    played = self._recorded(y)
                    live = mon_fade.pick(self.monitor_on, y, silence)
                    mon.put(play_fade.pick(played is not None, silence if played is None else played, live))
                level, out_level = level_db(x), level_db(y)
                # 話していないかは入力の音量をかける前の大きさで見る（音量で削るタイミングが変わらないように）
                quiet = level - 20 * math.log10(max(gain, 1e-6)) < self.QUIET_DB
                if quiet and time.monotonic() >= next_settle:
                    next_settle = time.monotonic() + self.SETTLE_SECONDS
                    trimmed |= self.out.buf.settle()
                    if mon is not None:
                        mon.buf.settle()
                with stats.lock:
                    stats.times.append(time.perf_counter() - t0)
                    stats.errors += err
                    stats.consecutive_errors = stats.consecutive_errors + 1 if err else 0
                    stats.skips += int(trimmed)
                    stats.level_db, stats.out_level_db = level, out_level

    def _recorded(self, y: np.ndarray) -> np.ndarray | None:
        """録って聞く: 出力先に流す音 y を録り、録り終えたら頭から流す。流しているブロックは録った音を、それ以外は
        None を返す（処理スレッドから）。"""
        with self._rec_lock:
            req, self._rec_req = self._rec_req, None
            if req is not None:
                self._rec_buf = np.zeros(req, dtype=np.float32) if req > 0 else None
                self._rec_pos, self._playing = 0, False
            buf, pos = self._rec_buf, self._rec_pos
            if buf is None:
                return None
            n = min(len(y), len(buf) - pos)
            self._rec_pos = pos + n
            done = self._rec_pos >= len(buf)
            if not self._playing:
                buf[pos:pos + n] = y[:n]
                if done:
                    self._playing, self._rec_pos = True, 0
                return None
            if done:
                self._rec_buf, self._playing = None, False
        chunk = buf[pos:pos + n]
        return chunk if n == len(y) else np.pad(chunk, (0, len(y) - n))

    def _denoise(self, d, x, reset: bool = False):
        # torch.set_num_threads(1) にすると 0.2 秒あたり 8ms → 5ms になるが、まだ torch を使っていない・後から
        # 作るスレッド（変換スレッド）まで 1 スレッドになり、CPU で変換するときに遅くなる（Mac で確かめた）ので使わない
        try:
            if reset:
                d.reset()
            return d.process(x)
        except Exception as e:  # 雑音除去が落ちても音は止めない（消さずに流す）
            traceback.print_exc()
            self.denoiser = None
            self.denoise_error = f"{type(e).__name__}: {e}"
            return None

    def _convert(self, x):
        """変換スレッドに1ブロック渡して待つ。(変換した声 か None, 失敗したら 1)"""
        self._seq += 1
        seq = self._seq
        self._conv_in.put((seq, x))
        deadline = time.monotonic() + self.CONVERT_TIMEOUT
        while self.running.is_set():
            try:
                s, y, err = self._conv_out.get(timeout=0.05)
            except queue.Empty:
                if not self._ready.is_set():
                    return None, 0  # 外された（モデルの切り替え中など）
                if time.monotonic() > deadline:
                    self.voice_problem = "変換が止まりました（GPU が応答しません）"
                    print(self.voice_problem, file=sys.stderr, flush=True)
                    return None, 0
                continue
            if s == seq:
                return y, err
        return None, 0

    # ---- 変換スレッド
    def _converter(self):
        engine = None
        while self.running.is_set():
            with self._engine_lock:
                req = self._engine_req[-1:]
                self._engine_req.clear()
            if req:
                engine = None
                self._ready.clear()
                while True:  # 前の engine 用に渡されて、まだ変換していないブロックは捨てる（新しい文脈に混ぜない）
                    try:
                        self._conv_in.get_nowait()
                    except queue.Empty:
                        break
                self._released.set()
                if req[0] is not None:
                    try:
                        req[0].prewarm(**self.options)
                        engine = req[0]
                        with self._engine_lock:
                            if not self._engine_req:  # 試運転の間に替えられていなければ
                                self._ready.set()
                    except BaseException as e:
                        traceback.print_exc()
                        with self._engine_lock:
                            if not self._engine_req:
                                self.engine_error = e.with_traceback(None)
            try:
                item = self._conv_in.get(timeout=0.1)
            except queue.Empty:
                continue
            if item is None or engine is None or self._engine_req:
                continue  # 起こされただけ・外された・替わる。音の処理スレッドは _ready を見て待つのをやめる
            seq, x = item
            try:
                y, err = engine.process(x, **self.options), 0
            except Exception as e:  # 1ブロック落としても止めない。続けて失敗したら表示側で外す
                y, err = None, 1
                if not self.last_error:  # 最初の1回は場所も出す（配布版では log.txt に残る）
                    traceback.print_exc()
                self.last_error = f"{type(e).__name__}: {e}"
                print(f"\n変換エラー: {self.last_error}", file=sys.stderr)
            self._conv_out.put((seq, y, err))
        self._released.set()
