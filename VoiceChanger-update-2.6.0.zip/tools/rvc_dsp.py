"""librosa・scipy を使わずに、リアルタイム変換が使う信号処理だけを持つ。

変換が librosa から使うのは rms・amplitude_to_db（rvc_engine の無音判定と音量の起伏）、本家の RMVPE
（音の高さの推定）が使うのは scipy.signal.get_window・librosa.util.pad_center・librosa.filters.mel だけ。
それなのに librosa を読むと numba・llvmlite・scipy.signal なども読み込まれ、RMVPE の import だけで
約 900 ファイルを開く（Windows では1ファイルごとに Defender の検査を待つので、これが起動の遅さになる）。
ここの関数は librosa 0.10 / scipy と同じ計算（使う引数の範囲で）。一致は Mac で確かめた（HANDOFF 9-44）。

install_rmvpe() は本家の infer/rmvpe.py を読み、librosa・scipy を読む3行だけをここに差し替えて
sys.modules["infer.rmvpe"] にする（行数は変えないので、エラーの行番号は本家のまま）。本家の版が変わって
その3行が見つからなければ何もしない（本家のまま librosa を使う）。
"""

from __future__ import annotations

import importlib.machinery
import sys
import types

import numpy as np

from rvc_common import RVC_ROOT


def get_window(window: str, n: int, fftbins: bool = True) -> np.ndarray:
    """scipy.signal.get_window の "hann" だけ（fftbins=True なら周期的な窓）。"""
    if window != "hann":
        raise NotImplementedError(f"窓 {window!r} は使えません（hann だけ）")
    m = n if fftbins else n - 1
    return 0.5 - 0.5 * np.cos(2.0 * np.pi * np.arange(n) / m)


def pad_center(data: np.ndarray, *, size: int, axis: int = -1, **kwargs) -> np.ndarray:
    """librosa.util.pad_center。"""
    n = data.shape[axis]
    lpad = (size - n) // 2
    lengths = [(0, 0)] * data.ndim
    lengths[axis] = (lpad, size - n - lpad)
    if lpad < 0:
        raise ValueError(f"目標の長さ {size} は元の長さ {n} 以上にしてください")
    return np.pad(data, lengths, **kwargs)


def tiny(x) -> float:
    """librosa.util.tiny。"""
    return np.finfo(np.asarray(x).dtype if np.issubdtype(np.asarray(x).dtype, np.floating) else np.float32).tiny


def normalize(*args, **kwargs):
    raise NotImplementedError("librosa.util.normalize は使えません（RMVPE は読み込むだけで使っていない）")


def _hz_to_mel(f, htk: bool):
    if htk:
        return 2595.0 * np.log10(1.0 + np.asarray(f, dtype=np.float64) / 700.0)
    f = np.asarray(f, dtype=np.float64)
    f_sp, min_log_hz = 200.0 / 3, 1000.0
    min_log_mel, logstep = min_log_hz / f_sp, np.log(6.4) / 27.0
    mels = f / f_sp
    return np.where(f >= min_log_hz, min_log_mel + np.log(np.maximum(f, min_log_hz) / min_log_hz) / logstep, mels)


def _mel_to_hz(m, htk: bool):
    if htk:
        return 700.0 * (10.0 ** (np.asarray(m, dtype=np.float64) / 2595.0) - 1.0)
    m = np.asarray(m, dtype=np.float64)
    f_sp, min_log_hz = 200.0 / 3, 1000.0
    min_log_mel, logstep = min_log_hz / f_sp, np.log(6.4) / 27.0
    return np.where(m >= min_log_mel, min_log_hz * np.exp(logstep * (m - min_log_mel)), f_sp * m)


def mel(*, sr: float, n_fft: int, n_mels: int = 128, fmin: float = 0.0, fmax: float | None = None,
        htk: bool = False, norm: str | None = "slaney", dtype=np.float32) -> np.ndarray:
    """librosa.filters.mel（norm は "slaney" か None）。"""
    if fmax is None:
        fmax = float(sr) / 2
    n_mels = int(n_mels)
    weights = np.zeros((n_mels, 1 + n_fft // 2), dtype=dtype)
    fftfreqs = np.fft.rfftfreq(n=n_fft, d=1.0 / sr)
    mel_f = _mel_to_hz(np.linspace(_hz_to_mel(fmin, htk), _hz_to_mel(fmax, htk), n_mels + 2), htk)
    fdiff = np.diff(mel_f)
    ramps = np.subtract.outer(mel_f, fftfreqs)
    for i in range(n_mels):
        lower = -ramps[i] / fdiff[i]
        upper = ramps[i + 2] / fdiff[i + 1]
        weights[i] = np.maximum(0, np.minimum(lower, upper))
    if norm == "slaney":
        enorm = 2.0 / (mel_f[2:n_mels + 2] - mel_f[:n_mels])
        weights *= enorm[:, np.newaxis]
    elif norm is not None:
        raise NotImplementedError(f"norm={norm!r} は使えません")
    return weights


def rms(y: np.ndarray, frame_length: int, hop_length: int) -> np.ndarray:
    """librosa.feature.rms(y=..., center=True, pad_mode="constant")。形は (1, フレーム数)。"""
    pad = frame_length // 2
    y = np.pad(np.asarray(y), (pad, pad), mode="constant")
    frames = np.lib.stride_tricks.sliding_window_view(y, frame_length)[::hop_length]
    return np.sqrt(np.mean(np.abs(frames) ** 2, axis=-1))[np.newaxis, :]


def amplitude_to_db(S, *, ref: float = 1.0, amin: float = 1e-5, top_db: float | None = 80.0) -> np.ndarray:
    """librosa.amplitude_to_db（ref は数値だけ）。"""
    power = np.square(np.abs(np.asarray(S)))
    db = 10.0 * np.log10(np.maximum(amin ** 2, power))
    db -= 10.0 * np.log10(np.maximum(amin ** 2, abs(ref) ** 2))
    if top_db is not None:
        db = np.maximum(db, db.max() - top_db)
    return db


RMVPE_IMPORTS = {
    "from librosa.util import normalize, pad_center, tiny": "from rvc_dsp import normalize, pad_center, tiny",
    "from scipy.signal import get_window": "from rvc_dsp import get_window",
    "from librosa.filters import mel": "from rvc_dsp import mel",
}


def install_rmvpe() -> bool:
    """本家の RMVPE を、librosa・scipy を読まずに使えるようにする（docstring 参照）。差し替えたら True。"""
    if "infer.rmvpe" in sys.modules:
        return False
    path = RVC_ROOT / "infer" / "rmvpe.py"
    try:
        src = path.read_text(encoding="utf-8")
    except OSError:
        return False
    for old, new in RMVPE_IMPORTS.items():
        if src.count(old) != 1:
            return False  # 本家の版が変わった。本家のまま読む
        src = src.replace(old, new)
    mod = types.ModuleType("infer.rmvpe")
    mod.__file__ = str(path)
    mod.__spec__ = importlib.machinery.ModuleSpec("infer.rmvpe", None, origin=str(path))
    exec(compile(src, str(path), "exec"), mod.__dict__)
    sys.modules["infer.rmvpe"] = mod
    return True
