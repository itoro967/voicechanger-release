"""RVC のストリーミング変換（入力ブロック1つ → 変換後のブロック1つ）。

本家の `RVCRealtimeVST/worker/rvc_worker.py` の `RVCStreamEngine`（MIT）を、
VST との共有メモリ部分を外して持ってきたもの。本家 `realtime_gui.py` のコールバックと
同じ処理で、マイク入力（vc.py）とファイル入力（vc_file.py）の両方から使う。
ファイルで試した結果がそのままリアルタイムの音になるよう、処理は1本にしてある。

ブロックごとの処理:
  1. 入力をリングバッファ（extra + crossfade + block）に足し、16kHz に変換
  2. HuBERT 特徴量 → index で学習データの特徴量に寄せる → RMVPE で F0 → 生成器
  3. 前ブロックの末尾と波形が最も合う位置を探して（SOLA）クロスフェードでつなぐ

`enter_rvc()` の後に import すること。
"""

from __future__ import annotations

import importlib.machinery
import importlib.util
import os
import sys
import types
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import torchaudio.transforms as tat

import faiss

if "parselmouth" not in sys.modules and importlib.util.find_spec("parselmouth") is None:
    # 配布版（vc_package.py）は GPLv3 の praat-parselmouth を入れない。rtrvc は先頭で import する
    # が、使うのは F0 の推定方法 "pm" のときだけ（配布版の窓は rmvpe しか選ばせない）。
    # 先に sys.modules を見るのは、このモジュールの import が途中で失敗して読み直すとき、前回置いた
    # 空のモジュールが残っていて find_spec が ValueError（__spec__ is None）になるため（Windows で起きた）
    stub = types.ModuleType("parselmouth")
    stub.__spec__ = importlib.machinery.ModuleSpec("parselmouth", None)
    sys.modules["parselmouth"] = stub

if os.environ.get("RVC_HUBERT") != "transformers":
    # HuBERT は transformers を使わない版にする（rvc_hubert.py。本家と同じ計算で、読み込みが速い）。
    # 本家と聞き比べたいときは RVC_HUBERT=transformers
    import rvc_hubert  # noqa: E402

    rvc_hubert.install()

# librosa・scipy を読まない（rvc_dsp.py。読むと numba なども付いてきて、RMVPE だけで約 900 ファイル開く）
import rvc_dsp  # noqa: E402

rvc_dsp.install_rmvpe()

from configs.config import Config  # noqa: E402
from infer import rtrvc  # noqa: E402
from tools.cuda_graph import clear_cuda_graph_cache, run_cuda_graph  # noqa: E402

from rvc_realtime import frames, raw_delay_frames  # noqa: E402  ブロック長などの丸め方は Session と同じもの


class Intonation:
    """抑揚（声の高さの上下の幅）を factor 倍にする。中心は、声の高さ（対数）のゆっくりした平均（CENTER_SECONDS
    ほどで追う。話す高さが変わっても付いていく）。中心からの上下（半音）を factor 倍にするので、×1.2 なら中心より
    +5 半音のところが +6 半音になる。f0 の 0（声の無いところ）はそのまま。"""

    CENTER_SECONDS = 2.0
    # 1ブロックで中心を寄せるもとにする差の上限（3 半音）。本家は声の無いところを前後でつなぐので、息・クリックを
    # 1回だけ高い声と取り違えると、そのブロックの中央値ごと飛ぶ。そのとき中心が大きくずれないように
    MAX_DELTA = np.log(2.0) * 3 / 12

    def __init__(self, block_seconds: float):
        self.factor = 1.0
        self.center: float | None = None
        self.alpha = min(1.0, block_seconds / self.CENTER_SECONDS)  # 1ブロックごとに中心を寄せる割合

    def reset(self) -> None:
        self.center = None

    def __call__(self, f0: np.ndarray) -> np.ndarray:
        voiced = f0 > 0
        if not voiced.any():
            return f0
        logf = np.log(f0[voiced])
        m = float(np.median(logf))  # 中心は factor が 1 の間も追う（上げた瞬間から付いていくように）
        if self.center is None:
            self.center = m
        else:
            self.center += self.alpha * max(-self.MAX_DELTA, min(self.MAX_DELTA, m - self.center))
        if self.factor == 1.0:
            return f0
        out = f0.copy()
        out[voiced] = np.exp(self.center + self.factor * (logf - self.center))
        return out


class _RVC(rtrvc.RVC):
    """本家の RVC に抑揚（intonation。StreamEngine が作ってすぐ入れる）を足したもの。本家の関数を外から差し替えると、
    RVC と関数がお互いを指して「解放」で GPU のメモリがすぐ空かなくなるので、サブクラスにする。

    本家は get_f0 で F0 を引数の半音ぶんずらしてから get_f0_post で生成器の形に直す。抑揚の中心はずらす前の声で
    追う（ずらした後で追うと、変換中に高さ・響きを動かしたとき、中心が追いつくまでの 2 秒ほど高さが行き過ぎる）。
    ずらした量は get_f0_post に渡らないので、get_f0 で受け取ったものを覚えておく（本家の式を写さない）。"""

    intonation: Intonation
    _f0_shift = 1.0

    def get_f0(self, x, f0_up_key, method="rmvpe"):
        self._f0_shift = 2.0 ** (f0_up_key / 12)
        return super().get_f0(x, f0_up_key, method)

    def get_f0_post(self, f0):
        f0 = np.asarray(f0, dtype=np.float64).reshape(-1)  # 本家の rmvpe・fcpe・pm はどれも numpy で渡す
        raw = self.intonation(f0 / self._f0_shift)  # 中心はずらす前の声で追う（factor が 1 でも）
        if self.intonation.factor != 1.0:
            # 本家の扱う範囲（f0_min〜f0_max）に収める。ただし、もともと範囲の外だった値は広げた分だけ戻す
            # （×1.00 から ×1.05 にした瞬間に、範囲の外の高さが急に切られないように）
            f0 = np.clip(raw * self._f0_shift, np.minimum(self.f0_min, f0), np.maximum(self.f0_max, f0))
        return super().get_f0_post(f0)

F0_METHODS = ("rmvpe", "fcpe", "pm")

# index の検索は1スレッドで足りる（1ブロック十数ベクトル）。macOS では torch と faiss が
# 別々の OpenMP を抱えていて、faiss を複数スレッドで検索すると segfault する（実測）。
# この設定は**呼んだスレッドにしか効かない**ので、process() の中でも毎回呼ぶ
# （マイク入力では rvc_realtime の変換スレッドから呼ばれる）
faiss.omp_set_num_threads(1)

# index の検索で見る区画数。train_index.py は nprobe=1 で保存するが、rtrvc は近傍 8件のうち
# 1件でも見つからないと**そのブロックだけ index を使わない**（「無効なインデックス」と出る）。
# データが少ないと区画内が8件に満たず、ブロックごとに声質の寄せ方がばらつく。
INDEX_NPROBE = 8
INDEX_K = 8  # rtrvc が1回の検索で取る近傍の数（これより少ない index は、どのブロックでも使えない）
INDEX_MISS_MAX = 0.2  # 試しの検索で近傍がそろわない割合がこれを超えたら「使えない」とする
FEATURE_DIMS = {"v1": 256, "v2": 768}  # HuBERT の特徴量の次元（index の次元と合わないと検索できない）


def read_index_file(path: Path):
    """index を読む。(index, None) か、読めなければ (None, 理由)。IVF の index は検索で見る区画数を INDEX_NPROBE にする。"""
    faiss.omp_set_num_threads(1)
    if not Path(path).is_file():
        return None, "index のファイルが見つかりません（動かしたか、消した）"
    try:
        index = faiss.read_index(str(path))
    except MemoryError:
        return None, "メモリが足りず、index を読めません"
    except Exception as e:
        return None, f"index を読めません（壊れているか、index ではないファイルです。{type(e).__name__}）"
    try:
        faiss.extract_index_ivf(index).nprobe = INDEX_NPROBE
    except RuntimeError:
        pass  # IVF ではない（全部を比べる）index。区画は無く、そのまま検索できる
    return index, None


def check_index(index, version: str) -> str | None:
    """読み込んだ index がこのモデルで使えるか。使えなければ理由（窓に出す）、使えれば None。"""
    want = FEATURE_DIMS.get(version)
    if want is not None and index.d != want:
        kind = next((f"{v} 型（{d} 次元）" for v, d in FEATURE_DIMS.items() if d == index.d), f"{index.d} 次元")
        return f"index は {kind}で、このモデル（{version}・{want} 次元）には使えません"
    if index.ntotal == 0:
        return "index の中身が空です（trained_ で始まる index は学習の途中のもの。added_ で始まるものを選んでください）"
    if index.ntotal < INDEX_K:
        return f"index のデータが少なすぎます（{index.ntotal} 個）"
    # 区画が多くて中身が少ないと、近傍が INDEX_K 個そろわないブロックで rtrvc が index を使わず、ブロックごとに
    # 「索引无效」を出す。index の中のものを試しに検索して確かめる（実際の声の特徴量も学習データの近くに来る）
    sample = index.reconstruct_n(0, min(index.ntotal, 4096))[::max(1, min(index.ntotal, 4096) // 64)]
    miss = float((index.search(sample, INDEX_K)[1] < 0).any(axis=1).mean())
    if miss > INDEX_MISS_MAX:
        return f"index のデータが少なすぎます（{index.ntotal} 個。検索の {miss:.0%} で近いものがそろいません）"
    return None

_faiss_read_index = faiss.read_index


def _read_index(path, *args):
    """faiss.read_index は、パスを C の fopen にそのまま渡すので、Windows では日本語などを含む
    パス（ユーザー名が日本語のフォルダの下など）を開けない。Python で読んでから復元する。
    rtrvc は faiss.read_index を呼ぶので、差し替えておけばそちらにも効く。"""
    if args or str(path).isascii():
        return _faiss_read_index(path, *args)
    return faiss.deserialize_index(np.fromfile(path, dtype=np.uint8))


faiss.read_index = _read_index


class StreamEngine:
    def __init__(
        self,
        model_path: Path,
        index_path: Path | None,
        sample_rate: int,
        block_ms: float = 200,
        crossfade_ms: float = 50,
        extra_ms: float = 2500,
        previous: "StreamEngine | None" = None,
    ):
        self.sample_rate = int(sample_rate)
        self.zc = max(1, self.sample_rate // 100)
        self.block_frame = frames(block_ms, self.sample_rate)
        self.block_frame_16k = 160 * self.block_frame // self.zc
        crossfade_frame = frames(crossfade_ms, self.sample_rate)
        self.crossfade_frame = crossfade_frame
        # 本家 GUI と同じく、実際に重ねるのは最大 40ms
        self.sola_buffer_frame = min(crossfade_frame, 4 * self.zc)
        self.sola_search_frame = self.zc
        # 変換した声は、入力の最新ブロックより crossfade + search（から SOLA のずらし 0〜10ms を引いた分）
        # 遅れて出てくる（推論の切り出しが input_wav の extra_frame から始まるため）。地声を流すときは
        # この分だけ遅らせると時刻がそろう（rvc_realtime.Session の voice_delay）
        self.raw_delay_frame = raw_delay_frames(crossfade_ms, self.sample_rate)  # crossfade + search
        self.extra_frame = frames(extra_ms, self.sample_rate)

        self.config = Config()
        device = self.config.device
        if previous is not None:
            # 使い回す HuBERT・生成器には、前の形（ブロック長など）の CUDA Graph が溜まっている（1つあたり
            # 最大8個）。ブロック長を何度も変えると GPU のメモリを取ったままになるので捨てる
            for owner in (getattr(previous.rvc, "model", None), getattr(previous.rvc, "net_g", None)):
                if owner is not None:
                    clear_cuda_graph_cache(owner)
        # previous を渡すと HuBERT・RMVPE を使い回す（チェックポイントの聞き比べ用）
        self.rvc = _RVC(
            0.0, 0.0, str(model_path), str(index_path) if index_path else "", 0.0,
            self.config, previous.rvc if previous else None,
        )
        if getattr(self.rvc, "net_g", None) is None or not hasattr(self.rvc, "model"):
            # rtrvc.RVC は読み込み失敗（モデル・HuBERT）を握りつぶしてトレースバックを
            # 出すだけで、そのまま進むと最初のブロックで分かりにくく落ちる。ここで止める
            raise RuntimeError(f"モデルを読み込めませんでした（上のトレースバックを参照）: {model_path}")
        self.rvc.intonation = Intonation(self.block_seconds)
        # index は、ここ（モデルを読み込むスレッド）で読んで確かめる。使えなければ理由を index_problem に置き、
        # index を使わずに変換する（違う型の index は、ブロックごとに検索が例外を出してログが埋まる）
        self.index_path = index_path  # 選んだもの（使えなくてもそのまま。次のエンジンが読み直さないように）
        self._index, self._index_error = None, None  # 読んだ index（使えない型でも持つ）と、読めなかった理由
        if index_path is not None:
            if previous is not None and previous.index_path == index_path:
                # 同じ index は読み直さない（聞き比べでモデルだけ替えるとき。index は数百 MB になる）。使えるかは、
                # モデルの版が違うことがあるので確かめ直す
                self._index, self._index_error = previous._index, previous._index_error
            else:
                self._index, self._index_error = read_index_file(index_path)
        self.index_problem = self._index_error or (
            check_index(self._index, getattr(self.rvc, "version", "v2")) if self._index is not None else None)
        if self._index is not None and self.index_problem is None:
            if previous is not None and previous._index is self._index and hasattr(previous.rvc, "big_npy"):
                self.rvc.big_npy = previous.rvc.big_npy
            else:
                try:
                    self.rvc.big_npy = self._index.reconstruct_n(0, self._index.ntotal)
                except MemoryError:
                    self.index_problem = "メモリが足りず、index を読めません"
            if self.index_problem is None:
                self.rvc.index = self._index
        if self.index_problem is not None:
            print(f"index を使いません: {self.index_problem}（{index_path}）", flush=True)
        self.tgt_sr = self.rvc.tgt_sr

        total = self.extra_frame + crossfade_frame + self.sola_search_frame + self.block_frame
        self.input_wav = torch.zeros(total, device=device, dtype=torch.float32)
        self.input_wav_res = torch.zeros(160 * total // self.zc, device=device, dtype=torch.float32)
        self.rms_buffer = np.zeros(4 * self.zc, dtype="float32")
        self.sola_buffer = torch.zeros(self.sola_buffer_frame, device=device, dtype=torch.float32)
        self.sola_den_kernel = torch.ones(1, 1, self.sola_buffer_frame, device=device, dtype=torch.float32)
        self.skip_head = self.extra_frame // self.zc
        self.return_length = (self.block_frame + self.sola_buffer_frame + self.sola_search_frame) // self.zc
        self.fade_in_window = torch.sin(
            0.5 * np.pi * torch.linspace(0.0, 1.0, steps=self.sola_buffer_frame, device=device)
        ) ** 2
        self.fade_out_window = 1 - self.fade_in_window
        self.resampler = tat.Resample(orig_freq=self.sample_rate, new_freq=16000, dtype=torch.float32).to(device)
        self.resampler2 = None
        if self.tgt_sr != self.sample_rate:
            self.resampler2 = tat.Resample(orig_freq=self.tgt_sr, new_freq=self.sample_rate,
                                           dtype=torch.float32).to(device)
        self._pitch = self._formant = self._index_rate = None

    @property
    def index_usable(self) -> bool:
        """index を使って変換するか（選んであり、使える）。"""
        return self.index_path is not None and self.index_problem is None

    @property
    def device(self) -> str:
        return self.config.device

    @property
    def block_seconds(self) -> float:
        return self.block_frame / self.sample_rate

    @property
    def delay_seconds(self) -> float:
        """アルゴリズム由来の遅延（ブロックをためる分 + 重ね合わせの分）。処理時間・出力バッファ・
        デバイスの遅延は含まない。"""
        return (self.block_frame + self.raw_delay_frame) / self.sample_rate

    def reset(self) -> None:
        self.input_wav.zero_()
        self.input_wav_res.zero_()
        self.rms_buffer.fill(0.0)
        self.sola_buffer.zero_()
        self.rvc.cache_pitch.zero_()
        self.rvc.cache_pitchf.zero_()
        self.rvc.intonation.reset()

    def prewarm(self, **opts) -> None:
        """初回の CUDA Graph 作成・RMVPE の読み込み・index の最初の検索を先に済ませる（index を読むのは __init__）。

        本番と同じ設定（opts）で回すこと。設定が違うと、初めての形の処理が本番の最初のブロックで走って
        出だしが詰まる。
        """
        t = torch.arange(self.block_frame, dtype=torch.float32)
        probe = (0.05 * torch.sin(2 * np.pi * 220.0 * t / self.sample_rate)).numpy()
        # 似せる強さが 0 でも index の検索を一度通しておく（あとで上げた最初のブロックが詰まらないように）
        first = dict(opts, index_rate=opts.get("index_rate") or 0.5) if self.index_usable else opts
        for o in (first, opts):
            self.process(probe, **o)
        if torch.device(self.device).type == "cuda":
            torch.cuda.synchronize(self.device)
        self.reset()

    def process(self, audio: np.ndarray, pitch: float = 0.0, formant: float = 0.0, intonation: float = 1.0,
                index_rate: float = 0.0, rms_mix: float = 0.0, threshold_db: float = -60.0,
                f0_method: str = "rmvpe") -> np.ndarray:
        """モノラル float32 の1ブロックを変換して、同じ長さで返す。"""
        if len(audio) != self.block_frame:
            raise ValueError(f"ブロック長が違います: 期待 {self.block_frame}, 実際 {len(audio)}")
        faiss.omp_set_num_threads(1)  # 呼び出し元のスレッドごとに要る（冒頭のコメント）
        self.rvc.intonation.factor = intonation
        if self._pitch != pitch:
            self.rvc.change_key(pitch)
            self._pitch = pitch
        if not getattr(self.rvc, "if_f0", 1):
            formant = 0.0  # F0 の無いモデルは高さを戻せない（本家は響きと一緒に高さも動く）ので、響きは使わない
        if self._formant != formant:
            self.rvc.change_formant(formant)
            self._formant = formant
        if self._index_rate != index_rate:
            if index_rate > 0 and not self.index_usable:
                index_rate = 0.0
            # index は読み込み済み（__init__）。本家の change_index_rate は 0 → 0 より大きい値のたびに index を
            # 読み直す（数百 MB だと変換スレッドが止まって途切れる。窓のスライダーは 0 を通れる）ので使わない
            self.rvc.index_rate = index_rate
            self._index_rate = index_rate

        indata = np.asarray(audio, dtype=np.float32).copy()
        if threshold_db <= -60.0:
            # ゲートを使わない間も直前の音を覚えておく（使い始めたブロックで古い音がつながらないように）
            self.rms_buffer[:] = indata[-len(self.rms_buffer):]
        else:
            # 閾値より小さい 10ms 区間を無音にする（息やキーボードの音を変換させない）
            gated = np.append(self.rms_buffer, indata)
            rms = rvc_dsp.rms(gated, frame_length=4 * self.zc, hop_length=self.zc)[:, 2:]
            self.rms_buffer[:] = gated[-4 * self.zc:]
            gated = gated[2 * self.zc - self.zc // 2:]
            below = rvc_dsp.amplitude_to_db(rms, ref=1.0)[0] < threshold_db
            for i, mute in enumerate(below):
                if mute:
                    gated[i * self.zc:(i + 1) * self.zc] = 0
            indata = gated[self.zc // 2:]

        # 本家 realtime_gui.py（雑音除去なしの経路）と同じ書き方。ゲートが有効だと indata は
        # 前ブロックの末尾 2zc を含む（ゲートで書き換わった分を戻す）。16kHz 側は前ブロックとの
        # 境目の 10ms も、右側の文脈がそろった今回の結果で上書きする
        dev = self.device
        n = indata.shape[0]
        self.input_wav[:-self.block_frame] = self.input_wav[self.block_frame:].clone()
        self.input_wav[-n:] = torch.from_numpy(indata).to(dev)
        self.input_wav_res[:-self.block_frame_16k] = self.input_wav_res[self.block_frame_16k:].clone()
        resample_input = self.input_wav[-n - 2 * self.zc:]
        self.input_wav_res[-160 * (n // self.zc + 1):] = run_cuda_graph(
            self.resampler, "vc-input-resample", lambda v: self.resampler(v), resample_input,
        )[160:]

        infer_wav = self.rvc.infer(
            self.input_wav_res, self.block_frame_16k, self.skip_head, self.return_length, f0_method,
        )
        if self.resampler2 is not None:
            infer_wav = run_cuda_graph(
                self.resampler2, "vc-output-resample", lambda v: self.resampler2(v), infer_wav,
            )

        if rms_mix < 1.0:
            # 出力の音量の起伏を入力に寄せる（0 で入力どおり、1 でモデルの出力のまま）
            input_tail = self.input_wav[self.extra_frame:]
            rms1 = rvc_dsp.rms(input_tail[:infer_wav.shape[0]].cpu().numpy(),
                               frame_length=4 * self.zc, hop_length=self.zc)
            rms1 = torch.from_numpy(rms1).to(dev)
            rms1 = F.interpolate(rms1.unsqueeze(0), size=infer_wav.shape[0] + 1,
                                 mode="linear", align_corners=True)[0, 0, :-1]
            rms2 = rvc_dsp.rms(infer_wav.cpu().numpy(), frame_length=4 * self.zc, hop_length=self.zc)
            rms2 = torch.from_numpy(rms2).to(dev)
            rms2 = F.interpolate(rms2.unsqueeze(0), size=infer_wav.shape[0] + 1,
                                 mode="linear", align_corners=True)[0, 0, :-1]
            rms2 = torch.maximum(rms2, torch.full_like(rms2, 1e-3))
            infer_wav *= torch.pow(rms1 / rms2, 1.0 - rms_mix)

        # SOLA（DDSP-SVC 由来）。前ブロックの末尾と最も相関の高い位置でつなぐ
        conv_input = infer_wav[None, None, :self.sola_buffer_frame + self.sola_search_frame]
        cor_nom = F.conv1d(conv_input, self.sola_buffer[None, None, :])
        cor_den = torch.sqrt(F.conv1d(conv_input ** 2, self.sola_den_kernel) + 1e-8)
        sola_offset = int(torch.argmax(cor_nom[0, 0] / cor_den[0, 0]))
        infer_wav = infer_wav[sola_offset:]
        infer_wav[:self.sola_buffer_frame] *= self.fade_in_window
        infer_wav[:self.sola_buffer_frame] += self.sola_buffer * self.fade_out_window
        self.sola_buffer[:] = infer_wav[self.block_frame:self.block_frame + self.sola_buffer_frame]
        return infer_wav[:self.block_frame].float().cpu().numpy()
