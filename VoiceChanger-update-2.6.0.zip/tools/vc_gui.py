#!/usr/bin/env python
"""リアルタイム音声変換の窓。配布版（VoiceChanger.exe）の本体でもある。

  ./vc gui                     リポジトリから起動（RVC/.venv の Python）
  VoiceChanger.exe                 配布版（tools/vc_package.py で作る）から起動
  … --check [--model X]            環境を表示して終わる（窓は開かない）

変換の中身は `vc run` と同じ（rvc_realtime.Session）。開いたらすぐマイクの音（地声。ノイズ除去は設定
どおり）を出力先に流す。「ロード」でモデルを読み込むと裏で変換が回り始め、「ボイチェン ON/OFF」で変換した声と
地声を一瞬で切り替える（ON の間は、変換の準備ができるまで無音。地声を漏らさない）。デバイス・遅延・モデルは
いつでも替えられる（すぐつなぎ直す・読み込み直す）。見た目は vc_theme.py（暗い色のテーマ）。

モデル（.pth）は次の場所から探す。「参照…」で他の場所のものも選べる。
  - <ルート>/models/ と、その1つ下のフォルダ   配布版。受け取ったモデルを置く
  - RVC/assets/weights/<名前>.pth               リポジトリで学習した最終版（学習を途中で止めて
                                                 最終版が無ければ、最新の途中のモデル）
index は .pth と同じフォルダから、名前にモデル名を含む .index を探す（学習で作られる
added_IVF…_<名前>_v2.index）。RVC/assets/weights のモデルは logs/<名前>/added_*.index。

配布版は pythonw.exe で動くので標準出力が無い。そのときはルートの log.txt に書く。
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
import os
import re
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import Callable, NamedTuple

import vc_update
from rvc_common import (
    FORMANT_RANGE, FORMANT_STEP, INTONATION_RANGE, INTONATION_STEP, MODELS_DIR, PROJECT_ROOT, RVC_ROOT, WEIGHTS_DIR,
    checkpoints, disable_quick_edit, enter_rvc, find_index, fmt_secs, model_base,
    rel_path, snap,
)
from vc_update import read_build_info

APP_NAME = vc_update.APP
# 配布版には同梱の Python（runtime/）がある。設定とログの置き場所が変わる
PACKAGED = (PROJECT_ROOT / "runtime").is_dir()
SETTINGS_PATH = PROJECT_ROOT / "settings.json" if PACKAGED else RVC_ROOT / "vc_gui_settings.json"
LOG_PATH = PROJECT_ROOT / "log.txt" if PACKAGED else RVC_ROOT / "vc_gui.log"

PITCH_RANGE = 24  # 声の高さは ±24 半音まで（響きの範囲・刻みは rvc_common の FORMANT_RANGE・FORMANT_STEP）
class VoiceField(NamedTuple):
    """「声」の欄の1行（スライダー）。"""
    name: str
    lo: float
    hi: float
    step: float
    fmt: Callable[[float], str]  # 値の表し方
    help: str  # 「?」に出す説明


# 「声」の欄の値（高さ・響き・抑揚・似せる強さ・無音にする音量）。スライダー・使う値・覚える値は、どれも
# rvc_common.snap でこの範囲と刻みに丸める。項目を足すときはここ（モデルごとに覚えるなら MODEL_DEFAULTS にも）
VOICE_FIELDS = dict(
    pitch=VoiceField("高さ", -PITCH_RANGE, PITCH_RANGE, 1, lambda v: f"{v:+.0f} 半音",
           "声の高さ（ドレミの高さ）を半音でずらします。男→女は +12 前後、女→男は -12 前後。合わないと感じたら"
           "「録って聞く」で ±2 くらい聞き比べてください。"),
    formant=VoiceField("響き", -FORMANT_RANGE, FORMANT_RANGE, FORMANT_STEP, lambda v: f"{v:+.1f} 半音",
             "高さはそのままで、声の響き（太さ・明るさ。体の大きさの感じ）だけをずらします。男→女で、高さは合って"
             "いるのに声が太い・大人っぽいなら +1〜+3。上げすぎると子どもっぽい・ヘリウムのような声になります。"
             "動かし終えて 0.3 秒後に効きます。"),
    intonation=VoiceField("抑揚", *INTONATION_RANGE, INTONATION_STEP, lambda v: f"×{v:.2f}",
                "声の高さの上下の幅を何倍にするか。×1.00 で入力どおり。女性らしい話し方に寄せるなら ×1.10〜×1.30。"
                "上げすぎると歌うような声に、×1.00 より下げると平板な声になります。F0 の無いモデルでは効きません。"),
    index_rate=VoiceField("似せる強さ", 0.0, 1.0, 0.01, lambda v: f"{v:.2f}",
                "学習した声の特徴（index）にどれだけ寄せるか。上げると似ますが、滑舌が落ちやすくなります。"
                "0.30〜0.75 で聞き比べてください。index が無いと効きません。"),
    threshold=VoiceField("無音にする音量", -60, -20, 1, lambda v: "使わない" if v <= -60 else f"{v:.0f} dB",
               "これより小さい音を無音にします（息・キーボード・環境音を変換させない）。入力メーターの白い線がこの位置"
               "です。いちばん左で「使わない」。"),
)
# モデルごとに覚える値の既定（前の版の設定に無い項目も）。無音にする音量はモデルによらず共通
MODEL_DEFAULTS = dict(pitch=0, formant=0.0, intonation=1.0, index_rate=0.5)
# 響きは、続けて変えている間は変換に渡さず、止まってからこれだけ待って1回だけ渡す（値ごとに GPU の準備を作り直して
# 一瞬止まるので）。高さなどはすぐ（次のブロックから）
FORMANT_DELAY_MS = 300
BLOCK_CHOICES = (100, 150, 200, 250, 300, 400, 600)
BUFFER_CHOICES = (0, 25, 50, 100, 150, 250)
DEFAULTS = dict(model="", index="", input="", output="", preview="", preview_on=True, preview_volume=100,
                pitch=MODEL_DEFAULTS["pitch"], index_rate=MODEL_DEFAULTS["index_rate"], threshold=-60, block_ms=200,
                buffer_ms=50, denoise=True, loaded=False,
                voice=False, voice_resume=False, output_chosen=False, input_volume=100,
                model_user="", model_password="")  # 声のモデルの置き場所の ID・パスワード（「取ってくる…」）
NO_INDEX = "（なし）"
NO_PREVIEW = "（なし）"
INDEX_WIDTH = 44  # index のファイル名の欄の幅（文字）。長い名前は途中を省く（窓の幅を変えないため）
# マイクの音（振幅 0〜1）がこれ以上なら音が割れている（0 dBFS に張り付いた。16bit の最大は 0.99997 なので
# 1.0 ちょうどでは比べない）
CLIP_LEVEL = 0.99
INPUT_VOLUME_MAX = 200  # 入力の音量（%）の上限
RECORD_SECONDS = 5  # 録って聞くの長さ

# 「ロード」から変換が始まるまでの段階（名前、窓に出す説明）。所要時間はログにも残す
STAGES = (
    ("libs", "ライブラリ", "ライブラリを読み込んでいます（初回は数分かかることがあります）"),
    ("model", "モデル", "モデルを読み込んでいます"),
    ("warmup", "試運転", "試運転しています（GPU の準備）"),
)


class Progress:
    """「ロード」の各段階の始まりと終わりの時刻。読み込みスレッドが書き、窓のスレッドが読む。"""

    def __init__(self):
        self.t0 = time.monotonic()
        self.begun: dict[str, float] = {}
        self.ended: dict[str, float] = {}

    def begin(self, key: str) -> None:
        self.begun.setdefault(key, time.monotonic())

    def end(self, key: str) -> None:
        self.begin(key)
        self.ended.setdefault(key, time.monotonic())

    def summary(self) -> str:
        parts = [f"{name} {self.ended.get(k, time.monotonic()) - self.begun[k]:.1f} 秒"
                 for k, name, _ in STAGES if k in self.begun]
        return " / ".join(parts) + f"（合計 {time.monotonic() - self.t0:.1f} 秒）"

    def text(self) -> str:
        """今の段階の説明と経過（窓に出す）。"""
        doing = next((text for k, _, text in reversed(STAGES) if k in self.begun), STAGES[0][2])
        return f"{doing}… {fmt_secs(time.monotonic() - self.t0)}"


# 学習で付く index の名前（本家 train_index.py: added_IVF<区画数>_Flat_nprobe_<n>_<名前>_<版>.index。assets/indices の
# 写しは頭に <名前>_ が付く）から、モデルの名前を取り出す
INDEX_NAME = re.compile(r"added_IVF\d+_Flat_nprobe_\d+_(?P<name>.+)_v\d$", re.IGNORECASE)


def index_mismatch(model: Path | None, index: Path | None) -> str:
    """index がモデルのものではなさそうなら知らせの文、合いそうなら空。別の人の index は、読み込んでもエラーに
    ならず、声がその人の学習データに寄るだけで気づけない（2026-11-03 に Mac で確かめた）。

    学習で付く名前なら、中のモデルの名前が同じか（taro に taro_style の index を合うとしない）。それ以外の名前は
    guess_index と同じ決まり（<名前>.index・…_<名前>_v2.index）。フォルダに .pth と .index が1つずつなら、置いた人が
    組にしたものとして知らせない（guess_index もそれを選ぶ）。"""
    if model is None or index is None:
        return ""
    name = model_base(model)
    m = INDEX_NAME.search(index.stem)
    if m:
        ok = m.group("name").lower() == name.lower()
    else:
        ok = re.search(rf"(^|_){re.escape(name)}(_v\d)?$", index.stem, re.IGNORECASE) is not None
    if ok or (index.parent == model.parent and len(list(model.parent.glob("*.pth"))) == 1
              and [p for p in model.parent.glob("*.index") if not p.name.startswith("trained_")] == [index]):
        return ""
    return (f"index「{elide(index.name, INDEX_WIDTH)}」はモデル「{name}」のものではないかもしれません（名前が合いません）。"
            "別の人の index だと、声がその人に寄ります（同じ声のものなら、このままで大丈夫です）")


def guess_index(pth: Path) -> Path | None:
    """.pth に合う index。

    同じフォルダの .index のうち、学習で付く名前（added_IVF…_<名前>_v2.index）がモデル名と一致する
    もの。無ければ名前にモデル名を含むもの、それも無ければフォルダにモデルが1つだけなら唯一の .index。
    （含むだけで選ぶと、taro に taro2 の index を選ぶことがある）。trained_*.index は学習の
    途中生成物で中身が空なので使わない。
    """
    name = model_base(pth)  # 途中のモデル（<名前>_e20_s1234）も <名前> で探す
    if pth.parent == WEIGHTS_DIR:
        return find_index(name)
    if pth.parent.name == "weights" and pth.parent.parent.name == "assets":
        # 別の RVC の学習結果（配布版から「参照…」でリポジトリのモデルを選んだときなど）。
        # index は RVC/logs/<名前>/added_*.index にある
        logs = sorted((pth.parent.parent.parent / "logs" / name).glob("added_*.index"),
                      key=lambda q: q.stat().st_mtime)
        if logs:
            return logs[-1]
    cands = [p for p in pth.parent.glob("*.index") if not p.name.startswith("trained_")]
    exact = re.compile(rf"(^|_){re.escape(name)}(_v\d)?\.index$", re.IGNORECASE)
    named = [p for p in cands if exact.search(p.name)] or [p for p in cands if name.lower() in p.name.lower()]
    if named:
        return max(named, key=lambda p: p.stat().st_mtime)
    if len(cands) == 1 and len(list(pth.parent.glob("*.pth"))) == 1:
        return cands[0]
    return None


def find_models() -> list[Path]:
    found: list[Path] = []
    if MODELS_DIR.is_dir():
        # 3階層下まで（zip を「すべて展開」すると models\<名前>\<名前>\<名前>.pth になりがち）
        for pattern in ("*.pth", "*/*.pth", "*/*/*.pth", "*/*/*/*.pth"):
            # ドットで始まるフォルダ（取ってくる途中の models/.<名前>.download/ など）の中は出さない
            found += sorted(p for p in MODELS_DIR.glob(pattern)
                            if not any(part.startswith(".") for part in p.relative_to(MODELS_DIR).parts))
    if WEIGHTS_DIR.is_dir():
        # モデルごとに最終版。学習を途中で止めて最終版が無ければ、最新の途中のモデル
        for name in sorted({model_base(p) for p in WEIGHTS_DIR.glob("*.pth")}):
            final = WEIGHTS_DIR / f"{name}.pth"
            ckpts = checkpoints(name)
            if final.exists() or ckpts:
                found.append(final if final.exists() else ckpts[-1])
    return found


def elide(text: str, width: int) -> str:
    """長すぎる文字列の途中を … で省く。"""
    if len(text) <= width:
        return text
    half = (width - 1) // 2
    return text[:half] + "…" + text[-(width - 1 - half):]


def labels_for(items, name, key):
    """表示名 → 値。表示名が重なるものには key(item) を添えて区別する。"""
    names = [name(i) for i in items]
    out = {}
    for i, n in zip(items, names):
        out[n if names.count(n) == 1 else f"{n}  [{key(i)}]"] = i
    return out


def clamp_voice(key: str, v) -> float:
    """声の欄の値を VOICE_FIELDS の範囲と刻みに丸める。数でない・inf・nan は ValueError。"""
    f = VOICE_FIELDS[key]
    return snap(v, f.lo, f.hi, f.step)


def clean_model_entry(e: dict) -> dict:
    """モデルごとに覚える値（MODEL_DEFAULTS のキー）を範囲に収める。無い・壊れた項目は既定値にする（1つ壊れて
    いても、ほかの値は残す）。"""
    out = {}
    for key, default in MODEL_DEFAULTS.items():
        try:
            out[key] = clamp_voice(key, e.get(key, default))
        except (TypeError, ValueError):
            out[key] = default
    out["pitch"] = int(out["pitch"])
    return out


def clean_per_model(v) -> dict:
    """settings.json の per_model（モデル名 → clean_model_entry の値）。dict でない項目は捨てる。"""
    if not isinstance(v, dict):
        return {}
    return {str(key): clean_model_entry(e) for key, e in v.items() if isinstance(e, dict)}


def load_settings() -> dict:
    """設定を読む。壊れている・型が違う項目は既定値にする（起動できなくならないように）。"""
    s = dict(DEFAULTS)
    s["per_model"] = {}
    s["models_seen"] = {}  # 「取ってくる…」の一覧で見たモデルの版（名前 → vc_update.model_version。もう知らせない）
    try:
        data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return s
    if not isinstance(data, dict):
        return s
    for key, default in DEFAULTS.items():
        v = data.get(key, default)
        try:
            if isinstance(default, bool):
                s[key] = bool(v)
            elif isinstance(default, str):
                s[key] = v if isinstance(v, str) else default
            else:
                s[key] = type(default)(v)
        except (TypeError, ValueError):
            s[key] = default
    if s["block_ms"] not in BLOCK_CHOICES:
        s["block_ms"] = DEFAULTS["block_ms"]
    if s["buffer_ms"] not in BUFFER_CHOICES:
        s["buffer_ms"] = DEFAULTS["buffer_ms"]
    s["input_volume"] = min(INPUT_VOLUME_MAX, max(0, s["input_volume"]))
    for key in ("pitch", "index_rate", "threshold"):  # 声の欄の値（inf・nan などで起動できなくならないように）
        try:
            s[key] = type(DEFAULTS[key])(clamp_voice(key, s[key]))
        except ValueError:
            s[key] = DEFAULTS[key]
    if "output_chosen" not in data:
        # 前の版は「開始」を押したときに出力先を保存していた（自分で選んで使った）
        s["output_chosen"] = bool(s["output"])
    if "per_model" in data:
        s["per_model"] = clean_per_model(data["per_model"])
    elif s["model"]:
        # 前の版はモデルごとに分けていなかった。最後に使ったモデルの値として引き継ぐ（モデル名でまとめる。
        # 途中のモデル（<名前>_e20_s1234）も最終版と同じ値を使うので、エポックを選び直しても合わせ直さなくてよい）
        s["per_model"] = clean_per_model({model_base(Path(s["model"])): dict(pitch=s["pitch"],
                                                                              index_rate=s["index_rate"])})
    seen = data.get("models_seen")
    if isinstance(seen, dict):
        s["models_seen"] = {k: v for k, v in seen.items() if isinstance(v, str)}
    return s


def save_settings(s: dict) -> None:
    """一時ファイルに書いてから置き換える（書いている途中で落ちても壊れない）。"""
    try:
        tmp = SETTINGS_PATH.with_name(SETTINGS_PATH.name + ".tmp")
        tmp.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, SETTINGS_PATH)
    except OSError:
        pass


def path_to_setting(p: Path | None) -> str:
    """アプリのフォルダの中なら相対パスで残す（フォルダごと移してもモデルを見失わない）。"""
    return rel_path(p) if p is not None else ""


def path_from_setting(s: str) -> Path | None:
    if not s:
        return None
    p = Path(s)
    return p if p.is_absolute() else PROJECT_ROOT / p


def nvidia_driver_version() -> str:
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
                           capture_output=True, text=True, timeout=10,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return r.stdout.strip().splitlines()[0] if r.returncode == 0 and r.stdout.strip() else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def load_libraries(after_torch=None) -> dict[str, float]:
    """torch・CUDA・RVC 本体を順に読み込み、それぞれにかかった秒数を返す。after_torch は torch を読んだ直後に呼ぶ
    （雑音除去は torch だけで動くので、CUDA の初期化や RVC 本体を待たずに効かせる）。

    「ロード」に数分かかる原因を切り分けるため（Windows の配布版で、ライブラリの読み込みに 149〜284 秒
    かかった。うち transformers が 96 秒で、HuBERT を transformers なしで動かすようにした）。
    enter_rvc() の後に呼ぶ。
    """
    times = {}
    t = time.perf_counter()
    torch = importlib.import_module("torch")
    times["torch"] = time.perf_counter() - t
    if after_torch is not None:
        after_torch()
    t = time.perf_counter()
    if torch.cuda.is_available():
        torch.zeros(1, device="cuda")
        torch.cuda.synchronize()
    times["CUDA の初期化"] = time.perf_counter() - t
    t = time.perf_counter()
    importlib.import_module("rvc_engine")  # configs.config が GPU を調べる（CUDA Graph の試し撮りもする）
    times["RVC 本体"] = time.perf_counter() - t
    return times


def load_error_text(e: BaseException) -> str:
    """ロード・試運転で落ちたときに窓に出す文。"""
    if isinstance(e, MemoryError) or "out of memory" in str(e).lower():
        return (f"GPU のメモリが足りません。\n\n{e}\n\n"
                "ゲームなど GPU を使うアプリを閉じてから、もう一度「ロード」してください。")
    return (f"モデルを読み込めませんでした。\n\n{type(e).__name__}: {e}\n\n"
            f"詳しい内容は {LOG_PATH if PACKAGED else 'コンソール'} にあります。")


def fmt_times(times: dict[str, float]) -> str:
    return f"{sum(times.values()):.1f} 秒（" + " / ".join(f"{k} {v:.1f}" for k, v in times.items()) + "）"


def check(model_arg: str | None, index_arg: str | None = None) -> int:
    """環境を表示する（困ったときに debug.bat から出してもらう）。

    変換の速さも測る。モデルは --model、無ければ見つかった最初のモデル（無ければ測らない）。
    """
    import platform

    info = read_build_info()
    if info:
        print(f"版      {info.get('version', '?')}  （{info.get('date', '?')}、{info.get('commit', '?')}）")
    print(f"Python  {platform.python_version()}  {sys.executable}")
    print(f"場所    {PROJECT_ROOT}{'  （配布版）' if PACKAGED else ''}")
    print(f"OS      {platform.platform()}")
    model = None
    if model_arg:
        model = Path(model_arg).resolve()
        if not model.exists():
            from rvc_common import find_model

            model = find_model(model_arg)
    else:
        model = next(iter(find_models()), None)
    index = Path(index_arg).resolve() if index_arg else (guess_index(model) if model else None)
    enter_rvc()

    lib_times = load_libraries()
    import numpy as np
    import sounddevice as sd
    import torch

    from rvc_realtime import (
        CABLE_LOOPBACK, CROSSFADE_MS, DEFAULT_HOSTAPI, DEFAULT_OUTPUT, SAMPLE_RATE, default_device, devices,
    )

    print(f"torch   {torch.__version__}（CUDA {torch.version.cuda}）")
    ok = True
    if torch.cuda.is_available():
        arch = torch.cuda.get_arch_list()
        for i in range(torch.cuda.device_count()):
            major, minor = torch.cuda.get_device_capability(i)
            mem = torch.cuda.get_device_properties(i).total_memory / 1024**3
            supported = f"sm_{major}{minor}" in arch
            ok &= supported
            print(f"GPU {i}   {torch.cuda.get_device_name(i)}  sm_{major}{minor}  {mem:.1f} GB"
                  f"{'' if supported else '  ← この torch はこの GPU に対応していません'}")
        print(f"        対応: {' '.join(arch)}")
    else:
        ok = False
        reason = ""
        try:  # 使えない理由（ドライバが古い など）。torch は警告を出すだけで理由を返さない
            torch.cuda.init()
        except Exception as e:
            reason = str(e).strip().splitlines()[0] if str(e).strip() else type(e).__name__
        print("GPU     使えません（NVIDIA の GPU とドライバが要ります）" + (f"\n        {reason}" if reason else ""))
    driver = nvidia_driver_version()
    print(f"ドライバ {driver or '不明（nvidia-smi が見つからない）'}"
          + ("  ← CUDA 12.8 には 528.33 以降（推奨 570 以降）が要ります"
             if driver and driver.split(".")[0].isdigit() and int(driver.split(".")[0]) < 528 else ""))

    print(f"音声    {sd.get_portaudio_version()[1]}")
    for kind in ("input", "output"):
        names = [d["name"] for d in devices(sd, kind, DEFAULT_HOSTAPI)]
        try:
            d = sd.query_devices(default_device(sd, kind, DEFAULT_HOSTAPI))
            name = f"{d['name']}（{int(d['default_samplerate'])} Hz）"
        except Exception:
            name = "（なし）"
        print(f"  既定の{'入力' if kind == 'input' else '出力'}: {name}（{len(names)} 個）")
        if kind == "input" and CABLE_LOOPBACK in name:
            print(f"    ← 既定の録音デバイスが {CABLE_LOOPBACK} です。窓でマイクを選んでください")
        if kind == "output" and not any(DEFAULT_OUTPUT in n for n in names):
            print(f"    ← {DEFAULT_OUTPUT}（VB-CABLE）がありません。Discord に流すには要ります")

    import rvc_denoise
    from rvc_engine import StreamEngine

    print(f"時間    ライブラリの読み込み {fmt_times(lib_times)}")
    t = time.perf_counter()
    den = rvc_denoise.Denoiser()
    load = time.perf_counter() - t
    noise = (0.01 * np.random.default_rng(0).standard_normal(9600)).astype(np.float32)
    times = []
    for _ in range(10):
        t0 = time.perf_counter()
        den.process(noise)
        times.append(time.perf_counter() - t0)
    print(f"雑音除去 0.2 秒あたり {1000 * sorted(times)[5]:.0f} ms（最大 {1000 * max(times):.0f}、CPU。"
          f"読み込み {load:.1f} 秒）")
    if model is None:
        print(f"モデル  なし（{MODELS_DIR} に置くと、変換の速さも測ります）")
        return 0 if ok else 1
    print(f"モデル  {model.name}  index: {index.name if index else 'なし'}")
    t = time.perf_counter()
    engine = StreamEngine(model, index, SAMPLE_RATE, 200, CROSSFADE_MS, 2500)
    print(f"時間    モデルの読み込み {time.perf_counter() - t:.1f} 秒")
    if engine.index_problem:
        print(f"index   使えません: {engine.index_problem}（速さは index なしで測ります）")
    opts = dict(pitch=0, index_rate=0.5 if engine.index_usable else 0.0, threshold_db=-60.0, f0_method="rmvpe")
    t = time.perf_counter()
    engine.prewarm(**opts)
    print(f"時間    試運転 {time.perf_counter() - t:.1f} 秒")
    t = np.arange(engine.block_frame) / SAMPLE_RATE
    times = []
    for k in range(20):
        f0 = 150 + 50 * np.sin(k / 3)
        x = sum(0.1 / h * np.sin(2 * np.pi * f0 * h * t) for h in range(1, 6)).astype(np.float32)
        t0 = time.perf_counter()
        engine.process(x, **opts)
        times.append(time.perf_counter() - t0)
    block = 1000 * engine.block_seconds
    avg, worst = 1000 * sum(times) / len(times), 1000 * max(times)
    print(f"変換    1ブロック {avg:.0f} ms（最大 {worst:.0f}）/ {block:.0f} ms  （{engine.device}）")
    if torch.cuda.is_available():
        print(f"        VRAM {torch.cuda.max_memory_reserved() / 1024**2:.0f} MB")
    if worst > block * 0.7:
        ok = False
        print("        ← 間に合わない可能性があります。ブロック長を伸ばすか、GPU を確かめてください")
    return 0 if ok else 1


class App:
    def __init__(self, root, sd):
        import tkinter as tk
        from tkinter import ttk

        import vc_theme as theme

        self.tk, self.ttk, self.root, self.sd, self.theme = tk, ttk, root, sd, theme
        # 高 DPI（Windows の表示スケール 150% など）では、ピクセルで決めた幅も合わせて大きくする
        # （文字は Tk が大きくするので、そのままだと折り返しやスライダーが窮屈になる）
        self.scale = theme.ui_scale(root)
        self.settings = load_settings()
        # 声の高さ・響き・抑揚・似せる強さはモデルごとに覚える（変えたらすぐ保存する）
        self.per_model: dict = self.settings["per_model"]
        self.model_key: str | None = None
        self.save_job = None
        self.formant_job = None
        self.models: dict = {}
        self.inputs: dict = {}
        self.outputs: dict = {}
        self.missing_devices: dict = {}
        self.session = None  # 音の流れ（起動したらすぐ開く。デバイス・遅延を変えたら開き直す）
        self.audio_error = ""  # 開けなかった・止まった理由
        # 出力先を自分で選んだか。選ぶまでは CABLE Input 以外に流さない（VB-CABLE が無いと既定のスピーカーに
        # なり、マイクが拾ってハウリングする）
        self.output_chosen = bool(self.settings["output_chosen"])
        self.notices: dict[str, tuple[str, str]] = {}  # 状態の下に出す知らせ（出どころ → (文, 種類)）
        self.mon_warned = ""
        # ロードしたモデル（rvc_engine.StreamEngine）。読み込みスレッドが作り、変換スレッドが試運転する
        self.engine = None
        self.engine_key = None
        self.loading = False
        self.load_result: tuple | None = None  # 読み込みスレッドの結果
        self.progress: Progress | None = None
        self.gpu_text = ""
        # ボイチェン ON のまま閉じたら、次も ON で始める（ロードが済むまでは無音。自動更新で開き直したときに
        # 地声が漏れないように）。ロードしていなかったなら OFF（地声）
        self.voice_on = bool(self.settings["voice"] and self.settings["loaded"])
        # ON のまま「解放」した（地声にした）。次にロードが済んだら ON に戻す。解放したまま・その後の読み込みの途中で
        # 閉じても覚えておく（voice とは別に残す。変換が止まって外れた ON は今までどおり次は OFF で始める）
        self.voice_resume = bool(self.settings["voice_resume"]) and not self.voice_on
        self.deferred = None  # 試運転が終わるまで後回しにした操作（デバイスの開き直し・再検索）
        self.denoise_model = None  # 雑音除去のモデル（先読みのスレッドが読む。CPU で動かす）
        self.denoise_failed = False
        self.libs_ok = False  # ライブラリ（torch・RVC 本体）を読めた
        self.n_tick = 0
        self.preloaded = threading.Event()  # ライブラリの先読みが終わった（成功でも失敗でも）
        # 自動更新（vc_update.py）。裏のスレッドが結果を入れ、窓のスレッド（tick）が知らせる
        self.update_info = None
        self.update_offered = False
        self.update_stage: str | None = None  # download（取っている・入れ替えを待っている）→ apply（入れ替えている）
        self.update_fraction = 0.0
        self.update_zip: Path | None = None  # 取り終えた更新ファイル
        self.update_result: tuple | None = None
        self.model_list: dict | None = None  # 起動したときに裏で取った、配っている声のモデルの一覧（tick が知らせる）

        version = read_build_info().get("version")
        self.title_base = f"{APP_NAME} {vc_update.label(version)}" if version else APP_NAME
        root.title(self.title_base)
        root.resizable(False, False)
        theme.apply(root)
        px = self.px
        outer = ttk.Frame(root, padding=px(14))
        outer.grid(sticky="nsew")

        # ---- いつも触るもの（上）: 今流している音とボイチェン、モデルとロード、ノイズ除去と入力
        top = ttk.Frame(outer, style="Card.TFrame", padding=px(16))
        top.grid(row=0, column=0, columnspan=2, sticky="ew")
        top.columnconfigure(1, weight=1)
        self.dot = theme.Dot(top, px(14))
        self.dot.grid(row=0, column=0, sticky="w", padx=(0, px(10)))
        self.status_var = tk.StringVar()
        ttk.Label(top, textvariable=self.status_var, style="Status.TLabel").grid(row=0, column=1, sticky="w")
        self.detail_var = tk.StringVar()
        ttk.Label(top, textvariable=self.detail_var, style="Dim.TLabel", wraplength=px(760), justify="left").grid(
            row=1, column=1, sticky="nw", pady=(px(2), 0))
        # 説明が1行でも2行でも窓の高さが変わらないように、2行分を取っておく
        from tkinter import font as tkfont

        top.rowconfigure(1, minsize=2 * tkfont.nametofont("SunValleyBodyFont").metrics("linespace") + px(4))

        # 使う順に左から: モデルを選ぶ → ロード → ボイチェン ON/OFF
        mdl = ttk.Frame(top)
        mdl.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(px(14), 0))
        mdl.columnconfigure(1, weight=1)
        ttk.Label(mdl, text="モデル").grid(row=0, column=0, sticky="w", padx=(0, px(12)))
        self.model_var = tk.StringVar()
        self.model_box = ttk.Combobox(mdl, textvariable=self.model_var, state="readonly", width=40)
        self.model_box.grid(row=0, column=1, sticky="ew")
        self.model_box.bind("<<ComboboxSelected>>", lambda e: self.on_model_selected(reload=True))
        mb = ttk.Frame(mdl)
        mb.grid(row=0, column=2, padx=(px(8), 0))
        ttk.Button(mb, text="参照…", command=self.browse_model).pack(side="left")
        # 配った人が置いた声のモデルを取る（ID・パスワードが要る）
        ttk.Button(mb, text="取ってくる…", command=self.open_model_fetch).pack(side="left", padx=(px(6), 0))
        self.fetch_win = None
        # ロード: モデルを読み込んで裏で変換を回し始める（読み込んだ後は「解放」で GPU を空ける）
        self.load_btn = theme.PillButton(mdl, px(130), px(64), self.toggle_load)
        self.load_btn.grid(row=0, column=3, rowspan=2, padx=(px(18), 0))
        # ボイチェン: 流す音を変換した声と地声で切り替える（一瞬。ロードが済むと押せる）
        self.voice_btn = theme.PillButton(mdl, px(230), px(64), self.toggle_voice)
        self.voice_btn.grid(row=0, column=4, rowspan=2, padx=(px(10), 0))
        ttk.Label(mdl, text="index", style="Dim.TLabel").grid(row=1, column=0, sticky="w", pady=(px(8), 0))
        self.index_var = tk.StringVar(value=NO_INDEX)
        ttk.Label(mdl, textvariable=self.index_var, style="Dim.TLabel", width=INDEX_WIDTH).grid(
            row=1, column=1, sticky="w", pady=(px(8), 0))
        ttk.Button(mdl, text="参照…", command=self.browse_index).grid(row=1, column=2, padx=(px(8), 0),
                                                                     pady=(px(8), 0))
        self.index_path: Path | None = None

        ttk.Separator(top).grid(row=3, column=0, columnspan=3, sticky="ew", pady=px(14))
        # 入力（マイク）と出力（Discord に流す音）のメーター。入力の横に音量、出力の横に「録って聞く」
        mf = ttk.Frame(top)
        mf.grid(row=4, column=0, columnspan=3, sticky="ew")
        mf.columnconfigure(4, weight=1)
        self.denoise_var = tk.BooleanVar(value=bool(self.settings["denoise"]))
        ttk.Checkbutton(mf, text="ノイズ除去", style="Switch.TCheckbutton", variable=self.denoise_var,
                        command=self.on_denoise).grid(row=0, column=0, rowspan=2, sticky="w")
        meters = []
        for r, name in enumerate(("入力", "出力")):
            pady = (px(8) if r else 0, 0)
            ttk.Label(mf, text=name, style="Dim.TLabel").grid(row=r, column=1, sticky="w", padx=(px(28), px(10)),
                                                              pady=pady)
            meters.append(theme.Meter(mf, px(300), px(8)))
            meters[-1].grid(row=r, column=2, sticky="w", pady=pady)
        self.in_meter, self.out_meter = meters
        vf = ttk.Frame(mf)
        vf.grid(row=0, column=3, sticky="w", padx=(px(12), 0))
        # 入力の音量（マイクの後でかけるので、マイク自体で割れた音は直らない）
        self.in_vol = tk.DoubleVar(value=float(self.settings["input_volume"]))
        self._volume(vf, self.in_vol, INPUT_VOLUME_MAX, "input_gain", gap=0)
        rf = ttk.Frame(mf)
        rf.grid(row=1, column=3, columnspan=2, sticky="w", padx=(px(12), 0), pady=(px(8), 0))
        self.rec_btn = ttk.Button(rf, text="録って聞く", width=10, command=self.toggle_recording)
        self.rec_btn.pack(side="left")
        self.rec_text = tk.StringVar()
        self.rec_shown = None
        ttk.Label(rf, textvariable=self.rec_text, style="Caption.TLabel", width=34).pack(side="left",
                                                                                        padx=(px(8), 0))
        self.delay_var = tk.StringVar()
        ttk.Label(mf, textvariable=self.delay_var, style="Dim.TLabel").grid(row=0, column=4, sticky="e")
        self.notice_label = ttk.Label(top, wraplength=px(760), justify="left")
        self.notice_label.grid(row=5, column=0, columnspan=3, sticky="w", pady=(px(12), 0))
        self.notice_label.grid_remove()  # 知らせがあるときだけ出す

        left, right = ttk.Frame(outer), ttk.Frame(outer)
        left.grid(row=1, column=0, sticky="nsew", pady=(px(12), 0), padx=(0, px(6)))
        right.grid(row=1, column=1, sticky="nsew", pady=(px(12), 0), padx=(px(6), 0))

        def card(parent, title: str, note: str = ""):
            c = ttk.Frame(parent, style="Card.TFrame", padding=px(14))
            c.pack(fill="x", pady=(0, px(12)))
            c.columnconfigure(1, weight=1)
            h = ttk.Frame(c)
            h.grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, px(6)))
            ttk.Label(h, text=title, style="Section.TLabel").pack(side="left")
            if note:
                ttk.Label(h, text=note, style="Caption.TLabel").pack(side="left", padx=(px(10), 0))
            return c

        def label(c, text: str, r: int):
            ttk.Label(c, text=text).grid(row=r, column=0, sticky="w", padx=(0, px(12)), pady=px(4))

        # ---- 声（変換中も変えられる）
        c = card(left, "声", "モデルごとに覚えます（変えるとすぐ保存）")
        # 値は self.voice[キー]（VOICE_FIELDS のキー）。始めは前回の設定（モデルを選ぶと、そのモデルの値に替わる）
        start = dict(MODEL_DEFAULTS, pitch=self.settings["pitch"], index_rate=self.settings["index_rate"],
                     threshold=self.settings["threshold"])
        self.voice = {key: tk.DoubleVar(value=float(start[key])) for key in VOICE_FIELDS}
        for r, (key, f) in enumerate(VOICE_FIELDS.items(), 1):
            label(c, f.name, r)
            self._slider(c, r, self.voice[key], f, self.on_option_changed)

        # ---- 遅延（変えたらすぐ開き直す。ブロックを変えるとモデルも読み込み直す）
        c = card(left, "遅延", "途切れるときは増やす（そのぶん遅れる）")
        df = ttk.Frame(c)
        df.grid(row=1, column=0, columnspan=3, sticky="w", pady=px(4))
        ttk.Label(df, text="ブロック").pack(side="left")
        self.block_var = tk.StringVar(value=str(int(self.settings["block_ms"])))
        self.block_box = ttk.Combobox(df, textvariable=self.block_var, state="readonly", width=5,
                                      values=[str(v) for v in BLOCK_CHOICES])
        self.block_box.pack(side="left", padx=(px(6), px(4)))
        ttk.Label(df, text="ms").pack(side="left")
        ttk.Label(df, text="余裕").pack(side="left", padx=(px(20), 0))
        self.buffer_var = tk.StringVar(value=str(int(self.settings["buffer_ms"])))
        self.buffer_box = ttk.Combobox(df, textvariable=self.buffer_var, state="readonly", width=5,
                                       values=[str(v) for v in BUFFER_CHOICES])
        self.buffer_box.pack(side="left", padx=(px(6), px(4)))
        ttk.Label(df, text="ms").pack(side="left")
        self.block_box.bind("<<ComboboxSelected>>", lambda e: self.on_block_changed())
        self.buffer_box.bind("<<ComboboxSelected>>", lambda e: self.on_buffer_changed())
        # 動いている間の数値。項目ごとに幅を決めた欄に出す（1行の文字列にすると、数値で長さが変わるたびに
        # 窓の幅まで伸び縮みする）
        sf = ttk.Frame(c)
        sf.grid(row=2, column=0, columnspan=3, sticky="w", pady=(px(8), 0))
        self.stat_vals = {}
        for i, (key, name, width) in enumerate((
            ("proc", "処理", 15), ("drop", "途切れ", 7), ("worst", "最大", 15), ("skip", "スキップ", 7),
        )):
            r, col = divmod(i, 2)
            ttk.Label(sf, text=name, style="Caption.TLabel").grid(row=r, column=2 * col, sticky="w",
                                                                 padx=(0 if col == 0 else px(16), px(6)))
            v = ttk.Label(sf, text="—", width=width, anchor="w", style="Caption.TLabel")
            v.grid(row=r, column=2 * col + 1, sticky="w")
            self.stat_vals[key] = v

        # ---- 音声デバイス（変えたらすぐ開き直す）。プレビューの ON/OFF・音量はそのデバイスの横に
        c = card(right, "音声デバイス", "変えるとすぐつなぎ直します")
        label(c, "マイク", 1)
        self.in_var, self.out_var, self.mon_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.in_box = ttk.Combobox(c, textvariable=self.in_var, state="readonly", width=30)
        self.in_box.grid(row=1, column=1, sticky="ew", pady=px(4))
        ttk.Button(c, text="再検索", command=self.rescan_devices).grid(row=1, column=2, padx=(px(8), 0))
        label(c, "出力先", 2)
        self.out_box = ttk.Combobox(c, textvariable=self.out_var, state="readonly", width=30)
        self.out_box.grid(row=2, column=1, sticky="ew", pady=px(4))
        self.out_hint = ttk.Label(c, style="Caption.TLabel", wraplength=px(360), justify="left")
        self.out_hint.grid(row=3, column=1, columnspan=2, sticky="w")
        label(c, "プレビュー", 4)
        self.mon_box = ttk.Combobox(c, textvariable=self.mon_var, state="readonly", width=30)
        self.mon_box.grid(row=4, column=1, sticky="ew", pady=px(4))
        for box in (self.in_box, self.out_box, self.mon_box):
            box.bind("<<ComboboxSelected>>", lambda e, b=box: self.on_devices_changed(chose_output=b is self.out_box))
        # プレビュー: 出力先と同じ音を自分のヘッドホンにも流す。ON/OFF・音量はすぐ効く
        pv = ttk.Frame(c)
        pv.grid(row=5, column=1, columnspan=2, sticky="w", pady=(px(4), 0))
        self.preview_var = tk.BooleanVar(value=bool(self.settings["preview_on"]))
        self.mon_switch = ttk.Checkbutton(pv, text="自分で聞く", style="Switch.TCheckbutton",
                                          variable=self.preview_var, command=self.on_preview)
        self.mon_switch.pack(side="left")
        self.mon_vol = tk.DoubleVar(value=float(self.settings["preview_volume"]))
        self._volume(pv, self.mon_vol, 100, "monitor_volume", gap=px(16))

        # 新しい版があるときだけ出す欄（窓の下）
        self.update_bar = ttk.Frame(outer)
        self.update_text = tk.StringVar()
        ttk.Label(self.update_bar, textvariable=self.update_text, foreground=theme.ACCENT).pack(side="left")
        self.update_btn = ttk.Button(self.update_bar, text="更新して再起動", style="Accent.TButton",
                                     command=self.start_update)

        self.refresh_models()
        self.fill_devices()
        self.open_audio()  # 起動したらすぐ地声を流す（出力先を選んでいなければ、選ぶまで待つ）
        if self.settings["loaded"] and self.model_path() is not None:
            self.start_load()  # 前回ロードしたまま閉じた
        self.refresh()
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.after(100, self.tick)
        threading.Thread(target=self._preload, daemon=True).start()
        if PACKAGED:
            threading.Thread(target=self._check_update, daemon=True).start()
        auths = vc_update.model_auths((self.settings["model_user"], self.settings["model_password"]))
        if auths:  # 鍵も覚えた ID・パスワードも無ければ、モデルは配られていない
            threading.Thread(target=self._check_models, args=(auths,), daemon=True).start()

    def _preload(self):
        """窓を開いたらすぐ、裏でライブラリと雑音除去のモデルを読み込んでおく（「ロード」の待ちを減らす）。

        「ロード」の読み込みは、これが終わるのを待ってから import する（_load）。
        """
        try:
            print(f"ライブラリの先読み: {fmt_times(load_libraries(after_torch=self._load_denoiser))}", flush=True)
            self.libs_ok = True
        except BaseException:
            traceback.print_exc()  # 「ロード」で同じ import をしたときに、そちらで知らせる
        finally:
            self.preloaded.set()
            if self.denoise_model is None:
                self.denoise_failed = True

    def _load_denoiser(self):
        try:
            import rvc_denoise

            self.denoise_model = rvc_denoise.load_model()
        except BaseException:
            traceback.print_exc()

    @property
    def preload_finished(self) -> bool:
        """ライブラリも雑音除去のモデルも読み終わった（成功でも失敗でも）。"""
        return self.preloaded.is_set()

    def px(self, n: int) -> int:
        return int(n * self.scale)

    def _slider(self, frm, row, var, f: VoiceField, on_change):
        """スライダーと値と「?」（マウスを乗せると説明）。値は f.step 刻みに吸い付き、刻みに寄せた値が変わったときだけ
        on_change を呼ぶ（動かしている間の1画素ごとには呼ばない）。溝をクリックするとその向きに1刻み、クリックして
        から矢印キーでも1刻みずつ（ホイールでは動かさない。乗せただけで動き、細かく回るホイールでは飛ぶので）。"""
        ttk = self.ttk
        frame = ttk.Frame(frm)
        frame.grid(row=row, column=1, columnspan=2, sticky="w")
        scale = ttk.Scale(frame, from_=f.lo, to=f.hi, variable=var, length=self.px(230))
        scale.pack(side="left")
        text = ttk.Label(frame, width=9)
        text.pack(side="left", padx=self.px(8))
        self.theme.HelpIcon(frame, f.help, self.px(16)).pack(side="left")
        last = [None]

        def changed(*_):
            v = var.get()
            s = snap(v, f.lo, f.hi, f.step)
            if s != v:
                var.set(s)  # 書き込みの通知の中で書くので、通知はもう一度は来ない（Tcl の決まり）
            text.configure(text=f.fmt(s))
            if s != last[0]:
                first, last[0] = last[0] is None, s
                if not first:  # 作ったときの1回目は知らせない
                    on_change()

        def nudge(n: int):
            var.set(snap(var.get() + n * f.step, f.lo, f.hi, f.step))
            return "break"  # ttk の既定の動き（刻みを無視して 1.0 ずつ動く）を止める

        def press(e):
            scale.focus_set()  # 矢印キーで動かせるように
            if "slider" in str(scale.identify(e.x, e.y)):
                return None  # つまみはそのまま（ドラッグ）
            at = (var.get() - f.lo) / (f.hi - f.lo) * scale.winfo_width()  # つまみのおおよその位置
            return nudge(1 if e.x > at else -1)

        for key, n in (("<Left>", -1), ("<Down>", -1), ("<Right>", 1), ("<Up>", 1)):
            scale.bind(key, lambda e, n=n: nudge(n))
        scale.bind("<Button-1>", press)
        var.trace_add("write", changed)
        changed()

    # ---- 知らせ
    def set_notice(self, key: str, text: str = "", kind: str = "info"):
        """状態の下に出す知らせ（モデルが無い・デバイスが見つからない など）。出どころ（key）ごとに持ち、
        空の text で消す。いちばん重い種類の色で、全部を並べて出す。"""
        if text:
            self.notices[key] = (text, kind)
        else:
            self.notices.pop(key, None)
        order = ("info", "ok", "warn", "error")
        worst = max((k for _, k in self.notices.values()), key=order.index, default="info")
        self.notice_label.configure(text="\n".join(t for t, _ in self.notices.values()),
                                    foreground=self.theme.STATE_COLORS[worst])
        if self.notices:
            self.notice_label.grid()
        else:
            self.notice_label.grid_remove()

    # ---- モデル
    def refresh_models(self, select: Path | None = None, keep_current: bool = False):
        """モデルの欄の一覧を作り直して select（無ければ覚えているもの）を選ぶ。keep_current なら、選んでいるモデル・
        index・声の設定はそのままで一覧だけ新しくする（ロードしている間に取ってきたとき。話している声を変えない）。"""
        current = self.model_path() if keep_current else None
        models = find_models()
        saved = path_from_setting(self.settings["model"])
        for extra in (select, saved, current):
            if extra is not None and extra.exists() and extra not in models:
                models.append(extra)
        self.models = labels_for(models, lambda p: p.stem, lambda p: p.parent.name)
        self.model_box["values"] = list(self.models)
        if current is not None:
            self.model_var.set(next(lbl for lbl, p in self.models.items() if p == current))
            return
        want = select or saved
        for lbl, p in self.models.items():
            if p == want:
                self.model_var.set(lbl)
                break
        else:
            self.model_var.set(next(iter(self.models), ""))
        keep_index = select is None and saved is not None and self.model_path() == saved
        self.on_model_selected(use_saved_index=keep_index)
        where = MODELS_DIR if PACKAGED else f"{MODELS_DIR} か {WEIGHTS_DIR}"
        self.set_notice("models", "" if self.models else
                        f"モデルがありません。{where} に .pth と .index を置くか、「参照…」で選んでください。"
                        "（モデルが無くても、地声とノイズ除去は使えます）", "warn")

    def model_path(self) -> Path | None:
        return self.models.get(self.model_var.get())

    def on_model_selected(self, use_saved_index: bool = False, reload: bool = False):
        p = self.model_path()
        saved = path_from_setting(self.settings["index"]) if use_saved_index else None
        if saved is not None and saved.exists():
            self.set_index(saved)
        else:
            self.set_index(guess_index(p) if p is not None else None)
        self.load_model_options(p)
        if reload:
            self.reload_if_loaded()

    def load_model_options(self, p: Path | None):
        """そのモデルで前に使った声の高さ・響き・抑揚・似せる強さに戻す。覚えていなければ既定値。"""
        self.model_key = model_base(p) if p is not None else None
        if self.model_key is None:
            return
        saved = clean_model_entry(self.per_model.get(self.model_key, {}))
        for key, value in saved.items():
            self.voice[key].set(value)  # 書き込むと trace が remember_options を呼ぶ

    def set_index(self, p: Path | None):
        self.index_path = p
        self.index_var.set(elide(p.name, INDEX_WIDTH) if p else f"{NO_INDEX}  似せる強さは効きません")
        self.set_notice("index_name", index_mismatch(self.model_path(), p), "warn")
        self.show_index_problem()

    def show_index_problem(self):
        """読み込んだエンジンが index を使えなかったら知らせる（読めない・違う型・空など。index なしで変換している）。
        エンジンを替えた・外した・index を選び直したときに呼ぶ（そのとき選んでいる index のものだけを出す）。"""
        e = self.engine
        problem = e.index_problem if e is not None and self.engine_key and self.engine_key[1] == self.index_path else None
        self.set_notice("index_invalid", f"{problem}。index を使わずに変換しています（似せる強さは効きません）"
                        if problem else "", "warn")

    def _check_models(self, auths: list):
        """裏で、配っている声のモデルの一覧を取る（tick が show_model_news で知らせる）。つながらない・ID が違う
        ときは何もしない（ログにだけ残す）。"""
        try:
            self.model_list = vc_update.fetch_models_any(auths)[1]
        except Exception as e:
            print(f"モデルの一覧を取れませんでした: {type(e).__name__}: {e}", flush=True)

    def show_model_news(self, models: dict):
        """配っているモデルに、手元に無いもの・取ったものの新しい版があれば知らせる。「取ってくる…」の一覧を開いたら
        消し、見た版は次から知らせない（取らないと決めたものを毎回知らせない）。"""
        news = vc_update.model_news(models, self.settings["models_seen"])
        heads = {"new": "新しい声のモデル", "changed": "取ってあるモデルの新しい版"}
        parts = [f"{head}（{'・'.join(n for n, s in news.items() if s == key)}）"
                 for key, head in heads.items() if key in news.values()]
        self.set_notice("model_news", "と".join(parts) + "があります。「取ってくる…」から取れます" if parts else "", "ok")

    def open_model_fetch(self):
        """「取ってくる…」: 配った人が itr-server に置いた声のモデルの一覧を出し、選んだものを models/ に取る
        （vc_update.fetch_models・download_model）。ID・パスワードは、アプリの鍵（vc models access で作り、全部入りの
        zip に入れたもの）→ この PC に覚えたもの の順に使う。どちらも無い・使えないときだけ入力欄を出す。"""
        if self.fetch_win is not None and self.fetch_win.winfo_exists():
            self.fetch_win.lift()
            return
        tk, ttk, theme, px = self.tk, self.ttk, self.theme, self.px
        win = tk.Toplevel(self.root)
        win.title("モデルを取ってくる")
        win.configure(bg=theme.BG)
        win.resizable(False, False)
        win.transient(self.root)
        self.fetch_win = win
        f = ttk.Frame(win, padding=px(16))
        f.grid(sticky="nsew")
        builtin = vc_update.builtin_access()
        saved = (self.settings["model_user"], self.settings["model_password"])
        uid, pw = tk.StringVar(value=saved[0]), tk.StringVar(value=saved[1])
        intro = ttk.Label(f, style="Dim.TLabel", wraplength=px(560), justify="left")
        intro.grid(row=0, column=0, columnspan=5, sticky="w")
        pw_entry = ttk.Entry(f, textvariable=pw, width=22, show="•")
        inputs = [ttk.Label(f, text="ID"), ttk.Entry(f, textvariable=uid, width=14), ttk.Label(f, text="パスワード"), pw_entry]
        list_btn = ttk.Button(f, style="Accent.TButton")
        list_btn.grid(row=1, column=4, sticky="e", pady=px(12))
        rows = ttk.Frame(f)
        rows.grid(row=2, column=0, columnspan=5, sticky="ew")
        status = tk.StringVar()
        ttk.Label(f, textvariable=status, style="Dim.TLabel", wraplength=px(560), justify="left").grid(
            row=3, column=0, columnspan=5, sticky="w", pady=(px(10), 0))
        close_btn = ttk.Button(f, text="閉じる")
        close_btn.grid(row=4, column=4, sticky="e", pady=(px(12), 0))
        # auth: 一覧を取れた (ID, パスワード)（モデルを取るときに使う）。inputs: 入力欄を出している。
        # progress は裏のスレッドが書き、poll が出す
        state = dict(auth=None, inputs=False, models={}, busy=False, progress=None, name="")

        def show_inputs() -> None:
            intro.configure(text="配った人から受け取った ID とパスワードを入れてください（この PC に覚えます）。")
            for i, w in enumerate(inputs):
                w.grid(row=1, column=i, sticky="w", padx=(0 if i % 2 == 0 else px(6), px(12)))
            list_btn.configure(text="一覧を見る")
            state["inputs"] = True

        def run(target, args: tuple, on_ok) -> None:
            """裏のスレッドで target(*args)。終わったら窓のスレッドで on_ok(結果)（Tk は別のスレッドから触れない）。"""
            state["busy"] = True
            list_btn.state(["disabled"])
            box: dict = {}

            def work() -> None:
                try:
                    box["ok"] = target(*args)
                except vc_update.AuthError as e:
                    box["auth"] = str(e)
                except Exception as e:
                    traceback.print_exc()
                    box["error"] = f"{type(e).__name__}: {e}"

            thread = threading.Thread(target=work, daemon=True)
            thread.start()

            def poll() -> None:
                if not win.winfo_exists():
                    return
                if state["progress"] is not None:
                    done, total = state["progress"]
                    status.set(f"{state['name']} を取っています… {done / 1e6:.0f} / {total / 1e6:.0f} MB")
                if thread.is_alive():
                    win.after(100, poll)
                    return
                state["busy"], state["progress"] = False, None
                list_btn.state(["!disabled"])
                if "ok" in box:
                    on_ok(box["ok"])
                elif "auth" in box:
                    # 入力欄を出す前は、アプリの鍵（一覧なら、通らなければ覚えた ID・パスワードも）で試していた
                    with_saved = target is vc_update.fetch_models_any and len(args[0]) > 1
                    if state["inputs"]:
                        status.set(box["auth"])
                    elif with_saved:
                        status.set(f"アプリに入っている鍵も、覚えている ID（{saved[0]}）も使えません（止められた可能性が"
                                   "あります）。配った人に確かめて、新しい ID とパスワードを入れてください。")
                    else:
                        status.set("アプリに入っている鍵が使えなくなっています。配った人から新しい更新ファイル（鍵入り）を"
                                   "もらうか、その人だけの ID とパスワードを入れてください。")
                    show_inputs()
                else:
                    status.set(f"取れませんでした（{box['error']}）。インターネットにつながっているか確かめてください。")

            win.after(100, poll)

        def show_list() -> None:
            if state["busy"]:
                return
            # 入力欄を出していればその値、出していなければアプリの鍵 → 覚えた ID・パスワード（vc_update.model_auths）
            auths = [(uid.get().strip(), pw.get())] if state["inputs"] else vc_update.model_auths(saved)
            if not auths or not all(auths[0]):  # 開いた後に鍵ファイルが無くなったときも
                show_inputs()
                status.set("ID とパスワードを入れてください。")
                return
            status.set("一覧を取っています…")
            run(vc_update.fetch_models_any, (auths,), lambda result: listed(*result))

        def listed(auth: tuple, models: dict) -> None:
            seen = {n: vc_update.model_version(e) for n, e in models.items()}
            before = (self.settings["model_user"], self.settings["model_password"])
            own = auth != vc_update.builtin_access()  # 入れた・覚えた ID で取れた（今の鍵ファイルと比べる）
            if own:
                show_inputs()  # 鍵が使えなかったなら、入力欄も出す
                self.settings["model_user"], self.settings["model_password"] = auth
            # 一覧を見たので、起動したときの知らせを消して、今の版はもう知らせない（変わったときだけ設定に書く）
            self.set_notice("model_news")
            if own and auth != before or seen != self.settings["models_seen"]:
                self.settings["models_seen"] = seen
                self.remember_options()
            state["models"], state["auth"] = models, auth
            draw()
            status.set("取りたいモデルの「取る」を押してください。" if models else "まだモデルが置かれていません。")

        def draw() -> None:
            for w in rows.winfo_children():
                w.destroy()
            for r, (name, entry) in enumerate(state["models"].items()):
                model_state = vc_update.model_state(name, entry)
                size = sum(int(x["size"]) for x in entry["files"]) / 1e6
                ttk.Label(rows, text=name, style="Section.TLabel").grid(row=r, column=0, sticky="w", pady=px(4))
                ttk.Label(rows, text=entry.get("note", ""), style="Dim.TLabel", wraplength=px(260)).grid(
                    row=r, column=1, sticky="w", padx=px(12))
                ttk.Label(rows, text=f"{size:.0f} MB", style="Dim.TLabel").grid(row=r, column=2, sticky="e")
                if model_state in ("same", "mine"):
                    text = "取ってあります" if model_state == "same" else "同じ名前の自分のモデルがあります"
                    ttk.Label(rows, text=text, style="Dim.TLabel").grid(row=r, column=3, padx=(px(12), 0))
                else:
                    ttk.Button(rows, text="取る" if model_state == "new" else "新しくする",
                               command=lambda n=name: fetch(n)).grid(row=r, column=3, padx=(px(12), 0))

        def fetch(name: str) -> None:
            if state["busy"]:
                return
            state["name"] = name
            status.set(f"{name} を取っています…")

            def progress(done: int, total: int) -> None:
                state["progress"] = (done, total)  # 裏のスレッドから。表示は poll が

            def fetched(path: Path) -> None:
                if self.engine is not None or self.loading:  # 使っている声はそのまま（話している途中で変えない）
                    self.refresh_models(keep_current=True)
                    status.set(f"{name} を取りました。モデルの欄で選べます（今の声はそのままです）。")
                else:
                    self.refresh_models(select=path if path.suffix == ".pth" else None)
                    status.set(f"{name} を取りました。モデルの欄で選んであります。")
                draw()

            run(vc_update.download_model, (name, state["models"][name], state["auth"], progress), fetched)

        def close() -> None:
            if state["busy"]:  # 取っている途中で閉じて開き直すと、同じものを2つ同時に取れてしまう
                status.set("取り終わるまでお待ちください（終わると閉じられます）。")
                return
            win.destroy()

        list_btn.configure(command=show_list)
        close_btn.configure(command=close)
        win.protocol("WM_DELETE_WINDOW", close)
        pw_entry.bind("<Return>", lambda e: show_list())
        if builtin is None:
            show_inputs()
        else:
            intro.configure(text="配った人が置いた声のモデルです。取りたいものの「取る」を押してください。")
            list_btn.configure(text="一覧を更新")
        win.update_idletasks()
        win.geometry(f"+{self.root.winfo_rootx() + px(60)}+{self.root.winfo_rooty() + px(60)}")
        theme.dark_title_bar(win)
        if builtin is not None or all(saved):
            show_list()  # 鍵か、覚えている ID・パスワードで、すぐ一覧を出す

    def browse_model(self):
        from tkinter import filedialog

        start = MODELS_DIR if MODELS_DIR.is_dir() else PROJECT_ROOT
        f = filedialog.askopenfilename(title="モデル（.pth）を選ぶ", initialdir=start,
                                       filetypes=[("RVC モデル", "*.pth")])
        if f:
            self.refresh_models(select=Path(f).resolve())
            self.reload_if_loaded()

    def browse_index(self):
        from tkinter import filedialog

        p = self.model_path()
        f = filedialog.askopenfilename(title="index を選ぶ",
                                       initialdir=p.parent if p else PROJECT_ROOT,
                                       filetypes=[("index", "*.index")])
        if f:  # キャンセルなら今のまま（使わないなら「似せる強さ」を 0 にする）
            self.set_index(Path(f).resolve())
            self.reload_if_loaded()

    # ---- デバイス
    def fill_devices(self):
        from rvc_realtime import CABLE_LOOPBACK, DEFAULT_HOSTAPI, DEFAULT_OUTPUT, default_device, devices

        sd = self.sd
        self.inputs = labels_for(devices(sd, "input", DEFAULT_HOSTAPI), lambda d: d["name"],
                                 lambda d: d["index"])
        self.outputs = labels_for(devices(sd, "output", DEFAULT_HOSTAPI), lambda d: d["name"],
                                  lambda d: d["index"])
        self.in_box["values"] = list(self.inputs)
        self.out_box["values"] = list(self.outputs)
        self.mon_box["values"] = [NO_PREVIEW] + list(self.outputs)

        def pick(table, saved, prefer):
            if saved in table:
                return saved
            for lbl in table:
                if prefer(lbl):
                    return lbl
            return next(iter(table), "")

        try:
            din = sd.query_devices(default_device(sd, "input", DEFAULT_HOSTAPI))["name"]
            dout = sd.query_devices(default_device(sd, "output", DEFAULT_HOSTAPI))["name"]
        except Exception:
            din = dout = ""
        # 既定の録音デバイスが CABLE Output になっていることがある（VB-CABLE を入れた直後）
        self.in_var.set(pick(self.inputs, self.settings["input"],
                             lambda lbl: lbl.startswith(din) and CABLE_LOOPBACK not in lbl)
                        or pick(self.inputs, "", lambda lbl: CABLE_LOOPBACK not in lbl))
        has_cable = any(DEFAULT_OUTPUT in lbl for lbl in self.outputs)
        self.out_var.set(pick(self.outputs, self.settings["output"],
                              lambda lbl: DEFAULT_OUTPUT in lbl if has_cable else lbl.startswith(dout)))
        # プレビューは選んだときだけ（既定で開くとスピーカーが鳴り、マイクが拾って回り込む）
        saved = self.settings["preview"]
        self.mon_var.set(saved if saved in self.outputs else NO_PREVIEW)
        # 前回選んでいたデバイスが無い（抜けている）なら知らせる。代わりに選んだものは覚えておく
        self.missing_devices = {}
        for kind, var, table in (("input", self.in_var, self.inputs), ("output", self.out_var, self.outputs),
                                 ("preview", self.mon_var, self.outputs)):
            want = self.settings[kind]
            if want and want not in table:
                self.missing_devices[kind] = (want, var.get())
        names = "、".join(f"{label}「{self.missing_devices[k][0]}」" for k, label in
                         (("input", "マイク"), ("output", "出力先"), ("preview", "プレビュー"))
                         if k in self.missing_devices)
        self.set_notice("devices", f"前回の{names}が見つかりません。挿してから「再検索」するか、選び直してください。"
                        if names else "", "warn")
        self.set_notice("no_mic", "" if self.inputs else
                        "マイクが見つかりません。マイクをつないでから「再検索」してください。", "error")
        self.out_hint.configure(text=(
            "Discord などに流す先（CABLE Input）。自分の声はプレビューにヘッドホンを選んで聞く"
            if has_cable else
            "VB-CABLE が見つかりません。Discord などに流すには VB-CABLE を入れてから「再検索」。"
            "今は出力先にヘッドホンを選べば、自分で聞いて確かめられます"))

    def preview_device(self) -> dict | None:
        return self.outputs.get(self.mon_var.get())

    def rescan_devices(self):
        """デバイスとモデルを探し直して、音を開き直す。今選んでいるものはそのまま（あれば）。"""
        if self.defer_while_warming(self.rescan_devices):
            return
        # 選び直したものを優先する（self.settings は前回保存した値なので、そのままだと戻ってしまう）
        for kind, var in (("input", self.in_var), ("output", self.out_var), ("preview", self.mon_var)):
            cur = var.get()
            missing = self.missing_devices.get(kind, ("", ""))
            if cur and cur != missing[1]:
                self.settings[kind] = cur if not (kind == "preview" and cur == NO_PREVIEW) else ""
        # PortAudio はデバイス一覧を起動時に読むので、作り直して読み直させる（開いているものは閉じてから）
        self.close_audio()
        self.sd._terminate()
        self.sd._initialize()
        self.fill_devices()
        model, index = self.model_path(), self.index_path
        self.refresh_models(select=model)
        if model is not None and self.model_path() == model:
            self.set_index(index)
        self.open_audio()

    def on_devices_changed(self, chose_output: bool = False):
        if chose_output:
            self.output_chosen = True
            self.missing_devices.pop("output", None)  # 前回のものの代わりではなく、自分で選んだ
        self.open_audio()
        self.remember_options()

    def on_block_changed(self):
        self.open_audio()
        self.reload_if_loaded()  # ブロック長が変わると、モデルも作り直す
        self.remember_options()

    def on_buffer_changed(self):
        if self.session is not None:
            self.session.set_buffer(int(self.buffer_var.get()))  # 開き直さない（試運転もやり直さない）
        self.remember_options()

    def output_ok(self) -> bool:
        """今の出力先に流してよいか: CABLE Input か、自分で選んだもの（前回のものが見つからず代わりに選んだ
        既定のデバイスは含めない。スピーカーだとハウリングする）。"""
        from rvc_realtime import DEFAULT_OUTPUT

        return DEFAULT_OUTPUT in self.out_var.get() or (self.output_chosen and "output" not in self.missing_devices)

    def defer_while_warming(self, action) -> bool:
        """試運転中なら action を終わってから行う（True を返す）。試運転は途中で止められないので、今開き直すと
        窓が終わるまで固まり、終わらなければ読み込んだモデルを捨てることになる。"""
        if not self.warming:
            return False
        self.deferred = action
        return True

    # ---- 音の流れ（起動したらすぐ開く）
    def open_audio(self):
        """マイク・出力先・プレビューを開いて、音を流し始める（開いていれば開き直す）。窓のスレッドから呼ぶ。"""
        from rvc_realtime import CABLE_LOOPBACK, Session

        if self.defer_while_warming(self.open_audio):
            return
        self.close_audio()
        self.audio_error = ""
        if not self.output_ok():
            return  # 状態の欄に「出力先を選んでください」と出す（refresh）
        in_dev, out_dev = self.inputs.get(self.in_var.get()), self.outputs.get(self.out_var.get())
        mon_dev = self.preview_device()
        if in_dev is None or out_dev is None:
            self.audio_error = "マイクと出力先を選んでください。"
            return
        if CABLE_LOOPBACK in in_dev["name"]:
            self.audio_error = (f"マイクが「{CABLE_LOOPBACK}」になっています。自分の出力を拾い続けてしまうので、"
                                "マイクを選んでください。")
            return
        if mon_dev is not None and mon_dev["index"] == out_dev["index"]:
            self.audio_error = "プレビューと出力先が同じデバイスです。プレビューは自分で聞くヘッドホンを選ぶか、「（なし）」にしてください。"
            return
        s = Session(in_dev["index"], out_dev["index"], block_ms=int(self.block_var.get()),
                    buffer_ms=int(self.buffer_var.get()), options=self.options(), voice=self.voice_on,
                    denoise=self.denoise_var.get(), monitor_dev=mon_dev["index"] if mon_dev else None,
                    monitor_on=self.preview_var.get(), monitor_volume=self.mon_vol.get() / 100,
                    input_gain=self.in_vol.get() / 100)
        try:
            s.open()
        except Exception as e:
            traceback.print_exc()
            self.audio_error = self.audio_error_text(e)
            return
        print(f"音声: {in_dev['name']}（{s.in_rate} Hz）→ {out_dev['name']}（{s.out.rate} Hz）"
              + (f"、プレビュー {mon_dev['name']}" if mon_dev else ""), flush=True)
        self.session = s  # 雑音除去は tick が渡す
        if self.engine is not None and not self.loading:
            if s.accepts(self.engine):
                s.set_engine(self.engine, wait=0)  # 試運転し直す（変換スレッドは開くたびに新しい）
            else:
                self.reload_if_loaded()
        self.mon_warned = s.monitor_error
        self.set_notice("preview", f"{s.monitor_error}。プレビューなしで続けます" if s.monitor_error else "", "warn")

    def close_audio(self, wait: float = 10.0):
        s, self.session = self.session, None
        if s is None:
            return
        s.stop(wait)
        if not s.stopped_cleanly:
            # 変換スレッドが終わらなかった（GPU が固まった等）。同じ engine を次で使うと取り合いになる
            self.engine = self.engine_key = None
            self.show_index_problem()
        for meter in (self.in_meter, self.out_meter):
            meter.reset()

    def audio_error_text(self, e: BaseException) -> str:
        from rvc_realtime import hostapi_name

        devs = ""
        for label, var, table in (("マイク", self.in_var, self.inputs), ("出力先", self.out_var, self.outputs),
                                  ("プレビュー", self.mon_var, self.outputs)):
            d = table.get(var.get())
            if d is not None:
                devs += f"{label}: {d['name']}（{hostapi_name(self.sd, d['index'])}）\n"
        return (f"デバイスを開けませんでした（{e}）。\n{devs}"
                "・他のアプリがそのデバイスを独占していないか確かめる\n・「再検索」を押してから選び直す")

    # ---- ロード・ボイチェン
    def wanted_key(self) -> tuple:
        return self.model_path(), self.index_path, int(self.block_var.get())

    @property
    def warming(self) -> bool:
        """変換スレッドが試運転している（ロードの続き）。"""
        return self.session is not None and self.engine is not None and self.session.engine_state == "warming"

    def toggle_load(self):
        if self.loading or self.warming or self.updating:
            return
        if self.engine is None:
            self.start_load()
        else:
            # 自分で解放したなら地声にする（ON のままだと無音になる）。次にロードが済んだら ON に戻す
            if self.voice_on:
                self.voice_resume = True
                self.set_voice(False)
            self.unload()

    def start_load(self):
        """モデルを読み込む（裏のスレッド）。読み込んでいる間も音は流れている（ボイチェン ON なら無音）。"""
        if self.updating:
            return  # 入れ替えて開き直すところ（開き直した後にロードする）
        model = self.model_path()
        if model is None or not model.exists():
            self.theme.show(self.root, APP_NAME, "モデル（.pth）を選んでください。", "warn")
            return
        key = self.wanted_key()
        if self.engine is not None and self.engine_key == key:
            return
        self.loading = True
        self.set_notice("voice")
        self.load_result = None
        self.progress = Progress()
        prev, self.engine, self.engine_key = self.engine, None, None
        self.show_index_problem()
        threading.Thread(target=self._load, args=(key, prev, self.session, self.progress), daemon=True).start()
        self.remember_options()

    def _load(self, key: tuple, prev, session, prog: Progress):
        """読み込み（重いので窓のスレッドの外で）。結果は self.load_result に置く。"""
        try:
            prog.begin("libs")
            # 先読みが終わるのを待ってから import する。2つのスレッドで同時に import すると、
            # transformers の遅延読み込みがぶつかって「cannot import name 'AutoFeatureExtractor'」で
            # 落ちる（Windows で起きた。Mac でも、片方が読み始めて 0.05 秒後にもう片方が来ると再現した）。
            # Python の import のロックは transformers の遅延読み込みまでは守らない
            self.preloaded.wait()
            import torch

            from rvc_engine import StreamEngine
            from rvc_realtime import CROSSFADE_MS, SAMPLE_RATE

            prog.end("libs")
            prog.begin("model")
            # 前のモデルの HuBERT・RMVPE は使い回す（切り替えが速い）。変換スレッドが手放してから
            if prev is not None and session is not None and not session.set_engine(None):
                prev = None  # 手放さない（GPU が固まった等）。前のものは使い回さない
            model, index, block_ms = key
            engine = StreamEngine(model, index, SAMPLE_RATE, block_ms, CROSSFADE_MS, 2500, previous=prev)
            prev = None
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            prog.end("model")
            self.load_result = ("ok", engine, key)
        except BaseException as e:
            traceback.print_exc()
            # 例外を持ち続けない（traceback が前のモデルや作りかけのものを抱えて、GPU のメモリが空かない）
            self.load_result = ("error", load_error_text(e), None)
        finally:
            del prev

    def check_load(self):
        """読み込みの結果を受け取って変換スレッドに渡し、試運転が済むのを見届ける（tick から）。"""
        if self.load_result is not None:
            kind, value, key = self.load_result
            self.load_result = None
            self.loading = False
            if kind == "error":
                self.progress = None
                self.root.after_idle(lambda: self.show_error(value))
                return
            self.engine, self.engine_key = value, key
            self.show_index_problem()
            if key != self.wanted_key():  # 読み込んでいる間にモデル・ブロック長を替えた
                self.start_load()
                return
            dev = str(value.device)
            if dev.startswith("cuda"):
                import torch

                self.gpu_text = torch.cuda.get_device_name(torch.device(dev))
            else:
                self.gpu_text = f"{dev} で動いています。GPU を使えていないので、間に合わず途切れる可能性が高いです"
            if self.session is not None:
                self.session.set_engine(value, wait=0)
            if self.progress is not None:
                self.progress.begin("warmup")
        s = self.session
        if s is None or self.engine is None:
            return
        if s.engine_state == "failed":
            text = load_error_text(s.engine_error)
            self.unload()
            self.root.after_idle(lambda: self.show_error(text))
        elif s.engine_state == "ready":
            if self.progress is not None:
                self.progress.end("warmup")
                print(f"ロードにかかった時間: {self.progress.summary()}", flush=True)
                self.progress = None
            if self.voice_resume:  # ON のまま解放していた
                self.voice_resume = False
                self.set_voice(True)

    def reload_if_loaded(self):
        """ロードしているなら、選んだモデル・index・ブロック長で読み込み直す（同じなら何もしない）。"""
        if self.loading:
            return  # 読み終わったところで check_load が選び直したものを読む
        if self.engine is not None and self.engine_key != self.wanted_key():
            self.start_load()

    def unload(self):
        """モデルを外して GPU を空ける。ボイチェンの ON/OFF はそのまま（ON なら無音。変換が止まって外したときに
        勝手に地声にしない）。「解放」ボタンのときは toggle_load が先に地声にしている。
        窓は長く止めない（変換スレッドが手放すのを少しだけ待つ。手放さなければ GPU のメモリはそのまま）。"""
        released = self.session is None or self.session.set_engine(None, wait=0.5)
        self.engine = self.engine_key = None
        self.show_index_problem()
        self.progress = None
        if released and self.libs_ok:
            import torch

            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        self.remember_options()

    def toggle_voice(self):
        self.set_voice(not self.voice_on)

    def set_voice(self, on: bool):
        """ボイチェンの ON/OFF。変換は止めずに、流す音を変換した声と地声で切り替える（次のブロックから）。"""
        self.voice_on = on
        if self.session is not None:
            self.session.voice = on
        self.refresh()

    def on_denoise(self):
        if self.session is not None:
            self.session.denoise = self.denoise_var.get()
        self.remember_options()

    # ---- プレビューの ON/OFF・音量（すぐ効く。デバイスは開いたまま、OFF は無音を流す）
    def on_preview(self):
        if self.session is not None:
            self.session.monitor_on = self.preview_var.get()
        self.remember_options()

    def _volume(self, parent, var, hi: int, attr: str, gap: int):
        """「音量」のつまみ（0〜hi %）。動かすと開いている音の流れの attr（倍率）にすぐ効かせる。"""
        ttk = self.ttk
        ttk.Label(parent, text="音量", style="Dim.TLabel").pack(side="left", padx=(gap, self.px(6)))
        ttk.Scale(parent, from_=0, to=hi, variable=var, length=self.px(130)).pack(side="left")
        text = self.tk.StringVar()
        ttk.Label(parent, textvariable=text, width=5).pack(side="left", padx=(self.px(6), 0))

        def show():
            text.set(f"{var.get():.0f}%")
            if self.session is not None:
                setattr(self.session, attr, var.get() / 100)

        def changed(*_):
            show()
            self.remember_options()  # 止まってから1回だけ書く

        var.trace_add("write", changed)
        show()

    # ---- 録って聞く（出力先に流す音を録って、プレビューで流す）
    def toggle_recording(self):
        s = self.session
        if s is None:
            return
        if s.recording[0]:
            s.stop_recording()
        else:
            s.start_recording(RECORD_SECONDS)
        self.show_recording()

    def show_recording(self):
        s = self.session
        ready = s is not None and s.mon is not None
        state, left = s.recording if ready else ("", 0.0)
        if state == "rec":
            btn, text = "止める", f"録音中… あと {math.ceil(left)} 秒。話してください"
        elif state == "play":
            btn, text = "止める", f"再生中… あと {math.ceil(left)} 秒"
        elif ready:
            btn, text = "録って聞く", f"{RECORD_SECONDS} 秒録って、プレビューで聞きます"
        elif s is None:
            btn, text = "録って聞く", ""  # 音が止まっている（理由は状態の欄に出る）
        elif self.preview_device() is not None:
            btn, text = "録って聞く", "プレビューを開けませんでした"
        else:
            btn, text = "録って聞く", "プレビューを選ぶと使えます"
        if self.rec_shown != (btn, text, ready):  # 変わったときだけ Tk に渡す
            self.rec_shown = (btn, text, ready)
            self.rec_btn.configure(text=btn)
            self.rec_btn.state(["!disabled"] if ready else ["disabled"])
            self.rec_text.set(text)

    # ---- 設定
    def options(self) -> dict:
        v = {key: var.get() for key, var in self.voice.items()}  # スライダーが刻みに寄せてある
        return dict(pitch=v["pitch"], formant=v["formant"], intonation=v["intonation"], index_rate=v["index_rate"],
                    rms_mix=0.0, threshold_db=v["threshold"], f0_method="rmvpe")

    def current_settings(self) -> dict:
        o = self.options()
        p = self.model_path()

        # 前回のデバイスが見つからず代わりを選んだだけなら、前回のものを覚えたままにする（挿し直せば戻る）
        def device(kind: str, current: str) -> str:
            missing, fallback = self.missing_devices.get(kind, ("", ""))
            return missing if missing and current == fallback else current

        return dict(model=path_to_setting(p), index=path_to_setting(self.index_path),
                    input=device("input", self.in_var.get()), output=device("output", self.out_var.get()),
                    preview=device("preview", self.mon_var.get() if self.preview_device() else ""),
                    preview_on=self.preview_var.get(),
                    preview_volume=round(self.mon_vol.get()), pitch=int(o["pitch"]),
                    index_rate=o["index_rate"], threshold=o["threshold_db"],
                    block_ms=int(self.block_var.get()), buffer_ms=int(self.buffer_var.get()),
                    denoise=self.denoise_var.get(), loaded=self.engine is not None or self.loading,
                    voice=self.voice_on, voice_resume=self.voice_resume, output_chosen=self.output_chosen,
                    input_volume=round(self.in_vol.get()), model_user=self.settings["model_user"],
                    model_password=self.settings["model_password"], models_seen=self.settings["models_seen"],
                    per_model=self.per_model)

    def on_option_changed(self):
        s = self.session
        if s is not None:
            o = self.options()
            applied = s.options.get("formant", 0.0)
            if o["formant"] != applied:
                # 響きは、スライダーを動かしている間は渡さない（途中の値ごとに GPU の準備を作り直さない）。
                # 止まってから FORMANT_DELAY_MS 後に1回だけ。ほかの値はすぐ（次のブロックから）
                if self.formant_job is not None:
                    self.root.after_cancel(self.formant_job)
                self.formant_job = self.root.after(FORMANT_DELAY_MS, self.apply_formant)
                o["formant"] = applied
            s.options = o
        self.remember_options()

    def apply_formant(self):
        self.formant_job = None
        if self.session is not None:
            self.session.options = self.options()

    def remember_options(self):
        """今のモデルの声の高さ・響き・抑揚・似せる強さを覚えて、少し待ってから保存する。"""
        if self.model_key is not None:
            self.per_model[self.model_key] = clean_model_entry(self.options())
        # スライダーを動かしている間は何度も呼ばれるので、止まってから1回だけ書く
        if self.save_job is not None:
            self.root.after_cancel(self.save_job)
        self.save_job = self.root.after(500, self.save_now)

    def save_now(self):
        self.save_job = None
        save_settings(self.current_settings())

    # ---- 表示
    def refresh(self):
        """状態・ボタン・タイトルを今の状態に合わせる（tick から何度も呼ぶ。変わったときだけ描き直す）。"""
        t, s = self.theme, self.session
        ready = s is not None and s.voice_ready
        busy = self.loading or self.warming
        if busy:
            self.load_btn.set("読み込み中…", t.GRAY, enabled=False)
        elif self.engine is not None:
            self.load_btn.set("解放", t.DISABLED, fg=t.DIM, enabled=not self.updating)
        else:
            self.load_btn.set("ロード", t.ACCENT, fg=t.ON_FG, enabled=not self.updating)
        if self.voice_on:
            self.voice_btn.set("ボイチェン ON", t.GREEN, fg=t.ON_FG)
        else:
            self.voice_btn.set("ボイチェン OFF（地声）", t.GRAY, enabled=ready)
        self.mon_switch.configure(state="normal" if self.preview_device() else "disabled")

        progress = self.progress.text() if self.progress is not None else "試運転しています（GPU の準備）"
        if s is None and not self.output_ok():
            color, status = t.YELLOW, "出力先を選んでください"
            detail = ("選ぶと音を流し始めます（スピーカーだとマイクが拾ってハウリングすることがあります。"
                      "Discord に流すなら VB-CABLE の CABLE Input を選んでください）")
        elif s is None:
            color, status = t.RED, "音が止まっています"
            detail = self.audio_error or "マイクと出力先を選んでください。"
        elif self.voice_on and not ready:
            color, status = t.YELLOW, "無音（ボイチェンの準備中）"
            if self.engine is None and not self.loading:
                detail = "モデルを読み込んでいません。「ロード」すると変換した声に（OFF で地声に戻ります）"
            else:
                detail = f"{progress}。終わると変換した声に（OFF で地声に戻ります）"
        elif self.voice_on:
            color, status = t.GREEN, "ボイチェン中"
            detail = self.gpu_text
        else:
            color, status = t.DIM, "地声を流しています"
            if busy:
                detail = f"{progress}。" + ("終わるとボイチェン ON に戻ります" if self.voice_resume
                                           else "終わったら「ボイチェン ON」にできます")
            elif self.engine is not None:
                detail = "「ボイチェン ON」ですぐ変換した声になります"
            elif self.voice_resume:
                detail = "「ロード」すると、終わったところでボイチェン ON に戻ります"
            else:
                detail = "「ロード」してから「ボイチェン ON」で変換した声になります"
        if s is not None and self.denoise_var.get():
            if self.denoise_failed:
                detail += "\nノイズ除去を読み込めませんでした（雑音を消さずに流しています。詳しくはログ）"
            elif s.denoise_error:
                detail += "\nノイズ除去が止まりました（雑音を消さずに流しています。詳しくはログ）"
            elif s.denoiser is None:
                detail += "\nノイズ除去は、ライブラリの読み込みが終わると効きます（初回は数分かかることがあります）"
        self.dot.set(color)
        if self.status_var.get() != status:
            self.status_var.set(status)
        if self.detail_var.get() != detail:
            self.detail_var.set(detail)
        title = f"{self.title_base}（ボイチェン ON）" if self.voice_on else self.title_base
        if self.root.title() != title:
            self.root.title(title)

    def show_error(self, text: str):
        self.theme.show(self.root, APP_NAME, text, "error")

    def tick(self):
        try:
            self.n_tick += 1
            s = self.session
            if s is not None and s.denoiser is None and self.denoise_model is not None and not s.denoise_error:
                import rvc_denoise

                s.set_denoiser(rvc_denoise.Denoiser(model=self.denoise_model))
            self.check_load()
            if self.deferred is not None and not self.warming:
                action, self.deferred = self.deferred, None
                action()
            if self.n_tick % 5 == 0:
                self.tick_update()
                self.check_health()
                if self.model_list is not None:
                    models, self.model_list = self.model_list, None
                    self.show_model_news(models)
            self.show_level()
            self.show_recording()
            self.refresh()
        finally:
            self.root.after(100, self.tick)

    def check_health(self):
        """音が止まった・変換が止まったら知らせる。数値も出す（0.5 秒ごと）。"""
        s = self.session
        if s is None:
            self.show_stats()
            return
        st = s.poll()
        problem, mon_problem = s.health()
        if problem:
            self.close_audio()
            self.audio_error = f"{problem}。「再検索」でつなぎ直してください。"
            self.alert()
            return
        if s.engine_state == "stuck":
            # 変換スレッドが GPU で固まっている。この Session では直らないので、モデルは捨てて開き直す
            # （固まったスレッドは待たない）
            self.engine = self.engine_key = None
            self.show_index_problem()
            self.close_audio(wait=0.5)
            self.open_audio()
            self.set_notice("voice", f"{s.voice_problem}。モデルを外しました（ボイチェン ON の間は無音。「ロード」し直すか、"
                                     "OFF で地声に。詳しくはログ）", "error")
            self.alert()
            return
        if st["consecutive_errors"] >= 10:
            self.unload()
            self.set_notice("voice", f"変換エラーが続きました（{s.last_error}）。モデルを外しました（ボイチェン ON の"
                                     "間は無音。「ロード」し直すか、OFF で地声に。詳しくはログ）", "error")
            self.alert()
        elif mon_problem and mon_problem != self.mon_warned:
            self.mon_warned = mon_problem
            self.set_notice("preview", f"{mon_problem}。出力先には流し続けています", "warn")
        if not st["times"]:
            return
        times = st["times"]
        avg, worst = 1000 * sum(times) / len(times), 1000 * max(times)
        block = s.block_ms
        self.show_stats(proc=f"{avg:.0f} ms / {block:.0f} ms", worst=f"{worst:.0f} ms",
                        drop=f"{st['dropouts']} 回", skip=f"{st['skips']} 回")
        # 最大の処理時間がブロックの何割か（7割を超えると途切れやすい）
        self.stat_vals["worst"].configure(foreground=(
            self.theme.GREEN if worst < 0.7 * block else self.theme.YELLOW if worst < block else self.theme.RED))
        self.delay_var.set(f"遅れ 約 {s.latency_ms(avg):.0f} ms")

    def show_level(self):
        """入力と出力のメーター。バーは平均の音量（入力は雑音を消した後。Discord に流れる大きさ）、目印はピーク。

        入力の「音割れ」はマイク自体で割れたとき（入力の音量をかける前のピーク。アプリでは直せない）。目印は音量を
        かけた後の位置に出す。出力の「音割れ」は 1 を超えて出力の手前で切れたとき（音量の上げすぎ・変換で大きく
        なった。地声のまま流しているマイクの割れは 1 を超えないので、入力にだけ出る）。"""
        s = self.session
        mic, out = s.take_peaks() if s is not None else (0.0, 0.0)
        gain = s.input_gain if s is not None else 1.0
        level, out_level = (s.stats.level_db, s.stats.out_level_db) if s is not None else (-120.0, -120.0)

        def db(a: float) -> float:
            return 20 * math.log10(a) if a > 1e-6 else -120.0

        # ログには割れ始めだけ残す
        if self.in_meter.show(level, db(mic * gain), mic >= CLIP_LEVEL, self.voice["threshold"].get(),
                              active=s is not None):
            print(f"マイクの音が割れました（ピーク {mic:.3f}）", flush=True)
        if self.out_meter.show(out_level, db(out), out > 1.0, active=s is not None):
            print(f"出力の音が割れました（ピーク {out:.3f}、入力の音量 {gain:.0%}）", flush=True)

    def show_stats(self, **values: str):
        for key, label in self.stat_vals.items():
            label.configure(text=values.get(key, "—"))
        if not values:
            self.stat_vals["worst"].configure(foreground="")
            self.delay_var.set("")

    # ---- 自動更新
    def _check_update(self):
        """裏で新しい版を確かめる（つながらなければ何もしない。ログにだけ残す）。"""
        try:
            self.update_info = vc_update.check()
        except Exception as e:
            print(f"更新の確認に失敗しました: {type(e).__name__}: {e}", flush=True)

    @property
    def updating(self) -> bool:
        return self.update_stage is not None

    def tick_update(self):
        if self.update_result is not None:
            self.finish_update()
        elif self.update_stage == "download":
            u = self.update_info
            if self.update_zip is None:
                self.update_text.set(f"更新をダウンロードしています… {self.update_fraction * 100:.0f}%"
                                     f"（{self.update_fraction * u.size / 1e6:.1f} / {u.size / 1e6:.1f} MB）")
            # 入れ替えるのは、先読み（torch・RVC の import）とロード・試運転が終わってから。読み込み中に
            # tools/・RVC/ を入れ替えると、使っているファイルを動かせずに失敗するか、古いものと新しいものが混ざる
            elif self.preload_finished and not self.loading and not self.warming:
                self.update_stage = "apply"
                self.update_text.set("更新しています…")
                threading.Thread(target=self._update_work, args=(self._apply_update,), daemon=True).start()
            else:
                self.update_text.set("ダウンロードしました。読み込みが終わったら更新して開き直します")
        elif self.update_info is not None and not self.update_offered:
            # 見つけたらすぐ知らせる（読み込みの途中でも。「はい」ならすぐ取り始め、入れ替えは上で待つ）
            self.update_offered = True
            self.root.after_idle(lambda: self.offer_update(self.update_info))

    def show_update_bar(self, text: str, button: bool):
        self.update_text.set(text)
        if button:
            self.update_btn.pack(side="right")
        else:
            self.update_btn.pack_forget()
        self.update_bar.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, self.px(4)))

    def offer_update(self, u):
        """起動して新しい版が見つかったら、窓で知らせる。「いいえ」でも下の欄から更新できる。"""
        new = vc_update.label(u.version)
        head = (f"新しい版（{new}）があります。今の版は {vc_update.current_label()} です。\n\n"
                f"変更点:\n{u.notes.strip() or '（なし）'}\n\n")
        if u.needs_full:
            self.show_update_bar(f"新しい版（{new}）は入れ直しが必要です（README「新しい版を受け取ったら」）", False)
            self.theme.show(self.root, APP_NAME, head + (
                "この版は Python・PyTorch も新しくなっているので、自動では更新できません。配った人から"
                "新しい zip を受け取って、入れ直してください（README の「新しい版を受け取ったら」）。"))
            return
        self.show_update_bar(f"新しい版（{new}）があります", True)
        if self.theme.ask(self.root, APP_NAME, head + (
                "今すぐ更新して、開き直しますか？\n（設定とモデルはそのまま残ります。ダウンロードは"
                f"約 {max(1, round(u.size / 1e6))} MB です。開き直す間だけ音が止まります）")):
            self.start_update()

    def start_update(self):
        if self.updating or self.update_info is None:
            return
        self.update_stage = "download"
        self.update_result = self.update_zip = None
        self.update_fraction = 0.0
        self.update_btn.configure(state="disabled")
        threading.Thread(target=self._update_work, args=(self._download_update,), daemon=True).start()

    def _download_update(self):
        def progress(done, total):
            self.update_fraction = done / max(total, 1)

        self.update_zip = vc_update.download(self.update_info, progress=progress)

    def _apply_update(self):
        vc_update.apply(self.update_zip, self.update_info)
        self.update_result = ("ok", "")

    def _update_work(self, work):
        """更新の裏の作業（取る・入れ替える）。失敗したら update_result に置く（tick が知らせる）。"""
        try:
            work()
        except BaseException as e:
            traceback.print_exc()
            self.update_result = ("error", f"{type(e).__name__}: {e}")

    def finish_update(self):
        kind, err = self.update_result
        self.update_stage = self.update_result = None
        if kind == "error":
            self.update_btn.configure(state="normal")
            self.update_text.set("更新できませんでした（今の版のまま使えます）")
            self.theme.show(self.root, APP_NAME, f"更新できませんでした。今の版のまま使えます。\n\n{err}\n\n"
                                                 f"詳しくは {LOG_PATH if PACKAGED else 'コンソール'} にあります。",
                            "error")
            return
        save_settings(self.current_settings())
        print(f"更新しました（{vc_update.label(self.update_info.version)}）。開き直します", flush=True)
        self.close_audio()  # 新しい版がすぐマイク・出力先を開けるように
        if vc_update.restart():
            os._exit(0)  # 新しい版が、この窓が閉じるのを待ってから開く（--after-update）
        self.theme.show(self.root, APP_NAME, "更新しました。開き直してください。")
        self.root.after_idle(self.on_close)  # tick の中なので、窓を閉じるのは tick を抜けてから

    def alert(self):
        """止まったことを知らせる（ゲーム中でも気づけるよう前に出す）。音は鳴らさない（既定の再生
        デバイスが CABLE Input になっていると Discord に流れるため）。"""
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.attributes("-topmost", True)
            self.root.after(1500, lambda: self.root.attributes("-topmost", False))
        except Exception:
            pass

    def on_close(self):
        if self.update_stage == "apply":
            return  # ファイルを入れ替えている途中で終わると、半分だけ新しい版になる（取っている間は閉じてよい）
        save_settings(self.current_settings())
        if self.loading or self.warming or not self.preloaded.is_set():
            # 読み込み中（スレッドが torch の import や engine を作っている・試運転している）。待たずに終える
            os._exit(0)
        self.close_audio()
        self.root.destroy()


def setup_output() -> None:
    """pythonw.exe（配布版）では標準出力が無い。print や本家のログを log.txt に書く。

    前回の log.txt は log.prev.txt に残す（落ちたあと開き直すと、送ってほしいログが消えるため）。
    フォルダに書けない（保護されたフォルダ・Program Files の下など）ときは %LOCALAPPDATA% に書く。
    PortAudio・CUDA などが C から直接書くエラーも残るよう、ファイル記述子 2 もログに向ける。
    """
    global LOG_PATH
    if sys.stdout is not None and sys.stderr is not None:
        return
    import faulthandler
    import tempfile

    f = None
    fallback = Path(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()) / APP_NAME / "log.txt"
    for path in (LOG_PATH, fallback):
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists():
                os.replace(path, path.with_name("log.prev.txt"))
            f = open(path, "w", encoding="utf-8", buffering=1)
            LOG_PATH = path
            break
        except OSError:
            continue
    if f is None:
        f = open(os.devnull, "w", encoding="utf-8")
    sys.stdout = sys.stderr = f
    try:
        faulthandler.enable(f)
        os.dup2(f.fileno(), 2)
    except (OSError, ValueError, RuntimeError):
        pass


def single_instance(wait: float = 0.0) -> bool:
    """同じ PC で2つ目を起動していないか（Windows のみ確かめる）。

    2つ起動すると、CABLE に2人分の声が混ざり、GPU のメモリも2倍使う。初回は窓が出るまで時間が
    かかるので、もう一度ダブルクリックされやすい。ハンドルはプロセスが終わるまで持つ。
    wait 秒までは、前のものが終わるのを待つ（自動更新で開き直したとき。前の窓がまだ閉じきっていない）。
    """
    global _INSTANCE_MUTEX
    if os.name != "nt":
        return True
    try:
        import ctypes

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateMutexW.restype = ctypes.c_void_p
        k32.CloseHandle.argtypes = [ctypes.c_void_p]
        deadline = time.monotonic() + wait
        while True:
            _INSTANCE_MUTEX = k32.CreateMutexW(None, False, f"Local\\{APP_NAME}.RVC")
            if ctypes.get_last_error() != 183:  # ERROR_ALREADY_EXISTS
                return True
            if time.monotonic() >= deadline:
                return False
            k32.CloseHandle(_INSTANCE_MUTEX)
            time.sleep(0.3)
    except Exception:
        return True


_INSTANCE_MUTEX = None


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--check", action="store_true", help="環境を表示して終わる")
    ap.add_argument("--model", help="--check で変換の速さを測るモデル（.pth のパス。リポジトリではモデル名も可）")
    ap.add_argument("--index", help="--check で使う index（既定: モデルから探す）")
    # 知らない引数は無視する（exe にファイルを落とされても、何も出ずに終わらないように）
    args, _unknown = ap.parse_known_args()
    setup_output()
    # インターネットには一切つながない（HuBERT は同梱のものを読むだけ）
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    if PACKAGED:
        # ほかのソフトが入れた Tcl/Tk の場所の指定があると、同梱の Tk を使わず窓が開かない
        os.environ.pop("TCL_LIBRARY", None)
        os.environ.pop("TK_LIBRARY", None)
    disable_quick_edit()  # debug.bat の黒い窓をクリックしても止まらないように（--check でも）
    if args.check:
        return check(args.model, args.index)

    if os.name == "nt":
        try:  # 高 DPI の画面でぼやけないように
            import ctypes

            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    import tkinter as tk
    from tkinter import messagebox

    root = tk.Tk()
    root.withdraw()
    if not single_instance(wait=20 if "--after-update" in sys.argv else 0):
        messagebox.showinfo(APP_NAME, "すでに起動しています。タスクバーの VoiceChanger を開いてください。")
        return 0
    try:
        enter_rvc()
        info = read_build_info()
        print(f"{APP_NAME}  {PROJECT_ROOT}"
              + (f"  （版 {vc_update.label(info.get('version', ''))}、{info.get('date', '?')}）" if info else ""), flush=True)
        import sounddevice as sd

        import vc_theme

        def report(exc, val, tb):
            traceback.print_exception(exc, val, tb)
            text = (f"エラーが起きました。\n\n{exc.__name__}: {val}\n\n"
                    f"詳しくは {LOG_PATH if PACKAGED else 'コンソール'} にあります。")
            try:
                vc_theme.show(root, APP_NAME, text, "error")
            except Exception:
                messagebox.showerror(APP_NAME, text)

        root.report_callback_exception = report
        app = App(root, sd)
    except BaseException as e:
        traceback.print_exc()
        restored = False
        try:  # 自動更新した直後の版が開けなかったら、前の版に戻す（vc_rollback.py）
            restored = vc_update.rollback()
        except Exception:
            traceback.print_exc()
        head = "更新した版を開けなかったので、前の版に戻しました。もう一度開いてください。" if restored else "起動できませんでした。"
        messagebox.showerror(APP_NAME, f"{head}\n\n{type(e).__name__}: {e}\n\n"
                                       f"詳しくは {LOG_PATH if PACKAGED else 'コンソール'} にあります。")
        return 1
    try:
        before = vc_update.started()
        if before is not None:
            now = vc_update.current_label()
            print(f"更新しました（{vc_update.label(before)} → {now}。前の版は update\\old にあります）", flush=True)
            # 状態の欄（モデルが無い等の知らせ）は上書きせず、下の欄に出す
            app.show_update_bar(f"新しい版（{now}）に更新しました", False)
    except Exception:
        traceback.print_exc()
    root.deiconify()
    vc_theme.dark_title_bar(root)  # 表示してから（Windows の Tk は表示するまで枠の窓を作らない）
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
