@echo off
rem =====================================================================
rem  VoiceChanger: start with a console window, for troubleshooting.
rem    1. Shows the environment: GPU, audio devices, conversion speed.
rem    2. Opens the usual window. Errors are printed here.
rem  When asking for help, send the text shown in this window.
rem
rem  KEEP THIS FILE ASCII-ONLY (cmd reads it with the console codepage).
rem  Written out with CRLF by tools\vc_package.py.
rem =====================================================================
cd /d "%~dp0"
echo [1/2] Checking the environment. Loading a model takes a while...
echo.
"%~dp0runtime\python.exe" -s -E "%~dp0tools\vc_gui.py" --check
echo.
echo [2/2] Opening the window. Close it to finish.
"%~dp0runtime\python.exe" -s -E "%~dp0tools\vc_gui.py"
echo.
pause
